#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSS Challenge - Task 1 inference: GRS skill class of every video in a folder
============================================================================

This is the entry point of the challenge container for the task identifier "GRS":

    python inference_task1.py <input folder with mp4 videos> <output folder>

For every video one row is written to <output>/<OUTPUT_FILENAME>:

    VIDEO   file name without extension
    GRS     skill class 0 beginner (GRS < 16) | 1 intermediate (16-23) | 2 proficient (24-31) | 3 expert (>= 32)

Optional columns (WRITE_PROBABILITIES) add the class name and the four class probabilities.

Checkpoints
-----------
CHECKPOINTS lists one or more files; the class probabilities of all of them are averaged.
Each file may be
  * a checkpoint of task1_grs_classification.py (best.pt, epoch_XX.pt): the backbone, the head,
    the frame sampling and the clip geometry are taken from the stored configuration and the
    multi-clip / flip test-time augmentation below is applied;
  * a plain state dictionary of an r2plus1d_18 with a 4-way final layer (the format of the first
    submission): clips of PLAIN_NUM_FRAMES frames at PLAIN_IMG_SIZE pixels, as that model was trained.

Usage
-----
    python inference_task1.py /input /output
    python inference_task1.py /input /output --checkpoint runs/<run>/checkpoints/best.pt
    python inference_task1.py /input /output --set TTA_NUM_CLIPS=5 --set GPU_IDS=[]
"""

import argparse
import os
import shutil
import sys
import tempfile
import time

import numpy as np

if __package__:
    from . import inference_common as common
    from . import task1_grs_classification as grs
else:                                       # executed as a plain script (e.g. inside the container)
    import inference_common as common  # pylint: disable=import-error
    import task1_grs_classification as grs  # pylint: disable=import-error


# ======================================================================================
#                                      CONFIG
# ======================================================================================
class CONFIG:
    """All options of Task 1 inference (edit here, or override with --set KEY=VALUE)."""

    CHECKPOINTS = ["task1_grs_model.pth"]      # checkpoint files (absolute, or relative to the weights folder); several files -> probability ensemble
    GPU_IDS = [0]                              # physical GPU ids to use, e.g. [0] | [0, 1] (DataParallel) | [] (CPU only)
    USE_AMP = True                             # True: fp16 autocast on CUDA (faster) | False: full fp32
    BATCH_SIZE = 4                             # videos per forward pass
    NUM_WORKERS = 4                            # DataLoader worker processes (0 = main process)
    USE_EMA_WEIGHTS = True                     # pipeline checkpoints: True: EMA weights when stored | False: raw weights
    TTA_NUM_CLIPS = 3                          # pipeline checkpoints: temporal clips averaged per video (1 = single clip)
    TTA_HFLIP = True                           # pipeline checkpoints: True: also average the horizontally flipped clips | False
    FRAME_CACHE_DIR = None                     # pipeline checkpoints: folder for decoded frame pools; None -> temporary folder removed at the end
    PLAIN_NUM_FRAMES = 16                      # plain state dictionaries: frames per clip (as trained)
    PLAIN_IMG_SIZE = 128                       # plain state dictionaries: clip resolution in pixels (as trained)
    ON_UNREADABLE_VIDEO = "error"              # "error": stop when a video cannot be decoded | "fallback": write FALLBACK_CLASS for it and continue
    FALLBACK_CLASS = 1                         # class written for unreadable videos with ON_UNREADABLE_VIDEO = "fallback" (a middle class keeps the expected cost low)
    OUTPUT_FILENAME = "task1_results.csv"      # result file written to the output folder
    WRITE_PROBABILITIES = False                # True: add GRS_CLASS_NAME and P_<class> columns | False: VIDEO and GRS only
    SEED = 42                                  # seed of the clip sampling (inference is deterministic for a fixed seed)


NUM_CLASSES = grs.NUM_CLASSES
CLASS_NAMES = grs.CLASS_NAMES
LOG = grs.LOG


# ======================================================================================
#                                  prediction per checkpoint
# ======================================================================================
def pipeline_probabilities(checkpoint_path, paths, cfg, device, cache_dir):
    """Class probabilities (N, 4) from a checkpoint of task1_grs_classification.py."""
    base_cfg = grs.clone_config(grs.CONFIG)
    base_cfg.GPU_IDS, base_cfg.USE_AMP, base_cfg.SEED = cfg.GPU_IDS, cfg.USE_AMP, cfg.SEED
    base_cfg.NUM_WORKERS, base_cfg.INFER_BATCH_SIZE = cfg.NUM_WORKERS, cfg.BATCH_SIZE
    base_cfg.USE_EMA_FOR_INFERENCE, base_cfg.FRAME_CACHE_DIR = cfg.USE_EMA_WEIGHTS, cache_dir
    model, ckpt_cfg = grs.load_model_from_checkpoint(checkpoint_path, base_cfg, device)
    LOG.info("Pipeline checkpoint: backbone %s, head %s, %d frames at %d px, sampling %s", ckpt_cfg.BACKBONE,
             ckpt_cfg.HEAD_TYPE, ckpt_cfg.NUM_FRAMES, ckpt_cfg.IMG_SIZE, ckpt_cfg.FRAME_SAMPLING)
    records = [{"video_id": common.video_id(path), "path": path, "label": -1,
                "soft_label": np.zeros(NUM_CLASSES, dtype=np.float32), "group": path} for path in paths]
    grs.verify_and_cache(records, ckpt_cfg, "test videos")
    return grs.predict_probabilities(model, records, ckpt_cfg, device, cfg.TTA_NUM_CLIPS, cfg.TTA_HFLIP,
                                     desc=f"predict {os.path.basename(checkpoint_path)}")


def plain_probabilities(state_dict, paths, cfg, device):
    """Class probabilities (N, 4) from a plain r2plus1d_18 state dictionary."""
    model = common.build_plain_r2plus1d(state_dict, NUM_CLASSES, "Task 1")
    model = common.wrap_data_parallel(model, device)
    LOG.info("Plain r2plus1d_18 state dictionary: %d frames at %d px", cfg.PLAIN_NUM_FRAMES, cfg.PLAIN_IMG_SIZE)
    logits = common.run_plain_video_model(model, paths, cfg, device)
    logits = logits - logits.max(axis=1, keepdims=True)
    return np.exp(logits) / np.exp(logits).sum(axis=1, keepdims=True)


# ======================================================================================
#                                        main
# ======================================================================================
def predict(input_dir, output_dir, cfg, checkpoint_paths, device):
    """Predict every video of `input_dir` and write the result file; returns its path."""
    paths = common.list_video_files(input_dir)
    LOG.info("Found %d videos in %s", len(paths), input_dir)
    unreadable = common.find_unreadable_videos(paths, cfg.PLAIN_NUM_FRAMES)
    common.handle_unreadable(unreadable, cfg.ON_UNREADABLE_VIDEO, LOG)
    readable = [path for path in paths if path not in unreadable]

    probs = np.zeros((len(readable), NUM_CLASSES))
    cache_dir = cfg.FRAME_CACHE_DIR or tempfile.mkdtemp(prefix="task1_frames_")
    try:
        for checkpoint_path in checkpoint_paths:
            state = common.read_checkpoint(checkpoint_path)
            kind = common.checkpoint_kind(state)
            LOG.info("Checkpoint %s (%s)", checkpoint_path, kind)
            if not readable:
                continue
            if kind == "pipeline":
                probs += pipeline_probabilities(checkpoint_path, readable, cfg, device, cache_dir)
            else:
                probs += plain_probabilities(state, readable, cfg, device)
    finally:
        if cfg.FRAME_CACHE_DIR is None:
            shutil.rmtree(cache_dir, ignore_errors=True)
    probs /= len(checkpoint_paths)

    predictions = dict(zip(readable, probs))
    fallback = np.eye(NUM_CLASSES)[cfg.FALLBACK_CLASS]
    rows = []
    for path in paths:
        prob = predictions.get(path, fallback)
        row = {"VIDEO": common.video_id(path), "GRS": int(np.argmax(prob))}
        if cfg.WRITE_PROBABILITIES:
            row["GRS_CLASS_NAME"] = CLASS_NAMES[row["GRS"]]
            row.update({f"P_{CLASS_NAMES[index]}": round(float(prob[index]), 6) for index in range(NUM_CLASSES)})
        rows.append(row)
    return common.write_results(rows, output_dir, cfg.OUTPUT_FILENAME)


def parse_args(argv=None):
    """Command-line interface: input folder, output folder, optional checkpoints and overrides."""
    parser = argparse.ArgumentParser(description="OSS challenge - Task 1 GRS classification inference")
    parser.add_argument("input_dir", help="folder with the videos to classify")
    parser.add_argument("output_dir", help="folder for the result file")
    parser.add_argument("--checkpoint", action="append", default=[], help="checkpoint file; repeat for an ensemble")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override a CONFIG entry")
    return parser.parse_args(argv)


def main(argv=None):
    """Entry point used by docker/Process_SkillEval.sh and the oss-infer-task1 command."""
    args = parse_args(argv)
    cfg = common.config_namespace(CONFIG)
    common.apply_overrides(cfg, args.set)
    common.export_visible_gpus(cfg.GPU_IDS)
    grs.setup_logging(None)
    grs.set_seed(cfg.SEED, deterministic=True)
    device = common.select_device(cfg.GPU_IDS)
    LOG.info("Task 1 inference | device %s | input %s | output %s", device, args.input_dir, args.output_dir)
    checkpoint_paths = common.resolve_checkpoints(cfg, args.checkpoint)
    start = time.time()
    output_path = predict(args.input_dir, args.output_dir, cfg, checkpoint_paths, device)
    LOG.info("Results written to %s (%.1f s)", output_path, time.time() - start)
    return 0


if __name__ == "__main__":
    sys.exit(main())
