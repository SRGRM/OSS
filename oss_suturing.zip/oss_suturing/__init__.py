"""
Training and inference pipelines for the Open Suturing Skills (OSS) challenge of the
MICCAI Endoscopic Vision (EndoVis) challenge series.

Modules
-------
task1_grs_classification   Task 1: GRS skill class (4 ordinal classes) from a suturing video
task2_osats_prediction     Task 2: the eight OSATS scores (1-5) from a suturing video
task3_keypoint_tracking    Task 3: keypoints, visibility and tracks of hands and instruments
inference_task1/2/3        entry points of the challenge container
inference_common           helpers shared by the inference entry points
"""

__version__ = "1.0.0"
