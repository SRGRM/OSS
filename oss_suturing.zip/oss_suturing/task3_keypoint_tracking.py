#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSS Challenge (MICCAI EndoVis) - Task 3: keypoint tracking of hands and instruments
===================================================================================

Purpose
-------
Train, validate and run inference for Task 3 of the Open Suturing Skills (OSS)
challenge: in every frame of a suturing video the keypoints of six objects have to
be located, flagged as visible / hidden / out-of-frame and linked into tracks:

    class 0  left hand      6 keypoints  thumb, middle, index, ring, pinky, back of hand
    class 1  right hand     6 keypoints  (same layout)
    class 2  scissors       3 keypoints  left (sharp point), right (broad point), joint
    class 3  tweezers       3 keypoints  left (with nub), right (with hole), nub
    class 4  needle holder  3 keypoints  left, right (right when text visible), joint
    class 5  needle         3 keypoints  left (end), right (tip), middle  (up to two needles)

    visibility flag: 0 out of frame, 1 hidden (occluded), 2 visible

The challenge scores the tracks with HOTA (Higher Order Tracking Accuracy) using the
Euclidean distance between predicted and annotated keypoints as similarity. A
HOTA-style metric with that similarity, the PCK (percentage of correct keypoints)
and the visibility accuracy are computed on the validation set after every epoch.

Approach
--------
* A single network predicts, from one frame, one heatmap per keypoint type
  (24 channels), a visibility class per keypoint type and an auxiliary
  7-class segmentation of hands and instruments (the training set provides
  masks at one frame per minute). The encoder is an ImageNet model (ResNet /
  ResNeXt / Wide-ResNet, ConvNeXt, EfficientNet / V2, MobileNet-V3, RegNet-Y or any
  timm model with multi-scale features); the decoder (feature pyramid, U-Net or the
  deconvolution "simple baseline") produces stride-4 maps. The visibility head pools the decoder features
  under the predicted heatmap of each keypoint (attention pooling), so it can
  tell "present but covered" from "left the field of view".
* Heatmap supervision with the CenterNet focal loss (or MSE / BCE / adaptive wing),
  an optional soft-argmax coordinate loss (integral regression), hidden
  keypoints supervised with a reduced weight, out-of-frame keypoints pushed to
  empty maps; visibility cross-entropy with class weights; Dice + cross-entropy
  for the segmentation on frames that have masks.
* Strong geometric and photometric augmentation (scale, rotation, translation,
  horizontal flip with left/right hand swapping, colour jitter, blur, noise and
  random erasing that turns covered keypoints into "hidden" examples) because
  the training set is small.
* Decoding with peak detection, non-maximum suppression and sub-pixel soft-argmax
  refinement; up to two needle instances are assembled from the needle channels
  with a geometric consistency rule; single-instance objects get fixed track ids
  and needle instances are associated across frames with the Hungarian algorithm,
  a miss window and optional exponential smoothing.
* Mixed precision, gradient accumulation and clipping, weight EMA, eight optimisers
  and ten learning-rate schedules with warm-up, early stopping, horizontal-flip
  test-time augmentation.
* Generative Reward Machine (GRM) hyper-parameter search (grm.py) over encoders,
  decoders, losses and optimisation settings, run in phases that can be started at
  different times: calibration probes, estimator fitting, Q-learning search, final
  training. The probes are scored with the validation HOTA.
* Every epoch writes its checkpoint, its MOT-style submission and a row of the
  training report into one run folder. Any frame, mask or annotation file that
  cannot be read stops the program with a clear message.

Expected input layout (as released on Synapse)
-----------------------------------------------
    train/frames/<video>_frame_<id>.png
    train/masks/<video>_frame_<id>_<object>[<n>]_mask.png     binary mask per object instance
    train/mot/<video>_frame_<id>.txt                            one line per object:
        frame, track_id, class_id, -1, -1, -1, -1, x1, y1, v1, x2, y2, v2, ...
    val/frames/<video>/<video>_frame_<id>.png                   (1 fps, keypoints only)
    val/mot/<video>_frame_<id>.txt

Output format
-------------
For every processed frame a text file <video>_frame_<id>.txt in the same layout as
the annotation files (frame, track id, class id, four -1 bounding-box fields, then
x, y, visibility per keypoint in original frame coordinates), plus one file per
video with all frames. The validation set is only ever used for validation.

How to run
----------
    python task3_keypoint_tracking.py                          # RUN_MODE from CONFIG
    python task3_keypoint_tracking.py --mode train --set ENCODER=convnext_tiny
    python task3_keypoint_tracking.py --mode predict --input /input --output /output \
                                      --checkpoint runs/<run>/checkpoints/best.pt

GRM search, phase by phase (each call resumes from the GRM folder, GRM_DIR):
    python task3_keypoint_tracking.py --mode grm_calibrate     # then grm_fit, grm_search, grm_final
    python task3_keypoint_tracking.py --mode grm_full          # every phase in one go

For the challenge container, docker/Process_SkillEval.sh calls inference_task3.py, which
loads the checkpoints written by this script and reuses the decoding and tracking defined here.

`--input` may hold mp4 videos (decoded at TEST_FPS), the validation layout
(one folder of frames per video) or a flat folder of <video>_frame_<id>.png files.
`--set KEY=VALUE` overrides any CONFIG entry (values are parsed as Python literals).

Environment
-----------
Python >= 3.8, numpy, opencv-python, tqdm, scipy (optional, Hungarian
matching; a greedy fallback is used without it) and PyTorch with torchvision:

    CUDA 11.4 driver (R470 series) ->  pip install torch torchvision \
                                       --index-url https://download.pytorch.org/whl/cu118
    CUDA 12.2 driver (R535 series) ->  pip install torch torchvision \
                                       --index-url https://download.pytorch.org/whl/cu121

CONFIG.CUDA_BUILD documents which build the run was intended for; it is checked
against torch.version.cuda at start-up and a warning is printed on mismatch.

Output of a training run (one folder per run under OUTPUT_ROOT)
----------------------------------------------------------------
    config_used.json, train.log, training_report.csv / .json
    checkpoints/epoch_XX.pt, best.pt, last.pt
    submissions/epoch_XX/<video>_frame_<id>.txt (+ <video>.txt per video)
    val_metrics/epoch_XX.json                    per-class PCK, visibility accuracy, HOTA parts

Coding conventions
------------------
PEP 8 naming (snake_case functions and variables, CapWords classes, UPPER_CASE
constants), 120-column lines. The only exceptions are the CONFIG entries, whose
inline comments deliberately stay on one line so that every option and its
alternatives can be read in one place, and the CONFIG class itself, which is
named like a constant because it is used as one.
"""

import argparse
import ast
import contextlib
import copy
import csv
import json
import logging
import math
import os
import random
import re
import shutil
import sys
import tempfile
import time
import types
from collections import Counter, OrderedDict, defaultdict
from datetime import datetime

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

if __package__:
    from . import grm
    from . import training_blocks as blocks
else:                                       # executed as a plain script
    import grm  # pylint: disable=import-error
    import training_blocks as blocks  # pylint: disable=import-error

try:
    from scipy.optimize import linear_sum_assignment   # optional: exact Hungarian matching
except ImportError:                                     # pragma: no cover
    linear_sum_assignment = None


# ======================================================================================
#                                      CONFIG
#   Every option of the pipeline lives here. Each entry carries a comment with its
#   meaning and the alternatives understood by the code.
# ======================================================================================
class CONFIG:
    """All options of the pipeline (edit here, or override with --set KEY=VALUE)."""

    # ---------------------------------------------------------------- run control
    RUN_MODE = "train"                 # "train": train + validate every epoch | "grm_calibrate" | "grm_merge" | "grm_fit" | "grm_search" | "grm_final" | "grm_full" | "grm_report": GRM phases (see the GRM block) | "predict": inference only (needs --input, --output, --checkpoint)
    RUN_NAME = None                    # folder name under OUTPUT_ROOT; None -> "task3_<encoder>_<timestamp>"
    OUTPUT_ROOT = "runs"               # parent folder of all run folders
    SEED = 42                          # random seed for python, numpy and torch
    DETERMINISTIC = False              # True: cudnn deterministic algorithms (slower, reproducible) | False: cudnn benchmark mode

    # ---------------------------------------------------------------- hardware
    GPU_IDS = [0]                      # physical GPU ids to expose, e.g. [0] | [0, 1] (DataParallel) | [] (CPU only)
    CUDA_BUILD = "cu121"               # wheel the environment was installed with: "cu118" (CUDA 11.4 driver) | "cu121" (CUDA 12.2 driver) | "cpu"; informational check
    USE_AMP = True                     # True: automatic mixed precision on CUDA | False: full fp32
    NUM_WORKERS = 4                    # DataLoader worker processes (0 = main process)
    PIN_MEMORY = True                  # True: pinned host memory | False
    PREFETCH_FACTOR = 2                # batches prefetched per worker (NUM_WORKERS > 0)

    # ---------------------------------------------------------------- data
    TRAIN_FRAMES_DIR = "data/train/frames"   # training frames <video>_frame_<id>.png
    TRAIN_MASKS_DIR = "data/train/masks"     # training masks <video>_frame_<id>_<object>_mask.png; None -> no segmentation supervision
    TRAIN_MOT_DIR = "data/train/mot"         # training keypoint files <video>_frame_<id>.txt
    VAL_FRAMES_DIR = "data/val/frames"       # validation frames <video>/<video>_frame_<id>.png (validation only, never used for training)
    VAL_MOT_DIR = "data/val/mot"             # validation keypoint files
    PREDICT_INPUT_DIR = None                 # frames / videos for which a submission is written after every epoch; None -> the validation set
    TEST_FPS = 1.0                           # sampling rate when the input of predict mode consists of mp4 videos (the test annotations are at 1 fps)
    MP4_FRAME_NUMBERING = "original"         # frame ids written for mp4 input: "original" (index inside the video) | "sequential" (0, 1, 2, ... of the sampled frames)
    REQUIRE_MOT_FOR_EVERY_FRAME = True       # True: a training frame without keypoint file stops the program | False: such frames are dropped with a warning
    STRICT_DATA_CHECK = True                 # True: every frame, mask and keypoint file is opened once before training; any failure stops the program
    USE_MASKS = True                         # True: auxiliary segmentation loss on frames that have masks | False: keypoints only

    # ---------------------------------------------------------------- geometry
    IMG_HEIGHT = 384                   # network input height (multiple of 32); the GoPro frames are 16:9
    IMG_WIDTH = 640                    # network input width (multiple of 32)
    HEATMAP_STRIDE = 4                 # output stride of the decoder (4 = quarter resolution heatmaps)
    HEATMAP_SIGMA = 2.0                # standard deviation of the Gaussian peaks (heatmap pixels)

    # ---------------------------------------------------------------- model
    ENCODER = "resnet34"               # "resnet18" | "resnet34" | "resnet50" | "resnet101" | "resnext50_32x4d" | "wide_resnet50_2" | "convnext_tiny" | "convnext_small" | "convnext_base" | "efficientnet_b0".."efficientnet_b3" | "efficientnet_v2_s" | "mobilenet_v3_large" | "regnet_y_800mf" | "regnet_y_1_6gf" | "regnet_y_3_2gf" | "timm:<model name>" (multi-scale features)
    PRETRAINED = True                  # True: ImageNet weights from torchvision | False: random initialisation
    DECODER_TYPE = "fpn"               # "fpn": feature pyramid (lateral + top-down addition) | "unet": upsampling + concatenation with skip connections | "simple": three deconvolutions from stride 32 (simple baseline)
    DECODER_CHANNELS = 128             # channels of the decoder
    HEAD_CHANNELS = 128                # channels of the heatmap / segmentation head convolutions
    VISIBILITY_HIDDEN = 128            # hidden units of the visibility classifier
    DROPOUT = 0.1                      # dropout inside the visibility classifier
    CHECKPOINT_INIT = None             # checkpoint whose weights initialise the network (shape-compatible tensors only); None -> ImageNet encoder only

    # ---------------------------------------------------------------- loss
    HEATMAP_LOSS = "focal"             # "focal": CenterNet penalty-reduced focal loss | "mse": mean squared error on the sigmoid map | "bce": binary cross-entropy with logits | "awing": adaptive wing loss on the sigmoid map
    FOCAL_ALPHA = 2.0                  # focal loss exponent on the prediction
    FOCAL_BETA = 4.0                   # focal loss exponent on the Gaussian penalty reduction
    AWING_ALPHA = 2.1                  # adaptive wing loss: exponent alpha
    AWING_OMEGA = 14.0                 # adaptive wing loss: magnitude omega
    AWING_EPSILON = 1.0                # adaptive wing loss: curvature epsilon
    AWING_THETA = 0.5                  # adaptive wing loss: threshold theta between the log and the linear part
    HEATMAP_LOSS_WEIGHT = 1.0          # weight of the heatmap loss
    HIDDEN_KEYPOINT_WEIGHT = 0.5       # heatmap weight of hidden (occluded) keypoints; 1.0 treats them like visible ones, 0 ignores their position
    VISIBILITY_LOSS_WEIGHT = 0.5       # weight of the visibility cross-entropy
    VISIBILITY_CLASS_WEIGHTS = (1.0, 1.5, 1.0)  # class weights (out-of-frame, hidden, visible) of the visibility loss; None -> unweighted
    SEG_LOSS_WEIGHT = 0.5              # weight of the auxiliary segmentation loss (Dice + cross-entropy); 0 disables
    SEG_DICE_WEIGHT = 0.5              # share of the Dice term inside the segmentation loss (the rest is cross-entropy)
    COORD_LOSS_WEIGHT = 0.0            # weight of the soft-argmax coordinate loss (integral regression) on in-frame keypoints; 0 disables
    SOFTARGMAX_BETA = 1.0              # sharpness of the softmax over the heatmap logits in the coordinate loss

    # ---------------------------------------------------------------- augmentation (training only)
    AUG_SCALE = (0.7, 1.3)             # random scale range; (1.0, 1.0) disables
    AUG_ROTATION_DEG = 20.0            # max rotation in degrees (0 disables)
    AUG_TRANSLATE = 0.10               # max translation as a fraction of the image size (0 disables)
    AUG_HFLIP_PROB = 0.5               # probability of a horizontal flip (left and right hand classes are swapped accordingly)
    AUG_BRIGHTNESS = 0.3               # max relative brightness change
    AUG_CONTRAST = 0.3                 # max relative contrast change
    AUG_SATURATION = 0.3               # max relative saturation change
    AUG_HUE_DEG = 10.0                 # max hue shift in degrees
    AUG_BLUR_PROB = 0.2                # probability of a Gaussian blur
    AUG_NOISE_STD = 0.02               # standard deviation of additive Gaussian noise (0..1 scale); 0 disables
    AUG_ERASE_PROB = 0.3               # probability of erasing a random rectangle; visible keypoints inside become "hidden"
    AUG_ERASE_SCALE = (0.02, 0.15)     # area range of the erased rectangle (fraction of the image)

    # ---------------------------------------------------------------- optimisation
    OPTIMIZER = "adamw"                # "adamw" | "adam" | "nadam" | "radam" | "adamax" | "sgd" (Nesterov momentum) | "rmsprop" | "adagrad"
    LEARNING_RATE = 3e-4               # learning rate of the decoder and heads
    ENCODER_LR_MULT = 0.5              # learning-rate multiplier of the pre-trained encoder
    WEIGHT_DECAY = 1e-4                # weight decay
    MOMENTUM = 0.9                     # momentum for sgd / rmsprop
    BETAS = (0.9, 0.999)               # betas for adam / adamw
    SCHEDULER = "cosine"               # "cosine" | "cosine_restarts" | "linear" | "polynomial" | "step" | "multistep" | "exponential" | "onecycle" | "plateau" (ReduceLROnPlateau on the validation loss) | "none"; all except plateau / none use WARMUP_EPOCHS
    WARMUP_EPOCHS = 2                  # linear warm-up epochs
    MIN_LR = 1e-6                      # lowest learning rate of the decaying schedules
    RESTART_EPOCHS = 10                # cycle length of SCHEDULER = cosine_restarts
    STEP_SIZE_EPOCHS = 15              # epochs between decays of SCHEDULER = step
    LR_MILESTONES = (30, 45)           # epochs of the decays of SCHEDULER = multistep
    LR_GAMMA = 0.3                     # decay factor of step / multistep (per decay) and exponential (per epoch)
    POLY_POWER = 0.9                   # exponent of SCHEDULER = polynomial
    PLATEAU_PATIENCE = 5               # plateau scheduler patience (epochs)
    PLATEAU_FACTOR = 0.5               # plateau scheduler factor
    NUM_EPOCHS = 60                    # training epochs
    BATCH_SIZE = 8                     # images per optimisation step
    GRAD_ACCUM_STEPS = 1               # gradient accumulation steps
    GRAD_CLIP_NORM = 2.0               # gradient norm clipping; 0 disables
    EMA_DECAY = 0.998                  # weight EMA decay; 0 disables
    EARLY_STOPPING_PATIENCE = 15       # epochs without improvement before stopping; 0 disables
    SELECTION_METRIC = "hota"          # metric used to pick the best epoch: "hota" | "pck" | "val_loss"
    FREEZE_ENCODER_EPOCHS = 0          # initial epochs with a frozen encoder (0 = train everything from the start)

    # ---------------------------------------------------------------- decoding and tracking
    PEAK_THRESHOLD = 0.25              # minimum heatmap value for a keypoint to count as present
    PEAK_NMS_RADIUS = 3                # radius (heatmap pixels) of the non-maximum suppression window
    SUBPIXEL_WINDOW = 2                # radius (heatmap pixels) of the soft-argmax refinement window; 0 disables
    MAX_NEEDLE_INSTANCES = 2           # maximum number of needles per frame (the data contain at most two)
    NEEDLE_MIDPOINT_TOLERANCE = 0.08   # needle assembly: max deviation of the middle point from the end/tip midpoint, fraction of the image diagonal
    OUT_OF_FRAME_IF_NO_PEAK = True     # True: a keypoint without a peak above PEAK_THRESHOLD is flagged out-of-frame regardless of the visibility head
    TTA_HFLIP = False                  # True: average with the horizontally flipped frame (hand channels swapped back)
    TRACK_MAX_DISTANCE = 0.15          # needle association: max mean keypoint distance between frames, fraction of the image diagonal
    TRACK_MISS_WINDOW = 3              # frames a needle track survives without a match before it is closed
    TRACK_SMOOTHING = 0.0              # exponential smoothing factor of track coordinates (0 = none, 0.3 = light smoothing)
    USE_EMA_FOR_INFERENCE = True       # True: submissions use the EMA weights when EMA_DECAY > 0

    # ---------------------------------------------------------------- evaluation
    PCK_THRESHOLD = 0.05               # PCK radius as a fraction of the image diagonal
    HOTA_DISTANCE_NORM = 0.10          # keypoint distance (fraction of the diagonal) at which the HOTA similarity reaches zero
    HOTA_ALPHAS = 19                   # number of localisation thresholds (0.05 ... 0.95)
    EVAL_INCLUDE_HIDDEN = True         # True: hidden keypoints (annotated position) take part in PCK / HOTA | False: visible only
    INFER_BATCH_SIZE = 8               # frames per batch during inference
    SAVE_OPTIMIZER_STATE = False       # True: optimizer / scheduler state in every checkpoint | False: weights only
    SUBMISSION_DIRNAME = "mot"         # sub-folder name for the per-frame text files inside each submission folder

    # ---------------------------------------------------------------- GRM search (grm_* modes, see grm.py)
    GRM_DIR = None                     # folder that keeps the GRM state between phases; None -> <OUTPUT_ROOT>/grm_task3
    GRM_SEARCH_SPACE = {               # every key is a CONFIG entry, every value the list of candidates; one key is the GRM state, the others form the actions
        "BATCH_SIZE": [4, 8, 16],                                   # batch-size classes (GRM state of the OSS challenge entry)
        "ENCODER": ["resnet34", "resnet50", "convnext_tiny", "efficientnet_b2"],   # encoders
        "DECODER_TYPE": ["fpn", "unet", "simple"],                  # decoders
        "HEATMAP_LOSS": ["focal", "mse", "awing"],                  # heatmap losses
        "LEARNING_RATE": [1e-4, 3e-4, 1e-3],                        # learning rates of decoder and heads
        "OPTIMIZER": ["adamw", "radam"],                            # optimisers
        "SCHEDULER": ["cosine", "onecycle"],                        # learning-rate schedules
        "COORD_LOSS_WEIGHT": [0.0, 0.1],                            # coordinate (integral regression) loss
    }
    GRM_STATE_KEY = "BATCH_SIZE"       # search-space key used as GRM state by the mapping function: "BATCH_SIZE" (OSS / genomic entries) | "BACKBONE" (footstep entry) | any other key of GRM_SEARCH_SPACE
    GRM_STATE_BINS = None              # optional grouping of state values into classes, e.g. {"small": [2, 4], "large": [8]}; None -> one GRM state per value
    GRM_MAX_ACTIONS = 48               # largest number of actions per state; bigger products are replaced by a fixed random subset
    GRM_SIGNAL_PRESET = "oss"          # training-log signals: "oss" (early training dynamics vector) | "stepup" (mean loss + batch-loss spread) | "ogb" (mean score metric + mean error metric) | "custom" (GRM_SIGNALS)
    GRM_SIGNALS = ["mean:train_loss", "std_batch_loss", "best:selection_score"]  # signals for GRM_SIGNAL_PRESET = "custom": series:/mean:/last:/best:/worst:/slope:<column>, std_batch_loss, loss_drop, generalization_gap
    GRM_SCORE_METRIC = "val_hota"      # score column of the "ogb" preset (P1, higher is better)
    GRM_ERROR_METRIC = "val_loss"      # error column of the "ogb" preset (P2, lower is better)
    GRM_PROBE_EPOCHS = 4               # epochs of a search probe; the signals always use the first GRM_PROBE_EPOCHS epochs
    GRM_CALIBRATION_PROBES = 4         # calibration probes per GRM state (random actions); 10-15 per state gives more reliable estimators
    GRM_CALIBRATION_EPOCHS = 15        # epochs of a calibration probe (its end performance is the estimator target); None -> NUM_EPOCHS (train to completion)
    GRM_CALIBRATION_STATES = None      # restrict a grm_calibrate call to some states, e.g. ["2", "4"] to share the work between machines; None -> all states
    GRM_MERGE_DIRS = []                # GRM folders (same search space) whose probes grm_merge imports
    GRM_PROBE_DATA_FRACTION = 1.0      # share of the training videos used by probes (stratified subset, faster probes); 1.0 -> all
    GRM_TARGET = "best"                # true performance learned by the estimators: "best" | "last" | "mean_last_k" of the selection score over the calibration run
    GRM_TARGET_LAST_K = 3              # epochs averaged by GRM_TARGET = mean_last_k
    GRM_ESTIMATOR = "ridge"            # "ridge" (standardised, L2, intercept) | "linear" (Perf = sum w_i * P_i, no intercept) | "linear_bias" | "huber" (robust ridge) | "knn"
    GRM_ESTIMATOR_SCOPE = "per_state"  # "per_state": one estimator per GRM state | "global": one shared estimator | "shrinkage": per-state ridge pulled towards the global one
    GRM_MIN_PROBES_PER_STATE = 3       # states with fewer usable calibration probes fall back to the global estimator
    GRM_RIDGE_LAMBDA = 1.0             # L2 strength of the ridge / huber / shrinkage estimators
    GRM_KNN_K = 3                      # neighbours of the knn estimator
    GRM_REWARD_SOURCE = "estimator"    # "estimator": GRM reward from the estimators | "raw": plain RL baseline rewarded directly with GRM_RAW_REWARD
    GRM_RAW_REWARD = "last:selection_score"  # signal used as reward by GRM_REWARD_SOURCE = "raw"; prefix "-" for losses, e.g. "-mean:train_loss"
    GRM_REWARD_MACHINE = True          # True: explore / exploit reward machine with labelling function | False: reward = estimate
    GRM_RM_PATIENCE = 3                # plateau steps in a row that send the reward machine from exploit back to explore
    GRM_IMPROVEMENT_MARGIN = 0.05      # an estimate counts as "improved" when it beats the best one by this share of the calibration-target spread
    GRM_NOVELTY_BONUS = 0.25           # explore-state bonus (share of the target spread), divided by sqrt(visits of the pair)
    GRM_DIVERGENCE_FACTOR = 3.0        # a probe whose train loss grows by this factor (or becomes non-finite) is labelled "diverged"
    GRM_PENALTY_MARGIN = 1.0           # reward of invalid / diverged probes: worst calibration target minus this many target standard deviations
    GRM_STATE_SELECTION = "random"     # next GRM state: "random" | "round_robin" | "least_visited" | "greedy" (best max-Q, epsilon exploration)
    GRM_ACTION_POLICY = "epsilon_greedy"  # action choice: "epsilon_greedy" | "ucb" | "softmax"
    GRM_EPSILON = 0.3                  # exploration rate when the reward machine is off
    GRM_EPSILON_EXPLORE = 0.5          # exploration rate in the explore state of the reward machine
    GRM_EPSILON_EXPLOIT = 0.1          # exploration rate in the exploit state of the reward machine
    GRM_UCB_C = 1.0                    # exploration constant of GRM_ACTION_POLICY = ucb
    GRM_SOFTMAX_TEMPERATURE = 0.05     # temperature of GRM_ACTION_POLICY = softmax
    GRM_Q_UPDATE = "q_learning"        # "q_learning": Q += a (r + g max Q(s', .) - Q) | "bandit": Q += a (r - Q)
    GRM_Q_LEARNING_RATE = 0.5          # step size alpha of the Q update (GRM_ALPHA_SCHEDULE = constant)
    GRM_ALPHA_SCHEDULE = "constant"    # "constant": GRM_Q_LEARNING_RATE | "visits": 1 / visits of the pair (running average)
    GRM_Q_DISCOUNT = 0.9               # discount gamma of the Q-learning update
    GRM_Q_INIT = 0.0                   # initial Q-values
    GRM_SEARCH_STEPS = 6               # search steps run by one grm_search call
    GRM_MAX_SEARCH_STEPS = 60          # total search steps over all calls
    GRM_MAX_HOURS = None               # time budget of one grm_search call in hours; None -> no limit
    GRM_FINAL_SELECTION = "q_value"    # "q_value": best visited Q | "estimated": best mean estimate | "verify_top_k": short real training of the top candidates
    GRM_FINAL_INCLUDE_CALIBRATION = True  # True: calibration probes (with their true performance) also compete for the final choice
    GRM_VERIFY_TOP_K = 3               # candidates trained by GRM_FINAL_SELECTION = verify_top_k
    GRM_VERIFY_EPOCHS = 15             # epochs of a verification run
    GRM_FINAL_EPOCHS = None            # epochs of the final training of the chosen configuration; None -> NUM_EPOCHS


cv2.setNumThreads(1)  # the DataLoader workers parallelise already; OpenCV threads would only compete

# --------------------------------------------------------------------------------------
# Object and keypoint layout of the challenge (see the data description on the challenge Synapse wiki)
# --------------------------------------------------------------------------------------
CLASS_NAMES = ["left_hand", "right_hand", "scissors", "tweezers", "needle_holder", "needle"]
NUM_OBJECT_CLASSES = 6
KEYPOINTS_PER_CLASS = [6, 6, 3, 3, 3, 3]
KEYPOINT_NAMES = {
    0: ["thumb", "middle", "index", "ring", "pinky", "back_of_hand"],
    1: ["thumb", "middle", "index", "ring", "pinky", "back_of_hand"],
    2: ["left_sharp_point", "right_broad_point", "joint"],
    3: ["left_with_nub", "right_with_hole", "nub"],
    4: ["left", "right", "joint"],
    5: ["left_end", "right_tip", "middle"],
}
CHANNEL_OFFSET = [0, 6, 12, 15, 18, 21]          # first heatmap channel of every class
NUM_CHANNELS = sum(KEYPOINTS_PER_CLASS)          # 24 keypoint channels
LEFT_HAND_CLASS, RIGHT_HAND_CLASS, NEEDLE_CLASS = 0, 1, 5
FLIP_CHANNEL_ORDER = list(range(6, 12)) + list(range(0, 6)) + list(range(12, NUM_CHANNELS))   # swaps the hands
VIS_OUT, VIS_HIDDEN, VIS_VISIBLE = 0, 1, 2
SEG_IGNORE = 255                                 # segmentation target of frames without masks
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)
MASK_NAME_TO_CLASS = {"lefthand": 0, "left": 0, "righthand": 1, "right": 1, "scissors": 2, "scissor": 2,
                      "tweezers": 3, "tweezer": 3, "forceps": 3, "needleholder": 4, "needledriver": 4, "needle": 5}
VIDEO_EXTENSIONS = (".mp4", ".avi", ".mov", ".mkv")
FRAME_NAME_PATTERN = re.compile(r"^(?P<video>.+)_frame_(?P<id>\d+)$")
GRM_MODES = ("grm_calibrate", "grm_merge", "grm_fit", "grm_search", "grm_final", "grm_full", "grm_report")
LOG = logging.getLogger("task3")


# ======================================================================================
#                                  general utilities
# ======================================================================================
def set_seed(seed, deterministic):
    """Seed every random number generator used by the pipeline and set the cudnn mode."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = bool(deterministic)
    torch.backends.cudnn.benchmark = not deterministic


def worker_init_fn(worker_id):
    """Give every DataLoader worker its own, reproducible random state."""
    seed = (torch.initial_seed() + worker_id) % (2 ** 32)
    np.random.seed(seed)
    random.seed(seed)


def setup_logging(run_dir):
    """Log to the console and, when a run folder is given, to <run_dir>/train.log."""
    LOG.handlers.clear()
    LOG.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", "%Y-%m-%d %H:%M:%S")
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    LOG.addHandler(console)
    if run_dir is not None:
        os.makedirs(run_dir, exist_ok=True)
        file_handler = logging.FileHandler(os.path.join(run_dir, "train.log"), encoding="utf-8")
        file_handler.setFormatter(formatter)
        LOG.addHandler(file_handler)


def config_to_dict(cfg):
    """Return all upper-case CONFIG entries as a plain, JSON-friendly dictionary."""
    entries = OrderedDict()
    for key in dir(cfg):
        if key.isupper():
            value = getattr(cfg, key)
            entries[key] = list(value) if isinstance(value, tuple) else value
    return entries


def clone_config(cfg):
    """Independent namespace copy of a configuration (CONFIG is a class; deepcopy would alias it)."""
    return types.SimpleNamespace(**{key: copy.deepcopy(getattr(cfg, key)) for key in dir(cfg) if key.isupper()})


def apply_overrides(cfg, overrides):
    """Apply KEY=VALUE overrides from the command line; string values are parsed as Python literals."""
    for key, raw_value in overrides.items():
        if not hasattr(cfg, key):
            raise KeyError(f"Unknown CONFIG entry '{key}'")
        value = raw_value
        if isinstance(raw_value, str):
            try:
                value = ast.literal_eval(raw_value)
            except (ValueError, SyntaxError):
                value = raw_value  # plain string such as a path or a mode name
        setattr(cfg, key, value)


def check_cuda_build(cfg):
    """Warn when the CUDA build torch was compiled with differs from CONFIG.CUDA_BUILD."""
    built = torch.version.cuda
    if built is None:
        LOG.warning("This torch build has no CUDA support; the run will use the CPU.")
        return
    tag = "cu" + built.replace(".", "")[:3]
    if cfg.CUDA_BUILD != "cpu" and not tag.startswith(cfg.CUDA_BUILD[:4]):
        LOG.warning("CONFIG.CUDA_BUILD = %s but torch was built for CUDA %s (%s). "
                    "Make sure the driver of this machine supports the installed build.", cfg.CUDA_BUILD, built, tag)


def export_visible_gpus(cfg):
    """Expose only the GPUs listed in CONFIG.GPU_IDS (must run before the first CUDA call)."""
    os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str(gpu_id) for gpu_id in cfg.GPU_IDS)


def get_device(cfg):
    """Return the torch device of the run (cuda:0 = first id of GPU_IDS, or the CPU)."""
    if torch.cuda.is_available() and len(cfg.GPU_IDS) > 0:
        device = torch.device("cuda:0")
        names = ", ".join(torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count()))
        LOG.info("Using %d GPU(s): physical ids %s -> %s", torch.cuda.device_count(), cfg.GPU_IDS, names)
    else:
        device = torch.device("cpu")
        LOG.info("Using the CPU (no GPU requested or available)")
    return device


def make_grad_scaler(enabled):
    """Create a GradScaler that works across torch versions (torch.amp.GradScaler appeared in 2.3)."""
    if hasattr(torch, "amp") and hasattr(torch.amp, "GradScaler"):
        return torch.amp.GradScaler("cuda", enabled=enabled)
    return torch.cuda.amp.GradScaler(enabled=enabled)


def autocast_context(device, enabled):
    """
    Return the autocast context for mixed precision (a no-op context on the CPU or when disabled).
    torch.autocast appeared in torch 1.10; older builds only offer torch.cuda.amp.autocast without dtype.
    """
    if device.type != "cuda" or not enabled:
        return contextlib.nullcontext()
    if hasattr(torch, "autocast"):
        return torch.autocast(device_type="cuda", dtype=torch.float16)
    return torch.cuda.amp.autocast(enabled=True)


def load_checkpoint(path):
    """
    Load a checkpoint written by this repository onto the CPU.

    The files hold the configuration next to the weights, so they are read as full pickles
    (weights_only=False on torch >= 1.13, where the argument exists). Only load trusted files.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:                     # torch < 1.13 has no weights_only argument
        return torch.load(path, map_location="cpu")


def unwrap(model):
    """Return the underlying module of a DataParallel wrapper (or the model itself)."""
    return model.module if isinstance(model, nn.DataParallel) else model


def write_json(path, payload):
    """Write a JSON file with indentation (UTF-8)."""
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


def hungarian(cost):
    """Minimum-cost assignment of a (rows, cols) cost matrix; scipy when available, otherwise greedy."""
    cost = np.asarray(cost, dtype=np.float64)
    if cost.size == 0:
        return np.zeros(0, dtype=int), np.zeros(0, dtype=int)
    if linear_sum_assignment is not None:
        rows, cols = linear_sum_assignment(cost)
        return np.asarray(rows), np.asarray(cols)
    # greedy fallback: take the cheapest remaining pair until one side is exhausted
    pairs = sorted(((row, col) for row in range(cost.shape[0]) for col in range(cost.shape[1])),
                   key=lambda pair: cost[pair])
    rows, cols, used_rows, used_cols = [], [], set(), set()
    for row, col in pairs:
        if row in used_rows or col in used_cols:
            continue
        rows.append(row)
        cols.append(col)
        used_rows.add(row)
        used_cols.add(col)
    return np.asarray(rows, dtype=int), np.asarray(cols, dtype=int)


# ======================================================================================
#                                   annotations
# ======================================================================================
def split_frame_name(stem):
    """'<video>_frame_<id>' -> (video, id); raises on any other naming."""
    match = FRAME_NAME_PATTERN.match(stem)
    if not match:
        raise ValueError(f"File name '{stem}' does not follow the <video>_frame_<id> pattern")
    return match.group("video"), int(match.group("id"))


def parse_mot_file(path):
    """
    Read one keypoint file. Returns a list of objects:
        {"frame": int, "track_id": int, "class_id": int, "keypoints": (K, 3) float array [x, y, visibility]}
    Lines are 'frame, track, class, bx, by, bw, bh, x1, y1, v1, ...' (bounding box fields are -1).
    """
    objects = []
    with open(path, "r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            values = [float(token) for token in re.split(r"[,\s]+", line) if token != ""]
            if len(values) < 7 or (len(values) - 7) % 3 != 0:
                raise ValueError(f"{path}:{line_no}: expected 7 + 3*K values, got {len(values)}")
            class_id = int(values[2])
            if not 0 <= class_id < NUM_OBJECT_CLASSES:
                raise ValueError(f"{path}:{line_no}: class id {class_id} outside 0..5")
            keypoints = np.array(values[7:], dtype=np.float32).reshape(-1, 3)
            expected = KEYPOINTS_PER_CLASS[class_id]
            if keypoints.shape[0] != expected:
                raise ValueError(f"{path}:{line_no}: class {CLASS_NAMES[class_id]} needs {expected} keypoints, "
                                 f"found {keypoints.shape[0]}")
            objects.append({"frame": int(values[0]), "track_id": int(values[1]), "class_id": class_id,
                            "keypoints": keypoints})
    return objects


def mask_class_from_name(stem, frame_stem):
    """'<video>_frame_<id>_<object>[<n>]_mask' -> (class id, instance index) or (None, None) when unknown."""
    rest = stem[len(frame_stem):].strip("_")
    rest = re.sub(r"_?mask$", "", rest)
    normalised = re.sub(r"[^a-z0-9]", "", rest.lower())
    match = re.match(r"^([a-z]+)(\d*)$", normalised)
    if not match:
        return None, None
    name, instance = match.group(1), match.group(2)
    if name not in MASK_NAME_TO_CLASS:
        return None, None
    return MASK_NAME_TO_CLASS[name], int(instance) if instance else 0


def collect_mask_files(cfg):
    """Map every training frame stem to its [(mask path, class id)] list; unknown object names are reported."""
    masks_by_frame = defaultdict(list)
    unknown_names = Counter()
    if not (cfg.USE_MASKS and cfg.TRAIN_MASKS_DIR and os.path.isdir(cfg.TRAIN_MASKS_DIR)):
        return masks_by_frame
    for file_name in os.listdir(cfg.TRAIN_MASKS_DIR):
        if not file_name.lower().endswith(".png"):
            continue
        stem = os.path.splitext(file_name)[0]
        match = re.match(r"^(.+_frame_\d+)_", stem)
        if not match:
            continue
        frame_stem = match.group(1)
        class_id, _ = mask_class_from_name(stem, frame_stem)
        if class_id is None:
            unknown_names[stem[len(frame_stem):]] += 1
            continue
        masks_by_frame[frame_stem].append((os.path.join(cfg.TRAIN_MASKS_DIR, file_name), class_id))
    if unknown_names:
        LOG.warning("Mask files with unrecognised object names are ignored: %s", dict(unknown_names))
    return masks_by_frame


def list_training_samples(cfg):
    """Collect (frame, keypoint file, mask files) triples of the training set."""
    if not os.path.isdir(cfg.TRAIN_FRAMES_DIR):
        raise FileNotFoundError(f"Training frames folder not found: {cfg.TRAIN_FRAMES_DIR}")
    frame_files = sorted(name for name in os.listdir(cfg.TRAIN_FRAMES_DIR) if name.lower().endswith(".png"))
    if not frame_files:
        raise FileNotFoundError(f"No png frames in {cfg.TRAIN_FRAMES_DIR}")
    masks_by_frame = collect_mask_files(cfg)
    samples, dropped = [], 0
    for file_name in frame_files:
        stem = os.path.splitext(file_name)[0]
        video, frame_id = split_frame_name(stem)
        mot_path = os.path.join(cfg.TRAIN_MOT_DIR, stem + ".txt")
        if not os.path.isfile(mot_path):
            if cfg.REQUIRE_MOT_FOR_EVERY_FRAME:
                raise FileNotFoundError(f"Keypoint file missing for training frame {file_name}: {mot_path}")
            dropped += 1
            continue
        samples.append({"video": video, "frame_id": frame_id, "image": os.path.join(cfg.TRAIN_FRAMES_DIR, file_name),
                        "mot": mot_path, "masks": masks_by_frame.get(stem, [])})
    if dropped:
        LOG.warning("%d training frames without keypoint file were dropped", dropped)
    with_masks = sum(1 for sample in samples if sample["masks"])
    LOG.info("Training set: %d frames from %d videos, %d frames with masks", len(samples),
             len({sample["video"] for sample in samples}), with_masks)
    return samples


def png_files_of(entry_path):
    """All png files of a folder (sorted), or the entry itself when it is a png file, or nothing."""
    if os.path.isdir(entry_path):
        return [os.path.join(entry_path, name) for name in sorted(os.listdir(entry_path))
                if name.lower().endswith(".png")]
    return [entry_path] if entry_path.lower().endswith(".png") else []


def list_validation_samples(cfg):
    """Collect the validation frames (one folder per video) and their keypoint files."""
    if not os.path.isdir(cfg.VAL_FRAMES_DIR):
        raise FileNotFoundError(f"Validation frames folder not found: {cfg.VAL_FRAMES_DIR}")
    samples = []
    for entry in sorted(os.listdir(cfg.VAL_FRAMES_DIR)):
        for path in png_files_of(os.path.join(cfg.VAL_FRAMES_DIR, entry)):
            stem = os.path.splitext(os.path.basename(path))[0]
            video, frame_id = split_frame_name(stem)
            mot_path = os.path.join(cfg.VAL_MOT_DIR, stem + ".txt")
            if not os.path.isfile(mot_path):
                raise FileNotFoundError(f"Keypoint file missing for validation frame {path}: {mot_path}")
            samples.append({"video": video, "frame_id": frame_id, "image": path, "mot": mot_path, "masks": []})
    if not samples:
        raise FileNotFoundError(f"No validation frames found under {cfg.VAL_FRAMES_DIR}")
    samples.sort(key=lambda sample: (sample["video"], sample["frame_id"]))
    LOG.info("Validation set: %d frames from %d videos", len(samples), len({sample["video"] for sample in samples}))
    return samples


def verify_samples(samples, description):
    """
    Open every image, keypoint file and mask once and store the frame size in the sample.
    Any failure stops the program: training on a silently shrunken dataset is worse than an error.
    """
    failures = []
    for sample in tqdm(samples, desc=f"data check: {description}", unit="frame"):
        try:
            image = cv2.imread(sample["image"], cv2.IMREAD_COLOR)
            if image is None or image.size == 0:
                raise RuntimeError("image cannot be read")
            sample["height"], sample["width"] = image.shape[:2]
            if sample.get("mot"):
                parse_mot_file(sample["mot"])
            for path, _ in sample.get("masks", []):
                mask = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
                if mask is None or mask.size == 0:
                    raise RuntimeError(f"mask cannot be read: {path}")
        except Exception as exc:  # every failure is reported, then the run stops
            failures.append((sample["image"], str(exc)))
    if failures:
        for path, reason in failures[:20]:
            LOG.error("  %s -> %s", path, reason)
        raise RuntimeError(f"{len(failures)} of {len(samples)} samples failed the data check; the run is stopped")
    LOG.info("All %d samples of '%s' are readable", len(samples), description)


def read_frame_sizes(samples):
    """Store height / width of every frame in the samples (needed for decoding) without the full data check."""
    for sample in samples:
        image = cv2.imread(sample["image"], cv2.IMREAD_COLOR)
        if image is None:
            raise RuntimeError(f"Frame could not be read: {sample['image']}")
        sample["height"], sample["width"] = image.shape[:2]


def objects_to_channels(objects):
    """
    Spread the annotated objects of one frame over the 24 keypoint channels.
    Returns (keypoints (24, 3) with visibility -1 for unannotated channels, second needle (3, 3) or None).
    """
    keypoints = np.zeros((NUM_CHANNELS, 3), dtype=np.float32)
    keypoints[:, 2] = -1.0
    second_needle = None
    needles_seen = 0
    for obj in sorted(objects, key=lambda item: (item["class_id"], item["track_id"])):
        class_id, offset = obj["class_id"], CHANNEL_OFFSET[obj["class_id"]]
        if class_id == NEEDLE_CLASS:
            needles_seen += 1
            if needles_seen == 2:
                second_needle = obj["keypoints"].copy()
                continue
            if needles_seen > 2:
                continue
        keypoints[offset:offset + KEYPOINTS_PER_CLASS[class_id]] = obj["keypoints"]
    return keypoints, second_needle


# ======================================================================================
#                                 dataset and augmentation
# ======================================================================================
def gaussian_heatmaps(points, visibility, height, width, sigma):
    """(K, 3) points in heatmap coordinates -> (K, height, width) maps with a peak of 1 at annotated locations."""
    maps = np.zeros((points.shape[0], height, width), dtype=np.float32)
    grid_y, grid_x = np.mgrid[0:height, 0:width]
    for channel in range(points.shape[0]):
        if visibility[channel] not in (VIS_HIDDEN, VIS_VISIBLE):
            continue
        centre_x, centre_y = int(round(points[channel, 0])), int(round(points[channel, 1]))
        if not (0 <= centre_x < width and 0 <= centre_y < height):
            continue
        maps[channel] = np.exp(-((grid_x - centre_x) ** 2 + (grid_y - centre_y) ** 2) / (2 * sigma ** 2))
    return maps


def to_heatmap_coordinates(points, stride):
    """Copy of (K, 3) input-pixel points with x, y converted to heatmap pixel coordinates."""
    converted = points.copy()
    converted[:, :2] = (converted[:, :2] + 0.5) / stride - 0.5
    return converted


class KeypointDataset(Dataset):
    """
    One training / validation frame -> network input and targets.

    Returns a dictionary with
        image         (3, H, W) normalised float tensor
        heatmaps      (24, H/s, W/s) Gaussian targets
        heat_weights  (24,) per-channel loss weight (0 = channel not annotated in this frame)
        coords        (24, 2) keypoint positions in heatmap pixels; coord_weights (24,) their loss weights
        vis           (24,) visibility class, -1 = not annotated
        seg           (H, W) long, 0 background / 1..6 object class / 255 ignore (no masks)
        index, orig_h, orig_w   sample identity and original frame size (for decoding)
    """

    def __init__(self, samples, cfg, train):
        """Store the samples and configuration; `train` switches the augmentation on."""
        self.samples, self.cfg, self.train = samples, cfg, train
        self.mean = np.array(IMAGENET_MEAN, dtype=np.float32).reshape((1, 1, 3))
        self.std = np.array(IMAGENET_STD, dtype=np.float32).reshape((1, 1, 3))

    def __len__(self):
        """Number of frames."""
        return len(self.samples)

    # ---------------------------------------------------------------- geometry
    def _affine(self, height, width, rng):
        """Augmentation + resize as one 2x3 matrix mapping original pixels to network pixels."""
        cfg = self.cfg
        scale_x, scale_y = cfg.IMG_WIDTH / width, cfg.IMG_HEIGHT / height
        resize = np.array([[scale_x, 0, 0], [0, scale_y, 0], [0, 0, 1]], dtype=np.float64)
        if not self.train:
            return resize[:2]
        scale = rng.uniform(*cfg.AUG_SCALE)
        angle = rng.uniform(-cfg.AUG_ROTATION_DEG, cfg.AUG_ROTATION_DEG)
        shift = rng.uniform(-cfg.AUG_TRANSLATE, cfg.AUG_TRANSLATE, size=2) * np.array([cfg.IMG_WIDTH, cfg.IMG_HEIGHT])
        centre = (cfg.IMG_WIDTH / 2, cfg.IMG_HEIGHT / 2)
        rotation = np.vstack([cv2.getRotationMatrix2D(centre, angle, scale), [0, 0, 1]])
        rotation[0, 2] += shift[0]
        rotation[1, 2] += shift[1]
        return (rotation @ resize)[:2]

    def _photometric(self, image, rng):
        """Colour jitter, blur and noise on a float RGB image in [0, 1]."""
        cfg = self.cfg
        if cfg.AUG_BRIGHTNESS > 0:
            image = image * (1 + rng.uniform(-cfg.AUG_BRIGHTNESS, cfg.AUG_BRIGHTNESS))
        if cfg.AUG_CONTRAST > 0:
            mean = image.mean()
            image = (image - mean) * (1 + rng.uniform(-cfg.AUG_CONTRAST, cfg.AUG_CONTRAST)) + mean
        if cfg.AUG_SATURATION > 0 or cfg.AUG_HUE_DEG > 0:
            hsv = cv2.cvtColor(np.clip(image, 0, 1).astype(np.float32), cv2.COLOR_RGB2HSV)
            hsv[..., 0] = (hsv[..., 0] + rng.uniform(-cfg.AUG_HUE_DEG, cfg.AUG_HUE_DEG)) % 360.0
            hsv[..., 1] = np.clip(hsv[..., 1] * (1 + rng.uniform(-cfg.AUG_SATURATION, cfg.AUG_SATURATION)), 0, 1)
            image = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        if cfg.AUG_BLUR_PROB > 0 and rng.random() < cfg.AUG_BLUR_PROB:
            kernel = int(rng.choice([3, 5]))
            image = cv2.GaussianBlur(image, (kernel, kernel), 0)
        if cfg.AUG_NOISE_STD > 0:
            image = image + rng.normal(0, cfg.AUG_NOISE_STD, size=image.shape).astype(np.float32)
        return np.clip(image, 0, 1).astype(np.float32)

    def _random_erase(self, image, keypoints, rng):
        """Erase a random rectangle; visible keypoints inside it become hidden (the object is still there)."""
        cfg = self.cfg
        area = rng.uniform(*cfg.AUG_ERASE_SCALE) * cfg.IMG_WIDTH * cfg.IMG_HEIGHT
        ratio = math.exp(rng.uniform(math.log(0.5), math.log(2.0)))
        erase_w = int(min(cfg.IMG_WIDTH, math.sqrt(area * ratio)))
        erase_h = int(min(cfg.IMG_HEIGHT, math.sqrt(area / ratio)))
        x0 = int(rng.integers(0, cfg.IMG_WIDTH - erase_w + 1))
        y0 = int(rng.integers(0, cfg.IMG_HEIGHT - erase_h + 1))
        image[y0:y0 + erase_h, x0:x0 + erase_w] = image.mean(axis=(0, 1))
        covered = ((keypoints[:, 0] >= x0) & (keypoints[:, 0] < x0 + erase_w) & (keypoints[:, 1] >= y0)
                   & (keypoints[:, 1] < y0 + erase_h) & (keypoints[:, 2] == VIS_VISIBLE))
        keypoints[covered, 2] = VIS_HIDDEN
        return image, keypoints

    def _load_segmentation(self, sample, height, width):
        """Combine the instance masks of a frame into one label map (0 background, 1..6 classes), or None."""
        if not (self.cfg.USE_MASKS and sample.get("masks")):
            return None
        seg = np.zeros((height, width), dtype=np.uint8)
        for path, class_id in sorted(sample["masks"], key=lambda item: -item[1]):   # hands last: they occlude tools
            mask = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
            if mask is None:
                raise RuntimeError(f"Mask could not be read: {path}")
            if mask.shape != (height, width):
                mask = cv2.resize(mask, (width, height), interpolation=cv2.INTER_NEAREST)
            seg[mask > 127] = class_id + 1
        return seg

    @staticmethod
    def _flip_horizontally(image, keypoints, second_needle, seg, width):
        """Mirror the frame and swap the left / right hand channels and segmentation classes."""
        image = np.ascontiguousarray(image[:, ::-1])
        keypoints[:, 0] = (width - 1) - keypoints[:, 0]
        keypoints = keypoints[FLIP_CHANNEL_ORDER]
        if second_needle is not None:
            second_needle[:, 0] = (width - 1) - second_needle[:, 0]
        if seg is not None:
            seg = np.ascontiguousarray(seg[:, ::-1])
            swapped = seg.copy()
            swapped[seg == LEFT_HAND_CLASS + 1] = RIGHT_HAND_CLASS + 1
            swapped[seg == RIGHT_HAND_CLASS + 1] = LEFT_HAND_CLASS + 1
            seg = swapped
        return image, keypoints, second_needle, seg

    def _transform_points(self, points, matrix):
        """Apply the 2x3 affine matrix to (K, 3) points; annotated points leaving the frame become out-of-frame."""
        cfg = self.cfg
        homogeneous = np.hstack([points[:, :2], np.ones((points.shape[0], 1), dtype=np.float32)])
        transformed = points.copy()
        transformed[:, :2] = homogeneous @ matrix.T
        inside = ((transformed[:, 0] >= 0) & (transformed[:, 0] < cfg.IMG_WIDTH)
                  & (transformed[:, 1] >= 0) & (transformed[:, 1] < cfg.IMG_HEIGHT))
        annotated = transformed[:, 2] >= 0
        transformed[annotated & ~inside, 2] = VIS_OUT
        return transformed

    # ---------------------------------------------------------------- item
    def __getitem__(self, index):
        """Load one frame with its annotations, augment (training only) and build the network targets."""
        cfg, sample = self.cfg, self.samples[index]
        rng = np.random.default_rng(None if self.train else cfg.SEED + index)
        bgr = cv2.imread(sample["image"], cv2.IMREAD_COLOR)
        if bgr is None or bgr.size == 0:
            raise RuntimeError(f"Frame could not be read: {sample['image']}")
        image = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        height, width = image.shape[:2]

        # ---- annotations in original pixel coordinates
        objects = parse_mot_file(sample["mot"]) if sample.get("mot") else []
        keypoints, second_needle = objects_to_channels(objects)
        seg = self._load_segmentation(sample, height, width)
        if self.train and rng.random() < cfg.AUG_HFLIP_PROB:
            image, keypoints, second_needle, seg = self._flip_horizontally(image, keypoints, second_needle, seg, width)

        # ---- affine (augmentation + resize) applied to image, masks and keypoints alike
        matrix = self._affine(height, width, rng)
        image = cv2.warpAffine(image, matrix, (cfg.IMG_WIDTH, cfg.IMG_HEIGHT), flags=cv2.INTER_LINEAR,
                               borderMode=cv2.BORDER_CONSTANT)
        if seg is not None:
            seg = cv2.warpAffine(seg, matrix, (cfg.IMG_WIDTH, cfg.IMG_HEIGHT), flags=cv2.INTER_NEAREST,
                                 borderMode=cv2.BORDER_CONSTANT)
        keypoints = self._transform_points(keypoints, matrix)
        if second_needle is not None:
            second_needle = self._transform_points(second_needle, matrix)

        image = image.astype(np.float32) / 255.0
        if self.train:
            image = self._photometric(image, rng)
            if cfg.AUG_ERASE_PROB > 0 and rng.random() < cfg.AUG_ERASE_PROB:
                image, keypoints = self._random_erase(image, keypoints, rng)
        image = (image - self.mean) / self.std

        # ---- targets at heatmap resolution
        stride = cfg.HEATMAP_STRIDE
        map_height, map_width = cfg.IMG_HEIGHT // stride, cfg.IMG_WIDTH // stride
        heatmaps = gaussian_heatmaps(to_heatmap_coordinates(keypoints, stride), keypoints[:, 2], map_height, map_width,
                                     cfg.HEATMAP_SIGMA)
        visibility = keypoints[:, 2].astype(np.int64)
        if second_needle is not None:                       # second needle: extra peaks in the needle channels
            offset = CHANNEL_OFFSET[NEEDLE_CLASS]
            extra = gaussian_heatmaps(to_heatmap_coordinates(second_needle, stride), second_needle[:, 2], map_height,
                                      map_width, cfg.HEATMAP_SIGMA)
            heatmaps[offset:offset + 3] = np.maximum(heatmaps[offset:offset + 3], extra)
            # the visibility channel reports the better-seen needle
            second_visibility = second_needle[:, 2].astype(np.int64)
            visibility[offset:offset + 3] = np.maximum(visibility[offset:offset + 3], second_visibility)
        coords = to_heatmap_coordinates(keypoints, stride)[:, :2]
        coord_weights = np.isin(keypoints[:, 2], (VIS_HIDDEN, VIS_VISIBLE)).astype(np.float32)
        if second_needle is not None:                       # two peaks per needle channel: no single target position
            coord_weights[CHANNEL_OFFSET[NEEDLE_CLASS]:CHANNEL_OFFSET[NEEDLE_CLASS] + 3] = 0.0
        hidden_or_full = np.where(keypoints[:, 2] == VIS_HIDDEN, cfg.HIDDEN_KEYPOINT_WEIGHT, 1.0)
        heat_weights = np.where(keypoints[:, 2] < 0, 0.0, hidden_or_full).astype(np.float32)
        if seg is None:
            seg = np.full((cfg.IMG_HEIGHT, cfg.IMG_WIDTH), SEG_IGNORE, dtype=np.int64)

        return {
            "image": torch.from_numpy(np.ascontiguousarray(image.transpose(2, 0, 1))),
            "heatmaps": torch.from_numpy(heatmaps),
            "heat_weights": torch.from_numpy(heat_weights),
            "coords": torch.from_numpy(np.ascontiguousarray(coords, dtype=np.float32)),
            "coord_weights": torch.from_numpy(coord_weights),
            "vis": torch.from_numpy(visibility),
            "seg": torch.from_numpy(seg.astype(np.int64)),
            "index": index,
            "orig_h": height, "orig_w": width,
        }


def make_loader(samples, cfg, train, batch_size=None):
    """Create the DataLoader of a sample list (shuffling and persistent workers for training only)."""
    dataset = KeypointDataset(samples, cfg, train=train)
    kwargs = {"batch_size": batch_size or cfg.BATCH_SIZE, "shuffle": train, "num_workers": cfg.NUM_WORKERS,
              "pin_memory": cfg.PIN_MEMORY and torch.cuda.is_available(), "drop_last": False,
              "worker_init_fn": worker_init_fn}
    if cfg.NUM_WORKERS > 0:
        kwargs["prefetch_factor"] = cfg.PREFETCH_FACTOR
        kwargs["persistent_workers"] = bool(train)   # evaluation loaders are short-lived
    return DataLoader(dataset, **kwargs)


# ======================================================================================
#                                        model
# ======================================================================================
RESNET_ENCODERS = {
    "resnet18": "ResNet18_Weights", "resnet34": "ResNet34_Weights", "resnet50": "ResNet50_Weights",
    "resnet101": "ResNet101_Weights", "resnext50_32x4d": "ResNeXt50_32X4D_Weights",
    "wide_resnet50_2": "Wide_ResNet50_2_Weights",
}
SEQUENTIAL_ENCODERS = {
    "convnext_tiny": "ConvNeXt_Tiny_Weights", "convnext_small": "ConvNeXt_Small_Weights",
    "convnext_base": "ConvNeXt_Base_Weights", "efficientnet_b0": "EfficientNet_B0_Weights",
    "efficientnet_b1": "EfficientNet_B1_Weights", "efficientnet_b2": "EfficientNet_B2_Weights",
    "efficientnet_b3": "EfficientNet_B3_Weights", "efficientnet_v2_s": "EfficientNet_V2_S_Weights",
    "mobilenet_v3_large": "MobileNet_V3_Large_Weights", "regnet_y_800mf": "RegNet_Y_800MF_Weights",
    "regnet_y_1_6gf": "RegNet_Y_1_6GF_Weights", "regnet_y_3_2gf": "RegNet_Y_3_2GF_Weights",
}
DECODER_TYPES = ("fpn", "unet", "simple")


def create_torchvision_model(namespace, name, weights_enum, weights_tag, pretrained):
    """
    Instantiate a torchvision model with or without pre-trained weights. torchvision >= 0.13 selects
    weights through enums (e.g. ResNet34_Weights.DEFAULT); older releases use `pretrained=`.
    """
    if not hasattr(namespace, name):
        raise ValueError(f"ENCODER '{name}' is not available in this torchvision version")
    constructor = getattr(namespace, name)
    enum = getattr(namespace, weights_enum, None)
    if enum is not None:
        return constructor(weights=getattr(enum, weights_tag) if pretrained else None)
    return constructor(pretrained=pretrained)


def split_by_stride(modules):
    """
    Split a list of modules that run one after the other into stem + four stages ending at strides
    4, 8, 16 and 32 (found with a dummy forward pass); modules after the stride-32 stage are dropped.
    """
    probe = torch.zeros(1, 3, 128, 128)
    last_index = {}
    with torch.no_grad():
        current = probe
        for index, module in enumerate(modules):
            current = module(current)
            stride = probe.shape[-1] // current.shape[-1]
            if stride in (4, 8, 16, 32):
                last_index[stride] = index
    if sorted(last_index) != [4, 8, 16, 32]:
        raise ValueError("The encoder does not provide stride 4, 8, 16 and 32 feature maps "
                         f"(found {sorted(last_index)})")
    bounds = [last_index[stride] for stride in (4, 8, 16, 32)]
    stem = nn.Sequential(*modules[:bounds[0] + 1])
    stages = [nn.Identity()] + [nn.Sequential(*modules[bounds[i] + 1:bounds[i + 1] + 1]) for i in range(3)]
    return stem, nn.ModuleList(stages)


class Encoder(nn.Module):
    """ImageNet encoder (torchvision or timm) returning feature maps at strides 4, 8, 16 and 32."""

    def __init__(self, cfg):
        """Build the backbone selected by CONFIG.ENCODER and split it into a stem and four stages."""
        super().__init__()
        name = cfg.ENCODER
        self.timm_model = None
        if name.startswith("timm:"):
            try:
                import timm  # pylint: disable=import-error
            except ImportError as exc:
                raise ImportError("ENCODER = 'timm:<name>' needs `pip install timm`") from exc
            self.timm_model = timm.create_model(name[len("timm:"):], pretrained=cfg.PRETRAINED, features_only=True,
                                                out_indices=(1, 2, 3, 4))
            self.channels = list(self.timm_model.feature_info.channels())
            return
        from torchvision import models
        if name in RESNET_ENCODERS:
            backbone = create_torchvision_model(models, name, RESNET_ENCODERS[name], "DEFAULT", cfg.PRETRAINED)
            self.stem = nn.Sequential(backbone.conv1, backbone.bn1, backbone.relu, backbone.maxpool)
            self.stages = nn.ModuleList([backbone.layer1, backbone.layer2, backbone.layer3, backbone.layer4])
        elif name in SEQUENTIAL_ENCODERS:
            backbone = create_torchvision_model(models, name, SEQUENTIAL_ENCODERS[name], "DEFAULT", cfg.PRETRAINED)
            if name.startswith("regnet"):
                modules = [backbone.stem] + list(backbone.trunk_output)
            elif name.startswith(("efficientnet", "mobilenet")):
                modules = list(backbone.features)[:-1]       # the last block is the 1x1 classifier expansion
            else:
                modules = list(backbone.features)
            self.stem, self.stages = split_by_stride(modules)
        else:
            raise ValueError(f"Unknown ENCODER '{name}'; choose from {sorted(RESNET_ENCODERS)} + "
                             f"{sorted(SEQUENTIAL_ENCODERS)} or 'timm:<model name>'")
        was_training = self.training
        self.eval()
        with torch.no_grad():
            self.channels = [feature.shape[1] for feature in self._forward_stages(torch.zeros(1, 3, 128, 128))]
        self.train(was_training)

    def _forward_stages(self, images):
        """Run stem and stages, collecting the four stage outputs."""
        features = []
        current = self.stem(images)
        for stage in self.stages:
            current = stage(current)
            features.append(current)
        return features

    def forward(self, images):
        """(B, 3, H, W) -> list of four feature maps at strides 4, 8, 16, 32."""
        if self.timm_model is not None:
            return list(self.timm_model(images))
        return self._forward_stages(images)


def conv_bn_relu(in_channels, out_channels):
    """3x3 convolution + batch norm + ReLU."""
    return nn.Sequential(nn.Conv2d(in_channels, out_channels, 3, padding=1), nn.BatchNorm2d(out_channels),
                         nn.ReLU(inplace=True))


class FPNDecoder(nn.Module):
    """Top-down feature pyramid: lateral 1x1 convolutions, upsampling + addition, 3x3 smoothing; stride-4 output."""

    def __init__(self, encoder_channels, channels):
        """One lateral convolution per encoder level and one smoothing block per merge."""
        super().__init__()
        self.lateral = nn.ModuleList([nn.Conv2d(width, channels, 1) for width in encoder_channels])
        self.smooth = nn.ModuleList([conv_bn_relu(channels, channels) for _ in range(3)])

    def forward(self, features):
        """Four encoder maps -> (B, channels, H/4, W/4)."""
        pyramid = self.lateral[3](features[3])
        for level in (2, 1, 0):
            upsampled = F.interpolate(pyramid, size=features[level].shape[-2:], mode="bilinear", align_corners=False)
            pyramid = self.smooth[level](upsampled + self.lateral[level](features[level]))
        return pyramid


class UNetDecoder(nn.Module):
    """U-Net style decoder: upsampling, concatenation with the skip connection and two 3x3 blocks per level."""

    def __init__(self, encoder_channels, channels):
        """Bottleneck projection and one fusion block per skip connection."""
        super().__init__()
        self.bottleneck = conv_bn_relu(encoder_channels[3], channels)
        self.fuse = nn.ModuleList([nn.Sequential(conv_bn_relu(channels + encoder_channels[level], channels),
                                                 conv_bn_relu(channels, channels)) for level in range(3)])

    def forward(self, features):
        """Four encoder maps -> (B, channels, H/4, W/4)."""
        decoded = self.bottleneck(features[3])
        for level in (2, 1, 0):
            upsampled = F.interpolate(decoded, size=features[level].shape[-2:], mode="bilinear", align_corners=False)
            decoded = self.fuse[level](torch.cat([upsampled, features[level]], dim=1))
        return decoded


class SimpleDecoder(nn.Module):
    """Three transposed convolutions on the stride-32 map (the 'simple baseline' head of pose estimation)."""

    def __init__(self, encoder_channels, channels):
        """Deconvolution blocks from stride 32 to stride 4."""
        super().__init__()
        layers, width = [], encoder_channels[3]
        for _ in range(3):
            layers += [nn.ConvTranspose2d(width, channels, kernel_size=4, stride=2, padding=1, bias=False),
                       nn.BatchNorm2d(channels), nn.ReLU(inplace=True)]
            width = channels
        self.deconv = nn.Sequential(*layers)

    def forward(self, features):
        """Four encoder maps (only the deepest is used) -> (B, channels, H/4, W/4)."""
        decoded = self.deconv(features[3])
        if decoded.shape[-2:] != features[0].shape[-2:]:
            decoded = F.interpolate(decoded, size=features[0].shape[-2:], mode="bilinear", align_corners=False)
        return decoded


class KeypointNet(nn.Module):
    """Encoder + decoder (FPN / U-Net / simple) + heatmap, segmentation and visibility heads."""

    def __init__(self, cfg):
        """Build the encoder, the decoder selected by DECODER_TYPE and the three heads."""
        super().__init__()
        self.cfg = cfg
        self.encoder = Encoder(cfg)
        decoder_ch, head_ch = cfg.DECODER_CHANNELS, cfg.HEAD_CHANNELS
        decoders = {"fpn": FPNDecoder, "unet": UNetDecoder, "simple": SimpleDecoder}
        if cfg.DECODER_TYPE not in decoders:
            raise ValueError(f"Unknown DECODER_TYPE '{cfg.DECODER_TYPE}'; choose from {DECODER_TYPES}")
        self.decoder = decoders[cfg.DECODER_TYPE](self.encoder.channels, decoder_ch)
        self.heat_head = nn.Sequential(conv_bn_relu(decoder_ch, head_ch), nn.Conv2d(head_ch, NUM_CHANNELS, 1))
        self.seg_head = nn.Sequential(conv_bn_relu(decoder_ch, head_ch), nn.Conv2d(head_ch, NUM_OBJECT_CLASSES + 1, 1))
        self.vis_head = nn.Sequential(nn.Linear(2 * decoder_ch + 1, cfg.VISIBILITY_HIDDEN), nn.GELU(),
                                      nn.Dropout(cfg.DROPOUT), nn.Linear(cfg.VISIBILITY_HIDDEN, 3))
        # the heatmap bias starts negative so that the focal loss does not explode on the empty maps
        nn.init.constant_(self.heat_head[-1].bias, -2.19)

    def forward(self, images):
        """
        (B, 3, H, W) -> {"heat": (B, 24, H/4, W/4) logits, "seg": (B, 7, H/4, W/4) logits, "vis": (B, 24, 3) logits}.
        The visibility logits come from attention pooling of the decoder features under every keypoint heatmap.
        """
        decoded = self.decoder(self.encoder(images))
        heat = self.heat_head(decoded)                                              # (B, 24, h, w)
        seg = self.seg_head(decoded)                                                # (B, 7, h, w)
        attention = torch.softmax(heat.flatten(2).float(), dim=-1)                  # (B, 24, h*w)
        pooled = torch.einsum("bkn,bcn->bkc", attention, decoded.flatten(2).float())  # (B, 24, d)
        global_feat = decoded.float().mean(dim=(2, 3)).unsqueeze(1).expand(-1, NUM_CHANNELS, -1)
        max_heat = torch.sigmoid(heat.float()).flatten(2).max(dim=-1).values.unsqueeze(-1)
        vis = self.vis_head(torch.cat([pooled, global_feat, max_heat], dim=-1))     # (B, 24, 3)
        return {"heat": heat, "seg": seg, "vis": vis}


class ModelEMA:
    """Exponential moving average of the model weights, evaluated as a second model."""

    def __init__(self, model, decay):
        """Copy the model as the EMA shadow and freeze its parameters."""
        self.decay = decay
        self.ema = copy.deepcopy(unwrap(model)).eval()
        for parameter in self.ema.parameters():
            parameter.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        """Move the shadow weights towards the current model weights (buffers are copied)."""
        source = unwrap(model).state_dict()
        for key, value in self.ema.state_dict().items():
            if value.dtype.is_floating_point:
                value.mul_(self.decay).add_(source[key].detach(), alpha=1.0 - self.decay)
            else:
                value.copy_(source[key])


# ======================================================================================
#                                        losses
# ======================================================================================
def soft_argmax(logits, beta):
    """Expected (x, y) heatmap position of every channel under softmax(beta * logits); (B, K, 2)."""
    batch, channels, height, width = logits.shape
    probs = torch.softmax(beta * logits.float().flatten(2), dim=-1).view(batch, channels, height, width)
    grid_x = torch.arange(width, device=logits.device, dtype=torch.float32)
    grid_y = torch.arange(height, device=logits.device, dtype=torch.float32)
    return torch.stack([(probs.sum(dim=2) * grid_x).sum(dim=-1), (probs.sum(dim=3) * grid_y).sum(dim=-1)], dim=-1)


class KeypointLoss(nn.Module):
    """
    Heatmap loss + visibility cross-entropy + auxiliary segmentation loss + optional coordinate
    (integral regression) loss; forward() returns (total, parts).
    """

    def __init__(self, cfg):
        """Register the visibility class weights."""
        super().__init__()
        self.cfg = cfg
        weights = cfg.VISIBILITY_CLASS_WEIGHTS
        self.register_buffer("vis_weights", torch.tensor(weights, dtype=torch.float32) if weights else torch.ones(3))

    def heatmap_loss(self, logits, target, channel_weights):
        """
        Focal / MSE / BCE / adaptive-wing heatmap loss; `channel_weights` (B, 24) weight each keypoint channel
        of each frame (0 for channels that are not annotated).
        """
        cfg = self.cfg
        logits = logits.float()
        weights = channel_weights.view(channel_weights.shape[0], channel_weights.shape[1], 1, 1)
        num_pixels = target.shape[-1] * target.shape[-2]
        if cfg.HEATMAP_LOSS == "mse":
            squared_error = (torch.sigmoid(logits) - target) ** 2
            return (squared_error * weights).sum() / weights.sum().clamp_min(1.0) / num_pixels
        if cfg.HEATMAP_LOSS == "bce":
            bce = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
            return (bce * weights).sum() / weights.sum().clamp_min(1.0) / num_pixels
        if cfg.HEATMAP_LOSS == "awing":
            return (self.adaptive_wing(torch.sigmoid(logits), target) * weights).sum() / \
                weights.sum().clamp_min(1.0) / num_pixels
        if cfg.HEATMAP_LOSS != "focal":
            raise ValueError(f"Unknown HEATMAP_LOSS '{cfg.HEATMAP_LOSS}'")
        predicted = torch.sigmoid(logits).clamp(1e-4, 1 - 1e-4)
        positive = (target >= 0.999).float()
        negative_weights = (1 - target).clamp_min(0) ** cfg.FOCAL_BETA
        positive_loss = -(predicted.log() * (1 - predicted) ** cfg.FOCAL_ALPHA * positive * weights)
        negative_loss = -((1 - predicted).log() * predicted ** cfg.FOCAL_ALPHA * negative_weights * (1 - positive)
                          * weights)
        num_positive = (positive * weights).sum().clamp_min(1.0)
        return (positive_loss.sum() + negative_loss.sum()) / num_positive

    def adaptive_wing(self, predicted, target):
        """Adaptive wing loss per pixel (Wang et al.): steep near the peaks, robust far from them."""
        cfg = self.cfg
        omega, theta, epsilon, alpha = cfg.AWING_OMEGA, cfg.AWING_THETA, cfg.AWING_EPSILON, cfg.AWING_ALPHA
        difference = (predicted - target).abs()
        exponent = alpha - target
        ratio = theta / epsilon
        scale = omega * (1 / (1 + ratio ** exponent)) * exponent * ratio ** (exponent - 1) / epsilon
        offset = theta * scale - omega * torch.log1p(ratio ** exponent)
        return torch.where(difference < theta, omega * torch.log1p((difference / epsilon) ** exponent),
                           scale * difference - offset)

    def coordinate_loss(self, logits, coords, coord_weights):
        """L1 distance (in heatmap pixels, normalised by the map size) between soft-argmax and target positions."""
        predicted = soft_argmax(logits, self.cfg.SOFTARGMAX_BETA)
        size = torch.tensor([logits.shape[-1], logits.shape[-2]], device=logits.device, dtype=torch.float32)
        distance = ((predicted - coords.float()).abs() / size).sum(dim=-1)            # (B, 24)
        return (distance * coord_weights).sum() / coord_weights.sum().clamp_min(1.0)

    def visibility_loss(self, vis_logits, vis_target):
        """Weighted cross-entropy over the annotated keypoint channels (target -1 = not annotated)."""
        return F.cross_entropy(vis_logits.float().reshape(-1, 3), vis_target.reshape(-1), weight=self.vis_weights,
                               ignore_index=-1)

    def segmentation_loss(self, seg_logits, seg_target):
        """Cross-entropy + Dice on the frames that have masks (target 255 marks frames / pixels without mask)."""
        cfg = self.cfg
        valid = seg_target != SEG_IGNORE
        if not valid.any():
            return seg_logits.sum() * 0.0
        logits = F.interpolate(seg_logits.float(), size=seg_target.shape[-2:], mode="bilinear", align_corners=False)
        cross_entropy = F.cross_entropy(logits, seg_target, ignore_index=SEG_IGNORE)
        probs = torch.softmax(logits, dim=1)
        one_hot = F.one_hot(seg_target.clamp_max(NUM_OBJECT_CLASSES), NUM_OBJECT_CLASSES + 1)
        target = one_hot.permute(0, 3, 1, 2).float()
        mask = valid.unsqueeze(1).float()
        intersection = (probs * target * mask).sum(dim=(0, 2, 3))
        denominator = ((probs + target) * mask).sum(dim=(0, 2, 3))
        present = (target * mask).sum(dim=(0, 2, 3)) > 0
        dice = 1 - (2 * intersection[present] + 1.0) / (denominator[present] + 1.0)
        return (1 - cfg.SEG_DICE_WEIGHT) * cross_entropy + cfg.SEG_DICE_WEIGHT * dice.mean()

    def forward(self, outputs, batch):
        """Weighted sum of the loss terms; returns (total, {name: value}) for reporting."""
        cfg = self.cfg
        parts = {"heat": cfg.HEATMAP_LOSS_WEIGHT * self.heatmap_loss(outputs["heat"], batch["heatmaps"],
                                                                     batch["heat_weights"]),
                 "vis": cfg.VISIBILITY_LOSS_WEIGHT * self.visibility_loss(outputs["vis"], batch["vis"])}
        if cfg.SEG_LOSS_WEIGHT > 0 and cfg.USE_MASKS:
            parts["seg"] = cfg.SEG_LOSS_WEIGHT * self.segmentation_loss(outputs["seg"], batch["seg"])
        if cfg.COORD_LOSS_WEIGHT > 0:
            parts["coord"] = cfg.COORD_LOSS_WEIGHT * self.coordinate_loss(outputs["heat"], batch["coords"],
                                                                          batch["coord_weights"])
        total = sum(parts.values())
        return total, {name: float(value.detach()) for name, value in parts.items()}


# ======================================================================================
#                                decoding and tracking
# ======================================================================================
def find_peaks(heat, max_peaks, threshold, nms_radius, subpixel):
    """
    heat: (h, w) float array in [0, 1]. Returns up to `max_peaks` peaks as (x, y, score) in
    heatmap coordinates, strongest first; the strongest peak is always returned (score may be
    below the threshold so that callers can still write coordinates for absent keypoints).
    """
    height, width = heat.shape
    kernel = 2 * nms_radius + 1
    dilated = cv2.dilate(heat, np.ones((kernel, kernel), np.uint8))
    candidates = np.argwhere(heat >= dilated - 1e-6)
    scores = heat[candidates[:, 0], candidates[:, 1]]
    peaks = []
    for candidate in np.argsort(-scores):
        y, x = candidates[candidate]
        score = float(scores[candidate])
        if peaks and score < threshold:
            break
        if any(abs(peak_x - x) <= nms_radius and abs(peak_y - y) <= nms_radius for peak_x, peak_y, _ in peaks):
            continue
        refined_x, refined_y = float(x), float(y)
        if subpixel > 0:
            y0, y1 = max(0, y - subpixel), min(height, y + subpixel + 1)
            x0, x1 = max(0, x - subpixel), min(width, x + subpixel + 1)
            window = heat[y0:y1, x0:x1]
            if window.sum() > 0:
                grid_y, grid_x = np.mgrid[y0:y1, x0:x1]
                refined_x = float((window * grid_x).sum() / window.sum())
                refined_y = float((window * grid_y).sum() / window.sum())
        peaks.append((refined_x, refined_y, score))
        if len(peaks) >= max_peaks:
            break
    if not peaks:                                             # all-zero map
        peaks.append((width / 2.0, height / 2.0, 0.0))
    return peaks


def assemble_needles(peaks_per_channel, diagonal, tolerance, max_instances):
    """
    Group needle peaks (end, tip, middle) into up to `max_instances` needle instances.
    Candidates are scored by the heat values and the geometric consistency
    middle ~ (end + tip) / 2. A missing middle point is estimated from end and tip.
    Returns a list of (3, 3) arrays [x, y, score].
    """
    ends, tips, mids = peaks_per_channel
    candidates = []
    for end_idx, end in enumerate(ends):
        for tip_idx, tip in enumerate(tips):
            expected_mid = ((end[0] + tip[0]) / 2, (end[1] + tip[1]) / 2)
            best_mid_idx, best_error = None, None
            for mid_idx, mid in enumerate(mids):
                error = math.hypot(mid[0] - expected_mid[0], mid[1] - expected_mid[1]) / max(diagonal, 1e-6)
                if best_error is None or error < best_error:
                    best_mid_idx, best_error = mid_idx, error
            geometry = max(0.0, 1.0 - best_error / tolerance) if best_mid_idx is not None else 0.0
            mid_score = mids[best_mid_idx][2] if best_mid_idx is not None else 0.0
            score = (end[2] + tip[2] + mid_score) / 3 * (0.5 + 0.5 * geometry)
            candidates.append((score, end_idx, tip_idx, best_mid_idx))
    candidates.sort(key=lambda candidate: -candidate[0])
    used_ends, used_tips, used_mids, instances = set(), set(), set(), []
    for _, end_idx, tip_idx, mid_idx in candidates:
        if end_idx in used_ends or tip_idx in used_tips or (mid_idx is not None and mid_idx in used_mids):
            continue
        end, tip = ends[end_idx], tips[tip_idx]
        mid = mids[mid_idx] if mid_idx is not None else ((end[0] + tip[0]) / 2, (end[1] + tip[1]) / 2, 0.0)
        instances.append(np.array([end, tip, mid], dtype=np.float32))
        used_ends.add(end_idx)
        used_tips.add(tip_idx)
        if mid_idx is not None:
            used_mids.add(mid_idx)
        if len(instances) >= max_instances:
            break
    if not instances:
        instances.append(np.array([ends[0], tips[0], mids[0]], dtype=np.float32))
    return instances


def decode_frame(heat, vis_logits, cfg, orig_w, orig_h):
    """
    heat: (24, h, w) sigmoid heatmaps of one frame; vis_logits: (24, 3).
    Returns a list of detections {"class_id", "keypoints": (K, 3) [x, y, visibility] in original
    frame coordinates, "score"}; single-instance classes yield exactly one detection each,
    the needle class up to MAX_NEEDLE_INSTANCES.
    """
    stride = cfg.HEATMAP_STRIDE
    map_height, map_width = heat.shape[1:]
    scale_x, scale_y = orig_w / (map_width * stride), orig_h / (map_height * stride)
    map_diagonal = math.hypot(map_width, map_height)
    vis_pred = np.argmax(vis_logits, axis=-1)
    detections = []

    def to_original(map_x, map_y):
        """Heatmap pixel -> original frame pixel (heatmap pixel centres sit at stride * (i + 0.5) - 0.5)."""
        return ((map_x + 0.5) * stride - 0.5) * scale_x, ((map_y + 0.5) * stride - 0.5) * scale_y

    for class_id in range(NUM_OBJECT_CLASSES):
        offset, num_keypoints = CHANNEL_OFFSET[class_id], KEYPOINTS_PER_CLASS[class_id]
        max_peaks = cfg.MAX_NEEDLE_INSTANCES if class_id == NEEDLE_CLASS else 1
        peaks = [find_peaks(heat[offset + keypoint], max_peaks, cfg.PEAK_THRESHOLD, cfg.PEAK_NMS_RADIUS,
                            cfg.SUBPIXEL_WINDOW) for keypoint in range(num_keypoints)]
        if class_id == NEEDLE_CLASS:
            instances = assemble_needles(peaks, map_diagonal, cfg.NEEDLE_MIDPOINT_TOLERANCE, cfg.MAX_NEEDLE_INSTANCES)
        else:
            instances = [np.array([channel_peaks[0] for channel_peaks in peaks], dtype=np.float32)]
        for instance_idx, instance in enumerate(instances):
            if instance_idx > 0 and float(instance[:, 2].mean()) < cfg.PEAK_THRESHOLD:
                continue                                        # a second needle needs real evidence
            keypoints = np.zeros((num_keypoints, 3), dtype=np.float32)
            for keypoint in range(num_keypoints):
                x, y = to_original(instance[keypoint, 0], instance[keypoint, 1])
                channel = offset + keypoint
                visibility = int(vis_pred[channel])
                has_peak = instance[keypoint, 2] >= cfg.PEAK_THRESHOLD
                if cfg.OUT_OF_FRAME_IF_NO_PEAK and not has_peak:
                    visibility = VIS_OUT
                elif visibility == VIS_OUT and has_peak:        # a clear peak contradicts "out of frame"
                    hidden_wins = vis_logits[channel, VIS_HIDDEN] > vis_logits[channel, VIS_VISIBLE]
                    visibility = VIS_HIDDEN if hidden_wins else VIS_VISIBLE
                keypoints[keypoint] = (float(np.clip(x, 0, orig_w - 1)), float(np.clip(y, 0, orig_h - 1)), visibility)
            detections.append({"class_id": class_id, "keypoints": keypoints, "score": float(instance[:, 2].mean())})
    return detections


class NeedleTracker:
    """Associates needle detections across frames; single-instance classes keep their class id as track id."""

    def __init__(self, cfg, diagonal):
        """`diagonal` (pixels) normalises the association distances of one video."""
        self.cfg, self.diagonal = cfg, diagonal
        self.tracks = {}                        # track id -> {"keypoints": (3, 3), "age": frames since last match}
        self.next_id = NUM_OBJECT_CLASSES - 1   # needle tracks start at id 5

    def _match(self, active_ids, needles):
        """Hungarian matching of the active tracks with the needle detections; returns [(track id, needle idx)]."""
        cost = np.zeros((len(active_ids), len(needles)))
        for track_pos, track_id in enumerate(active_ids):
            for needle_idx, needle in enumerate(needles):
                offsets = self.tracks[track_id]["keypoints"][:, :2] - needle["keypoints"][:, :2]
                cost[track_pos, needle_idx] = np.linalg.norm(offsets, axis=1).mean() / self.diagonal
        rows, cols = hungarian(cost)
        return [(active_ids[track_pos], needle_idx) for track_pos, needle_idx in zip(rows, cols)
                if cost[track_pos, needle_idx] <= self.cfg.TRACK_MAX_DISTANCE]

    def step(self, detections):
        """Assign track ids to the detections of the next frame and return them."""
        cfg = self.cfg
        needles = [det for det in detections if det["class_id"] == NEEDLE_CLASS]
        tracked = [{"track_id": det["class_id"], **det} for det in detections if det["class_id"] != NEEDLE_CLASS]

        active_ids = [track_id for track_id, track in self.tracks.items() if track["age"] <= cfg.TRACK_MISS_WINDOW]
        matches = self._match(active_ids, needles)
        matched_tracks = {track_id for track_id, _ in matches}
        matched_needles = {needle_idx for _, needle_idx in matches}
        for track_id, needle_idx in matches:
            track = self.tracks[track_id]
            keypoints = needles[needle_idx]["keypoints"].copy()
            if cfg.TRACK_SMOOTHING > 0:
                keypoints[:, :2] = (cfg.TRACK_SMOOTHING * track["keypoints"][:, :2]
                                    + (1 - cfg.TRACK_SMOOTHING) * keypoints[:, :2])
            track.update(keypoints=keypoints, age=0)
            tracked.append({"track_id": track_id, **{**needles[needle_idx], "keypoints": keypoints}})
        for track_id in list(self.tracks):
            if track_id not in matched_tracks:
                self.tracks[track_id]["age"] += 1
                if self.tracks[track_id]["age"] > cfg.TRACK_MISS_WINDOW:
                    del self.tracks[track_id]
        for needle_idx, needle in enumerate(needles):
            if needle_idx not in matched_needles:
                self.next_id += 1
                self.tracks[self.next_id] = {"keypoints": needle["keypoints"].copy(), "age": 0}
                tracked.append({"track_id": self.next_id, **needle})
        return tracked


def format_mot_line(frame_id, detection):
    """One submission line: frame, track id, class id, four -1 box fields, then x, y, visibility per keypoint."""
    values = [str(frame_id), str(detection["track_id"]), str(detection["class_id"]), "-1", "-1", "-1", "-1"]
    for x, y, visibility in detection["keypoints"]:
        values += [f"{x:.2f}", f"{y:.2f}", str(int(visibility))]
    return ",".join(values)


# ======================================================================================
#                                       inference
# ======================================================================================
@torch.no_grad()
def run_inference(model, samples, cfg, device, desc="inference"):
    """
    Run the network on the samples (sorted by video and frame id), decode and track.
    Returns {video: [(frame_id, [detections with track ids]), ...]} in frame order.
    """
    model.eval()
    loader = make_loader(samples, cfg, train=False, batch_size=cfg.INFER_BATCH_SIZE)
    per_sample = [None] * len(samples)
    for batch in tqdm(loader, desc=desc, unit="batch", leave=False):
        images = batch["image"].to(device, non_blocking=True)
        with autocast_context(device, cfg.USE_AMP):
            outputs = model(images)
        heat = torch.sigmoid(outputs["heat"].float())
        vis = outputs["vis"].float()
        if cfg.TTA_HFLIP:
            with autocast_context(device, cfg.USE_AMP):
                flipped_outputs = model(torch.flip(images, dims=[-1]))
            flipped_heat = torch.flip(torch.sigmoid(flipped_outputs["heat"].float()), dims=[-1])
            heat = 0.5 * (heat + flipped_heat[:, FLIP_CHANNEL_ORDER])            # hands swapped back
            vis = 0.5 * (vis + flipped_outputs["vis"].float()[:, FLIP_CHANNEL_ORDER])
        heat, vis = heat.cpu().numpy(), vis.cpu().numpy()
        for batch_pos, sample_idx in enumerate(batch["index"].tolist()):
            per_sample[sample_idx] = decode_frame(heat[batch_pos], vis[batch_pos], cfg, int(batch["orig_w"][batch_pos]),
                                                  int(batch["orig_h"][batch_pos]))
    if any(prediction is None for prediction in per_sample):
        raise RuntimeError("Some frames received no prediction")
    results = defaultdict(list)
    order = sorted(range(len(samples)), key=lambda idx: (samples[idx]["video"], samples[idx]["frame_id"]))
    trackers = {}
    for sample_idx in order:
        sample = samples[sample_idx]
        if sample["video"] not in trackers:
            trackers[sample["video"]] = NeedleTracker(cfg, math.hypot(sample["width"], sample["height"]))
        results[sample["video"]].append((sample["frame_id"], trackers[sample["video"]].step(per_sample[sample_idx])))
    return results


def write_submission(results, folder, cfg):
    """Per-frame files <video>_frame_<id>.txt plus one file per video, in the annotation layout."""
    mot_dir = os.path.join(folder, cfg.SUBMISSION_DIRNAME)
    os.makedirs(mot_dir, exist_ok=True)
    for video, frames in results.items():
        with open(os.path.join(folder, f"{video}.txt"), "w", encoding="utf-8") as video_handle:
            for frame_id, detections in frames:
                lines = [format_mot_line(frame_id, detection) for detection in detections]
                frame_path = os.path.join(mot_dir, f"{video}_frame_{frame_id}.txt")
                with open(frame_path, "w", encoding="utf-8") as frame_handle:
                    frame_handle.write("\n".join(lines) + ("\n" if lines else ""))
                video_handle.write("".join(line + "\n" for line in lines))


# ======================================================================================
#                                      evaluation
# ======================================================================================
def evaluable_keypoints(keypoints, include_hidden):
    """Boolean mask of the keypoints that take part in localisation metrics (visible, optionally hidden)."""
    keep = keypoints[:, 2] == VIS_VISIBLE
    if include_hidden:
        keep = keep | (keypoints[:, 2] == VIS_HIDDEN)
    return keep


def keypoint_similarity(gt_keypoints, pr_keypoints, diagonal, norm, include_hidden):
    """Mean over the evaluable GT keypoints of max(0, 1 - distance / (norm * diagonal)); None if none."""
    keep = evaluable_keypoints(gt_keypoints, include_hidden)
    if not keep.any():
        return None
    distances = np.linalg.norm(gt_keypoints[keep, :2] - pr_keypoints[keep, :2], axis=1) / (norm * diagonal)
    return float(np.clip(1.0 - distances, 0.0, 1.0).mean())


def hota_from_pairs(frame_pairs, num_alphas):
    """
    HOTA, DetA and AssA averaged over `num_alphas` localisation thresholds from the per-frame
    (GT entity, predicted entity, similarity) pairs; a None entity marks an unmatched detection.
    """
    hota_values, deta_values, assa_values = [], [], []
    for alpha in np.linspace(0.05, 0.95, num_alphas):
        tp_pairs = Counter()                   # (GT track, predicted track) -> matches at this alpha
        gt_count, pr_count = Counter(), Counter()
        true_pos = false_neg = false_pos = 0
        for pairs in frame_pairs:
            for gt_entity, pr_entity, similarity in pairs:
                if gt_entity is not None:
                    gt_count[gt_entity] += 1
                if pr_entity is not None:
                    pr_count[pr_entity] += 1
                if gt_entity is not None and pr_entity is not None and similarity >= alpha:
                    tp_pairs[(gt_entity, pr_entity)] += 1
                    true_pos += 1
                else:
                    false_neg += gt_entity is not None
                    false_pos += pr_entity is not None
        deta = true_pos / max(true_pos + false_neg + false_pos, 1)
        assa = 0.0
        if true_pos > 0:
            association_sum = 0.0
            for (gt_entity, pr_entity), matches in tp_pairs.items():
                fn_assoc = gt_count[gt_entity] - matches       # GT detections not matched to this predicted track
                fp_assoc = pr_count[pr_entity] - matches       # predicted detections not matched to this GT track
                association_sum += matches * matches / max(matches + fn_assoc + fp_assoc, 1)
            assa = association_sum / true_pos
        hota_values.append(math.sqrt(deta * assa))
        deta_values.append(deta)
        assa_values.append(assa)
    return float(np.mean(hota_values)), float(np.mean(deta_values)), float(np.mean(assa_values))


def evaluate_tracking(samples, results, cfg):
    """
    PCK, visibility accuracy and a HOTA-style score with keypoint-distance similarity.

    Entities are object instances (class + track) per frame. An object counts as present
    in a frame when it has at least one evaluable keypoint (visible, or hidden when
    EVAL_INCLUDE_HIDDEN); objects that are entirely out of frame are neither detections
    nor misses. For every localisation threshold alpha the present GT and predicted
    instances of a frame are matched with the Hungarian algorithm on the similarity;
    TP/FN/FP give the detection accuracy and the consistency of (GT track, predicted
    track) pairs over the sequence gives the association accuracy, as in the HOTA
    definition. Videos are evaluated jointly. The visibility accuracy compares the
    flags of matched objects (single-instance classes are always paired).
    """
    gt_by_frame = {}
    for sample in samples:
        diagonal = math.hypot(sample["width"], sample["height"])
        gt_by_frame[(sample["video"], sample["frame_id"])] = (parse_mot_file(sample["mot"]), diagonal)
    pr_by_frame = {(video, frame_id): detections
                   for video, frames in results.items() for frame_id, detections in frames}
    include_hidden = cfg.EVAL_INCLUDE_HIDDEN

    pck_hits, pck_total = Counter(), Counter()
    vis_hits, vis_total = 0, 0
    frame_pairs = []          # per frame: list of (GT entity, predicted entity, similarity) over all classes
    for (video, frame_id), (gt_objects, diagonal) in gt_by_frame.items():
        pr_objects = pr_by_frame.get((video, frame_id), [])
        pairs = []
        for class_id in range(NUM_OBJECT_CLASSES):
            gt_class = [obj for obj in gt_objects if obj["class_id"] == class_id]
            pr_class = [obj for obj in pr_objects if obj["class_id"] == class_id]
            vis_pairs = []
            if class_id != NEEDLE_CLASS and gt_class and pr_class:
                vis_pairs.append((gt_class[0], pr_class[0]))           # single-instance classes pair directly
            gt_present = [obj for obj in gt_class if evaluable_keypoints(obj["keypoints"], include_hidden).any()]
            pr_present = [obj for obj in pr_class if evaluable_keypoints(obj["keypoints"], include_hidden).any()]

            similarity = np.zeros((len(gt_present), len(pr_present)))
            for gt_idx, gt_obj in enumerate(gt_present):
                for pr_idx, pr_obj in enumerate(pr_present):
                    similarity[gt_idx, pr_idx] = keypoint_similarity(gt_obj["keypoints"], pr_obj["keypoints"], diagonal,
                                                                     cfg.HOTA_DISTANCE_NORM, include_hidden)
            rows, cols = hungarian(-similarity)
            matched = dict(zip(rows.tolist(), cols.tolist()))
            for gt_idx, gt_obj in enumerate(gt_present):
                keep = evaluable_keypoints(gt_obj["keypoints"], include_hidden)
                pck_total[class_id] += int(keep.sum())
                gt_entity = (video, gt_obj["track_id"], class_id)
                if gt_idx not in matched:
                    pairs.append((gt_entity, None, 0.0))
                    continue
                pr_obj = pr_present[matched[gt_idx]]
                pairs.append((gt_entity, (video, pr_obj["track_id"], class_id), similarity[gt_idx, matched[gt_idx]]))
                distances = np.linalg.norm(gt_obj["keypoints"][:, :2] - pr_obj["keypoints"][:, :2], axis=1)
                pck_hits[class_id] += int((distances[keep] <= cfg.PCK_THRESHOLD * diagonal).sum())
                if class_id == NEEDLE_CLASS:
                    vis_pairs.append((gt_obj, pr_obj))
            pairs.extend((None, (video, pr_obj["track_id"], class_id), 0.0)
                         for pr_idx, pr_obj in enumerate(pr_present) if pr_idx not in matched.values())
            for gt_obj, pr_obj in vis_pairs:
                annotated = gt_obj["keypoints"][:, 2] >= 0
                vis_total += int(annotated.sum())
                vis_hits += int((pr_obj["keypoints"][annotated, 2] == gt_obj["keypoints"][annotated, 2]).sum())
        frame_pairs.append(pairs)

    hota, deta, assa = hota_from_pairs(frame_pairs, cfg.HOTA_ALPHAS)
    pck_per_class = {CLASS_NAMES[class_id]: (pck_hits[class_id] / pck_total[class_id] if pck_total[class_id] else None)
                     for class_id in range(NUM_OBJECT_CLASSES)}
    return {"hota": hota, "deta": deta, "assa": assa,
            "pck": sum(pck_hits.values()) / max(sum(pck_total.values()), 1), "pck_per_class": pck_per_class,
            "visibility_accuracy": vis_hits / max(vis_total, 1)}


# ======================================================================================
#                                       trainer
# ======================================================================================
class Trainer:
    """
    Trains the keypoint network: builds data, model, optimiser and schedule, validates after
    every epoch and writes checkpoints, submissions, validation metrics and the training report.
    """

    def __init__(self, cfg, train_samples, val_samples, run_dir, device, probe=False, tag="main"):
        """
        Prepare loaders, model, EMA, loss, optimiser, scheduler, scaler and the run folders.
        With probe=True (GRM probes) nothing is written to disk.
        """
        self.cfg, self.device, self.run_dir = cfg, device, run_dir
        self.probe, self.tag = probe, tag
        self.train_samples, self.val_samples = train_samples, val_samples
        self.history = []
        self.batch_stats = blocks.RunningStats()
        self.best_score, self.best_epoch, self.epochs_without_improvement = -1e9, -1, 0

        self.train_loader = make_loader(train_samples, cfg, train=True)
        self.model = KeypointNet(cfg)
        if cfg.CHECKPOINT_INIT:
            self._load_initial_weights(cfg.CHECKPOINT_INIT)
        self.model.to(device)
        if device.type == "cuda" and torch.cuda.device_count() > 1:
            self.model = nn.DataParallel(self.model)
            LOG.info("DataParallel over %d GPUs", torch.cuda.device_count())
        self.ema = ModelEMA(self.model, cfg.EMA_DECAY) if cfg.EMA_DECAY > 0 else None

        self.criterion = KeypointLoss(cfg).to(device)
        self.optimizer = self._build_optimizer()
        self.steps_per_epoch = max(1, math.ceil(len(self.train_loader) / cfg.GRAD_ACCUM_STEPS))
        self.scheduler, self.scheduler_per_step = self._build_scheduler()
        self.scaler = make_grad_scaler(enabled=(cfg.USE_AMP and device.type == "cuda"))

        self.submission_samples = None
        if not probe:
            for sub_folder in ("checkpoints", "submissions", "val_metrics"):
                os.makedirs(os.path.join(run_dir, sub_folder), exist_ok=True)
            if cfg.PREDICT_INPUT_DIR:
                self.submission_samples = load_prediction_samples(cfg.PREDICT_INPUT_DIR, cfg, run_dir)

    # ---------------------------------------------------------------- set-up helpers
    def _load_initial_weights(self, checkpoint_path):
        """Initialise the network from a checkpoint (shape-compatible tensors only)."""
        state = load_checkpoint(checkpoint_path)
        weights = state.get("ema_state") or state["model_state"]
        own = self.model.state_dict()
        compatible = {key: value for key, value in weights.items() if key in own and own[key].shape == value.shape}
        self.model.load_state_dict(compatible, strict=False)
        LOG.info("Initialised %d of %d tensors from %s", len(compatible), len(own), checkpoint_path)

    def _build_optimizer(self):
        """Create the optimiser with a reduced learning rate (ENCODER_LR_MULT) for the pre-trained encoder."""
        cfg, core = self.cfg, unwrap(self.model)
        groups = [{"params": list(core.encoder.parameters()), "lr": cfg.LEARNING_RATE * cfg.ENCODER_LR_MULT},
                  {"params": [param for name, param in core.named_parameters() if not name.startswith("encoder.")],
                   "lr": cfg.LEARNING_RATE}]
        return blocks.build_optimizer(groups, cfg)

    def _build_scheduler(self):
        """Create the learning-rate schedule; returns (scheduler, stepped_per_batch)."""
        return blocks.build_scheduler(self.optimizer, self.cfg, self.steps_per_epoch)

    def _to_device(self, batch):
        """Move every tensor of a batch dictionary to the training device."""
        return {key: (value.to(self.device, non_blocking=True) if torch.is_tensor(value) else value)
                for key, value in batch.items()}

    def _selection_score(self, metrics):
        """Scalar used to compare epochs (higher is better) according to SELECTION_METRIC."""
        if self.cfg.SELECTION_METRIC == "val_loss":
            return -metrics["val_loss"]
        return metrics[self.cfg.SELECTION_METRIC]

    # ---------------------------------------------------------------- one epoch
    def train_epoch(self, epoch):
        """
        Train for one epoch; returns (mean training loss, mean value of every loss part). The batch-loss
        statistics of the epoch (a GRM signal) are kept in self.batch_stats.
        """
        cfg, model = self.cfg, self.model
        self.batch_stats = blocks.RunningStats()
        model.train()
        for parameter in unwrap(model).encoder.parameters():
            parameter.requires_grad_(epoch >= cfg.FREEZE_ENCODER_EPOCHS)
        running_loss, seen, part_sums = 0.0, 0, Counter()
        self.optimizer.zero_grad(set_to_none=True)
        progress = tqdm(self.train_loader, desc=f"[{self.tag}] epoch {epoch + 1}/{cfg.NUM_EPOCHS} train",
                        unit="batch", leave=False)
        for step, batch in enumerate(progress):
            batch = self._to_device(batch)
            batch_size = batch["image"].shape[0]
            with autocast_context(self.device, cfg.USE_AMP):
                outputs = model(batch["image"])
                loss, parts = self.criterion(outputs, batch)
                loss = loss / cfg.GRAD_ACCUM_STEPS
            self.scaler.scale(loss).backward()
            if (step + 1) % cfg.GRAD_ACCUM_STEPS == 0 or (step + 1) == len(self.train_loader):
                if cfg.GRAD_CLIP_NORM > 0:
                    self.scaler.unscale_(self.optimizer)
                    nn.utils.clip_grad_norm_(model.parameters(), cfg.GRAD_CLIP_NORM)
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.optimizer.zero_grad(set_to_none=True)
                if self.ema is not None:
                    self.ema.update(model)
                if self.scheduler is not None and self.scheduler_per_step:
                    self.scheduler.step()
            batch_loss = loss.item() * cfg.GRAD_ACCUM_STEPS
            self.batch_stats.add(batch_loss)
            running_loss += batch_loss * batch_size
            seen += batch_size
            for name, value in parts.items():
                part_sums[name] += value * batch_size
            progress.set_postfix(loss=f"{running_loss / max(seen, 1):.4f}",
                                 lr=f"{self.optimizer.param_groups[1]['lr']:.2e}")
        return running_loss / max(seen, 1), {name: value / max(seen, 1) for name, value in part_sums.items()}

    @torch.no_grad()
    def evaluate(self, model, desc):
        """Validation loss (teacher-forced targets) + tracking metrics of the decoded predictions."""
        cfg = self.cfg
        model.eval()
        loader = make_loader(self.val_samples, cfg, train=False, batch_size=cfg.INFER_BATCH_SIZE)
        total_loss, seen = 0.0, 0
        for batch in tqdm(loader, desc=desc + " loss", unit="batch", leave=False):
            batch = self._to_device(batch)
            with autocast_context(self.device, cfg.USE_AMP):
                outputs = model(batch["image"])
            loss, _ = self.criterion(outputs, batch)
            total_loss += loss.item() * batch["image"].shape[0]
            seen += batch["image"].shape[0]
        results = run_inference(model, self.val_samples, cfg, self.device, desc=desc + " decode")
        metrics = evaluate_tracking(self.val_samples, results, cfg)
        metrics["val_loss"] = total_loss / max(seen, 1)
        return metrics, results

    # ---------------------------------------------------------------- bookkeeping
    def _save_checkpoint(self, epoch, metrics, file_name):
        """Save weights (raw + EMA), configuration and metrics of an epoch under checkpoints/<file_name>."""
        cfg = self.cfg
        payload = {"epoch": epoch, "task": "task3_keypoints", "config": config_to_dict(cfg), "metrics": metrics,
                   "model_state": unwrap(self.model).state_dict(),
                   "ema_state": self.ema.ema.state_dict() if self.ema is not None else None}
        if cfg.SAVE_OPTIMIZER_STATE:
            payload["optimizer_state"] = self.optimizer.state_dict()
            payload["scheduler_state"] = self.scheduler.state_dict() if self.scheduler is not None else None
        torch.save(payload, os.path.join(self.run_dir, "checkpoints", file_name))

    def _write_submission(self, epoch, use_ema, chosen_results):
        """Submission of this epoch (inference folder, or the validation predictions); returns the folder."""
        cfg = self.cfg
        folder = os.path.join(self.run_dir, "submissions", f"epoch_{epoch + 1:02d}")
        if self.submission_samples is None:
            results = chosen_results
        else:
            prefer_ema = use_ema or (self.ema is not None and cfg.USE_EMA_FOR_INFERENCE)
            inference_model = self.ema.ema if prefer_ema else unwrap(self.model)
            results = run_inference(inference_model, self.submission_samples, cfg, self.device,
                                    desc=f"submission epoch {epoch + 1}")
        write_submission(results, folder, cfg)
        return folder

    def _write_report(self, row):
        """Append the epoch row to training_report.csv and refresh training_report.json."""
        csv_path = os.path.join(self.run_dir, "training_report.csv")
        flat_row = OrderedDict((key, value) for key, value in row.items() if not isinstance(value, (list, dict)))
        write_header = not os.path.isfile(csv_path)
        with open(csv_path, "a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(flat_row.keys()))
            if write_header:
                writer.writeheader()
            writer.writerow(flat_row)
        write_json(os.path.join(self.run_dir, "training_report.json"),
                   {"config": config_to_dict(self.cfg), "best_epoch": self.best_epoch + 1,
                    "best_score": self.best_score, "epochs": self.history})

    # ---------------------------------------------------------------- main loop
    def fit(self):
        """Run the training loop; returns the per-epoch history (list of report rows)."""
        cfg = self.cfg
        LOG.info("[%s] training %d epochs | %d train frames / %d val frames | encoder %s | decoder %s "
                 "| heatmap loss %s | optimizer %s | scheduler %s | batch %d x %d", self.tag, cfg.NUM_EPOCHS,
                 len(self.train_samples),
                 len(self.val_samples), cfg.ENCODER, cfg.DECODER_TYPE, cfg.HEATMAP_LOSS, cfg.OPTIMIZER, cfg.SCHEDULER,
                 cfg.BATCH_SIZE, cfg.GRAD_ACCUM_STEPS)
        for epoch in range(cfg.NUM_EPOCHS):
            epoch_start = time.time()
            train_loss, loss_parts = self.train_epoch(epoch)
            metrics, results = self.evaluate(self.model, f"epoch {epoch + 1} val")
            ema_metrics, ema_results = None, None
            if self.ema is not None:
                ema_metrics, ema_results = self.evaluate(self.ema.ema, f"epoch {epoch + 1} val (EMA)")
            if self.scheduler is not None and not self.scheduler_per_step:
                self.scheduler.step(metrics["val_loss"])

            # the epoch score used for model selection prefers the EMA weights when they are better
            use_ema = ema_metrics is not None and self._selection_score(ema_metrics) > self._selection_score(metrics)
            chosen_metrics, chosen_results = (ema_metrics, ema_results) if use_ema else (metrics, results)
            score = self._selection_score(chosen_metrics)
            improved = score > self.best_score
            if improved:
                self.best_score, self.best_epoch, self.epochs_without_improvement = score, epoch, 0
            else:
                self.epochs_without_improvement += 1

            row = OrderedDict([("epoch", epoch + 1), ("lr_encoder", self.optimizer.param_groups[0]["lr"]),
                               ("lr_heads", self.optimizer.param_groups[1]["lr"]), ("train_loss", train_loss),
                               ("train_loss_std", self.batch_stats.std), ("train_batches", self.batch_stats.count)])
            row.update((f"train_loss_{name}", value) for name, value in loss_parts.items())
            row.update([("val_loss", metrics["val_loss"]), ("val_hota", metrics["hota"]), ("val_deta", metrics["deta"]),
                        ("val_assa", metrics["assa"]), ("val_pck", metrics["pck"]),
                        ("val_visibility_acc", metrics["visibility_accuracy"]),
                        ("ema_hota", ema_metrics["hota"] if ema_metrics else None),
                        ("ema_pck", ema_metrics["pck"] if ema_metrics else None),
                        ("selected_weights", "ema" if use_ema else "raw"), ("selection_score", score),
                        ("best_so_far", improved), ("epoch_seconds", round(time.time() - epoch_start, 1)),
                        ("encoder", cfg.ENCODER), ("decoder", cfg.DECODER_TYPE), ("batch_size", cfg.BATCH_SIZE),
                        ("heatmap_loss", cfg.HEATMAP_LOSS), ("optimizer", cfg.OPTIMIZER), ("scheduler", cfg.SCHEDULER),
                        ("learning_rate", cfg.LEARNING_RATE),
                        ("img_size", f"{cfg.IMG_WIDTH}x{cfg.IMG_HEIGHT}")])
            row.update((f"pck_{name}", value) for name, value in chosen_metrics["pck_per_class"].items())
            self.history.append(row)
            ema_text = f" | EMA HOTA {ema_metrics['hota']:.4f} PCK {ema_metrics['pck']:.3f}" if ema_metrics else ""
            parts_text = {name: round(value, 4) for name, value in loss_parts.items()}
            LOG.info("[%s] epoch %d/%d | train loss %.4f %s | val loss %.4f | HOTA %.4f (DetA %.3f, AssA %.3f) "
                     "| PCK %.3f | vis acc %.3f%s | %.0fs%s", self.tag, epoch + 1, cfg.NUM_EPOCHS, train_loss,
                     parts_text,
                     metrics["val_loss"], metrics["hota"], metrics["deta"], metrics["assa"], metrics["pck"],
                     metrics["visibility_accuracy"], ema_text, time.time() - epoch_start,
                     " | new best" if improved else "")
            LOG.info("PCK per class: %s", chosen_metrics["pck_per_class"])

            if not self.probe:
                self._save_checkpoint(epoch, chosen_metrics, f"epoch_{epoch + 1:02d}.pt")
                self._save_checkpoint(epoch, chosen_metrics, "last.pt")
                if improved:
                    self._save_checkpoint(epoch, chosen_metrics, "best.pt")
                write_json(os.path.join(self.run_dir, "val_metrics", f"epoch_{epoch + 1:02d}.json"),
                           {"raw": metrics, "ema": ema_metrics})
                folder = self._write_submission(epoch, use_ema, chosen_results)
                if improved:
                    best_dir = os.path.join(self.run_dir, "best_submission")
                    shutil.rmtree(best_dir, ignore_errors=True)
                    shutil.copytree(folder, best_dir)
                self._write_report(row)
            if 0 < cfg.EARLY_STOPPING_PATIENCE <= self.epochs_without_improvement:
                LOG.info("Early stopping: no improvement for %d epochs", cfg.EARLY_STOPPING_PATIENCE)
                break
        LOG.info("Finished: best epoch %d with %s = %.4f", self.best_epoch + 1, cfg.SELECTION_METRIC, self.best_score)
        return self.history


# ======================================================================================
#                                    entry points
# ======================================================================================
def extract_video_frames(video_path, cfg, output_folder):
    """Decode one video at TEST_FPS into <output_folder>/<video>_frame_<id>.png files; returns the samples."""
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    os.makedirs(output_folder, exist_ok=True)
    capture = cv2.VideoCapture(video_path)
    if not capture.isOpened():
        raise RuntimeError(f"Video cannot be opened: {video_path}")
    fps = capture.get(cv2.CAP_PROP_FPS) or 30.0
    step = max(1, int(round(fps / cfg.TEST_FPS)))
    LOG.info("Extracting frames of %s at %.1f fps (every %d-th frame)", video_name, cfg.TEST_FPS, step)
    samples = []
    index = 0
    while True:
        success, frame = capture.read()
        if not success:
            break
        if index % step == 0:
            frame_id = index if cfg.MP4_FRAME_NUMBERING == "original" else len(samples)
            path = os.path.join(output_folder, f"{video_name}_frame_{frame_id}.png")
            if not os.path.isfile(path):
                cv2.imwrite(path, frame)
            samples.append({"video": video_name, "frame_id": frame_id, "image": path, "mot": None, "masks": []})
        index += 1
    capture.release()
    if not samples:
        raise RuntimeError(f"No frames could be decoded from {video_path}")
    return samples


def load_prediction_samples(input_dir, cfg, work_dir):
    """
    Build the sample list of an inference folder: mp4 videos (decoded at TEST_FPS into
    <work_dir>/extracted_frames), one folder of png frames per video, or a flat folder of
    <video>_frame_<id>.png files. Every frame is verified (and its size recorded).
    """
    if not os.path.isdir(input_dir):
        raise FileNotFoundError(f"Input folder not found: {input_dir}")
    entries = sorted(os.listdir(input_dir))
    video_files = [entry for entry in entries if entry.lower().endswith(VIDEO_EXTENSIONS)]
    samples = []
    if video_files:
        for video_file in video_files:
            output_folder = os.path.join(work_dir, "extracted_frames", os.path.splitext(video_file)[0])
            samples.extend(extract_video_frames(os.path.join(input_dir, video_file), cfg, output_folder))
    else:
        for entry in entries:
            for path in png_files_of(os.path.join(input_dir, entry)):
                video, frame_id = split_frame_name(os.path.splitext(os.path.basename(path))[0])
                samples.append({"video": video, "frame_id": frame_id, "image": path, "mot": None, "masks": []})
    if not samples:
        raise FileNotFoundError(f"No videos or png frames found in {input_dir}")
    samples.sort(key=lambda sample: (sample["video"], sample["frame_id"]))
    verify_samples(samples, f"inference frames ({input_dir})")
    return samples


def prepare_data(cfg):
    """List and verify the training / validation frames; returns (train_samples, val_samples)."""
    train_samples = list_training_samples(cfg)
    val_samples = list_validation_samples(cfg)
    if cfg.STRICT_DATA_CHECK:
        verify_samples(train_samples, "training frames")
        verify_samples(val_samples, "validation frames")
    else:
        read_frame_sizes(train_samples + val_samples)
    overlap = {sample["video"] for sample in train_samples} & {sample["video"] for sample in val_samples}
    if overlap:
        LOG.warning("%d videos appear in both the training and the validation set: %s", len(overlap),
                    sorted(overlap)[:5])
    return train_samples, val_samples


def run_training(cfg, run_dir, device):
    """List and verify the training / validation frames, then train."""
    train_samples, val_samples = prepare_data(cfg)
    write_json(os.path.join(run_dir, "config_used.json"), config_to_dict(cfg))
    Trainer(cfg, train_samples, val_samples, run_dir, device).fit()
    LOG.info("Run folder: %s", run_dir)


def frame_subset(samples, fraction, seed):
    """Random subset with `fraction` of the training frames, drawn per video so that every video stays present."""
    if fraction >= 1.0:
        return list(samples)
    rng = random.Random(seed)
    by_video = OrderedDict()
    for sample in samples:
        by_video.setdefault(sample["video"], []).append(sample)
    subset = []
    for frames in by_video.values():
        frames = list(frames)
        rng.shuffle(frames)
        subset.extend(frames[:max(1, int(round(fraction * len(frames))))])
    return subset


def build_grm_task(cfg, device):
    """GRM adapter of this script; the frames are listed and verified only when a phase trains something."""
    data = {}

    def splits():
        """Training / validation samples, loaded once per call of the script."""
        if not data:
            data["train"], data["val"] = prepare_data(cfg)
        return data["train"], data["val"]

    def run_probe(overrides, epochs, tag, data_fraction):
        """Train one configuration for `epochs` epochs without writing files; returns its history."""
        train_samples, val_samples = splits()
        probe_cfg = clone_config(cfg)
        apply_overrides(probe_cfg, overrides)
        probe_cfg.NUM_EPOCHS = epochs
        probe_cfg.EARLY_STOPPING_PATIENCE = 0
        subset = frame_subset(train_samples, data_fraction, cfg.SEED)
        trainer = Trainer(probe_cfg, subset, val_samples, cfg.GRM_DIR, device, probe=True, tag=tag)
        try:
            return trainer.fit()
        finally:
            del trainer
            if device.type == "cuda":
                torch.cuda.empty_cache()

    def train_final(overrides):
        """Full training of the configuration chosen by the GRM, in <GRM_DIR>/final_<encoder>."""
        train_samples, val_samples = splits()
        final_cfg = clone_config(cfg)
        apply_overrides(final_cfg, overrides)
        if cfg.GRM_FINAL_EPOCHS:
            final_cfg.NUM_EPOCHS = cfg.GRM_FINAL_EPOCHS
        run_dir = os.path.join(cfg.GRM_DIR, f"final_{final_cfg.ENCODER.replace(':', '_')}")
        os.makedirs(run_dir, exist_ok=True)
        write_json(os.path.join(run_dir, "config_used.json"), config_to_dict(final_cfg))
        history = Trainer(final_cfg, train_samples, val_samples, run_dir, device, tag="grm-final").fit()
        LOG.info("Final run folder: %s", run_dir)
        return history

    return grm.GRMTask("task3", cfg, run_probe, train_final, LOG)


ARCHITECTURE_KEYS = ("ENCODER", "DECODER_TYPE", "DECODER_CHANNELS", "HEAD_CHANNELS", "VISIBILITY_HIDDEN", "DROPOUT",
                     "IMG_HEIGHT", "IMG_WIDTH", "HEATMAP_STRIDE")


def upgrade_state_dict(weights, config):
    """Rename the decoder weights of checkpoints written before DECODER_TYPE existed (FPN at the top level)."""
    if "DECODER_TYPE" in config:
        return weights
    renamed = {}
    for key, value in weights.items():
        if key.startswith(("lateral.", "smooth.")):
            key = "decoder." + key
        renamed[key] = value
    return renamed


def load_model_from_checkpoint(checkpoint_path, cfg, device):
    """Rebuild the network described by a checkpoint and load its (EMA) weights; returns (model, config)."""
    state = load_checkpoint(checkpoint_path)
    ckpt_cfg = clone_config(cfg)
    # the architecture and the input geometry come from the checkpoint, everything else from CONFIG
    for key in ARCHITECTURE_KEYS:
        if key in state["config"]:
            setattr(ckpt_cfg, key, state["config"][key])
    if "DECODER_TYPE" not in state["config"]:
        ckpt_cfg.DECODER_TYPE = "fpn"
    ckpt_cfg.PRETRAINED = False
    model = KeypointNet(ckpt_cfg)
    use_ema = cfg.USE_EMA_FOR_INFERENCE and state.get("ema_state")
    model.load_state_dict(upgrade_state_dict(state["ema_state"] if use_ema else state["model_state"], state["config"]))
    model.to(device)
    if device.type == "cuda" and torch.cuda.device_count() > 1:
        model = nn.DataParallel(model)
    return model, ckpt_cfg


def run_prediction(cfg, args, device):
    """Predict mode: frames or videos of args.input -> MOT-style track files in args.output."""
    if not args.input or not args.output or not args.checkpoint:
        raise ValueError("predict mode needs --input <folder>, --output <folder> and --checkpoint <file>")
    model, ckpt_cfg = load_model_from_checkpoint(args.checkpoint, cfg, device)
    os.makedirs(args.output, exist_ok=True)
    work_dir = tempfile.mkdtemp(prefix="task3_frames_")     # decoded mp4 frames stay out of the output folder
    samples = load_prediction_samples(args.input, ckpt_cfg, work_dir)
    results = run_inference(model, samples, ckpt_cfg, device, desc="predict")
    write_submission(results, args.output, ckpt_cfg)
    LOG.info("Tracks for %d frames of %d videos written to %s", len(samples), len(results), args.output)


def parse_args():
    """Command-line interface (every CONFIG entry can also be overridden with --set)."""
    parser = argparse.ArgumentParser(description="OSS challenge - Task 3 keypoint tracking")
    parser.add_argument("--mode", choices=("train", "predict") + GRM_MODES, default=None,
                        help="overrides CONFIG.RUN_MODE")
    parser.add_argument("--input", default=None, help="predict mode: folder with videos or frames")
    parser.add_argument("--output", default=None, help="predict mode: output folder for the track files")
    parser.add_argument("--checkpoint", default=None, help="predict mode: checkpoint file (.pt)")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override any CONFIG entry")
    return parser.parse_args()


def build_config(args):
    """Working copy of CONFIG with the command-line overrides applied and the geometry checked."""
    overrides = {}
    for item in args.set:
        if "=" not in item:
            raise ValueError(f"--set expects KEY=VALUE, got '{item}'")
        key, value = item.split("=", 1)
        overrides[key.strip()] = value.strip()
    cfg = clone_config(CONFIG)
    apply_overrides(cfg, overrides)
    if args.mode:
        cfg.RUN_MODE = args.mode
    if cfg.IMG_HEIGHT % 32 or cfg.IMG_WIDTH % 32:
        raise ValueError("IMG_HEIGHT and IMG_WIDTH must be multiples of 32")
    return cfg


def main():
    """Entry point: dispatch to training, a GRM phase or prediction."""
    args = parse_args()
    cfg = build_config(args)
    export_visible_gpus(cfg)          # before the first CUDA call

    if cfg.RUN_MODE == "predict":
        setup_logging(None)
        set_seed(cfg.SEED, cfg.DETERMINISTIC)
        check_cuda_build(cfg)
        run_prediction(cfg, args, get_device(cfg))
        return

    if cfg.RUN_MODE in GRM_MODES:
        cfg.GRM_DIR = cfg.GRM_DIR or os.path.join(cfg.OUTPUT_ROOT, "grm_task3")
        log_dir = cfg.GRM_DIR
    elif cfg.RUN_MODE == "train":
        run_name = cfg.RUN_NAME or f"task3_{cfg.ENCODER.replace(':', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        log_dir = os.path.join(cfg.OUTPUT_ROOT, run_name)
    else:
        raise ValueError(f"Unknown RUN_MODE '{cfg.RUN_MODE}'")
    setup_logging(log_dir)
    LOG.info("Task 3 - keypoint tracking | mode %s | folder %s", cfg.RUN_MODE, log_dir)
    LOG.info("Configuration: %s", json.dumps(grm.to_jsonable(config_to_dict(cfg))))
    set_seed(cfg.SEED, cfg.DETERMINISTIC)
    check_cuda_build(cfg)
    device = get_device(cfg)
    start = time.time()
    if cfg.RUN_MODE == "train":
        run_training(cfg, log_dir, device)
    else:
        grm.GRMRunner(build_grm_task(cfg, device)).run(cfg.RUN_MODE)
    LOG.info("Total time: %.1f minutes", (time.time() - start) / 60)


if __name__ == "__main__":
    main()
