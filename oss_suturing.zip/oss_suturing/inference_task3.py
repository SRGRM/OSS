#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSS Challenge - Task 3 inference: keypoint tracks of hands and instruments
==========================================================================

This is the entry point of the challenge container for the keypoint tracking task:

    python inference_task3.py <input folder> <output folder>

The input folder may hold mp4 videos (sampled at TEST_FPS), one folder of png frames per video,
or a flat folder of <video>_frame_<id>.png files.

Output of a keypoint checkpoint (task3_keypoint_tracking.py)
-------------------------------------------------------------
    <output>/<video>.txt                       all frames of a video
    <output>/mot/<video>_frame_<id>.txt        one file per frame
Each line follows the annotation layout:
    frame, track_id, class_id, -1, -1, -1, -1, x1, y1, v1, x2, y2, v2, ...
with keypoints in original frame pixels and visibility 0 out of frame, 1 hidden, 2 visible.
Classes 0 left hand, 1 right hand, 2 scissors, 3 tweezers, 4 needle holder, 5 needle.

Output of a plain U-Net state dictionary (first submission)
-----------------------------------------------------------
That model segments hands and instruments as one foreground class. It is kept so that the
earlier weights remain usable; it writes <output>/<frame>_mask.png (0 background, 255
foreground) and no keypoint tracks.

Usage
-----
    python inference_task3.py /input /output
    python inference_task3.py /input /output --checkpoint runs/<run>/checkpoints/best.pt
    python inference_task3.py /input /output --set TEST_FPS=1.0 --set TTA_HFLIP=True
"""

import argparse
import os
import shutil
import sys
import tempfile
import time

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm

if __package__:
    from . import inference_common as common
    from . import task3_keypoint_tracking as kpt
else:                                       # executed as a plain script (e.g. inside the container)
    import inference_common as common  # pylint: disable=import-error
    import task3_keypoint_tracking as kpt  # pylint: disable=import-error


# ======================================================================================
#                                      CONFIG
# ======================================================================================
class CONFIG:
    """All options of Task 3 inference (edit here, or override with --set KEY=VALUE)."""

    CHECKPOINTS = ["task3_keypoint_model.pt"]  # one checkpoint file (absolute, or relative to the weights folder): a task3_keypoint_tracking.py checkpoint or a plain U-Net state dictionary
    GPU_IDS = [0]                              # physical GPU ids to use, e.g. [0] | [0, 1] (DataParallel) | [] (CPU only)
    USE_AMP = True                             # True: fp16 autocast on CUDA (faster) | False: full fp32
    BATCH_SIZE = 8                             # frames per forward pass
    NUM_WORKERS = 4                            # DataLoader worker processes (0 = main process)
    TEST_FPS = 1.0                             # sampling rate for mp4 input (the test annotations are at 1 fps)
    MP4_FRAME_NUMBERING = "original"           # frame ids for mp4 input: "original" (index inside the video) | "sequential" (0, 1, 2, ... of the sampled frames)
    KEEP_EXTRACTED_FRAMES = False              # True: keep the png frames decoded from mp4 input in <output>/extracted_frames | False: temporary folder
    USE_EMA_WEIGHTS = True                     # keypoint checkpoints: True: EMA weights when stored | False: raw weights
    TTA_HFLIP = False                          # keypoint checkpoints: True: average with the flipped frame (hands swapped back) | False
    PEAK_THRESHOLD = 0.25                      # keypoint checkpoints: minimum heatmap value for a present keypoint
    OUT_OF_FRAME_IF_NO_PEAK = True             # keypoint checkpoints: True: keypoints without a peak are flagged out of frame | False: trust the visibility head
    MAX_NEEDLE_INSTANCES = 2                   # keypoint checkpoints: maximum needles per frame
    TRACK_MAX_DISTANCE = 0.15                  # keypoint checkpoints: needle association gate, fraction of the frame diagonal
    TRACK_MISS_WINDOW = 3                      # keypoint checkpoints: frames a needle track survives without a match
    TRACK_SMOOTHING = 0.0                      # keypoint checkpoints: exponential smoothing of track coordinates (0 = none)
    PLAIN_IMG_HEIGHT = 512                     # U-Net state dictionaries: input height (as trained)
    PLAIN_IMG_WIDTH = 512                      # U-Net state dictionaries: input width (as trained)
    PLAIN_MASK_THRESHOLD = 0.5                 # U-Net state dictionaries: foreground probability threshold
    PLAIN_MASK_AT_FRAME_SIZE = True            # U-Net state dictionaries: True: masks resized to the frame size | False: masks at network resolution
    SEED = 42                                  # random seed (inference is deterministic)


LOG = kpt.LOG
DECODING_KEYS = ("TEST_FPS", "MP4_FRAME_NUMBERING", "TTA_HFLIP", "PEAK_THRESHOLD", "OUT_OF_FRAME_IF_NO_PEAK",
                 "MAX_NEEDLE_INSTANCES", "TRACK_MAX_DISTANCE", "TRACK_MISS_WINDOW", "TRACK_SMOOTHING")


# ======================================================================================
#                          U-Net of the first submission (segmentation)
# ======================================================================================
class DoubleConv(nn.Module):
    """Two 3x3 convolutions, each followed by batch norm and ReLU."""

    def __init__(self, in_channels, out_channels):
        """Build the two convolution blocks."""
        super().__init__()
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True))

    def forward(self, features):
        """Apply both blocks."""
        return self.double_conv(features)


class UNet(nn.Module):
    """Four-level U-Net with transposed-convolution upsampling (parameter names match the saved weights)."""

    def __init__(self, in_channels=3, num_classes=1, base_features=64):
        """Build encoder, decoder and the 1x1 output convolution."""
        super().__init__()
        widths = [base_features * factor for factor in (1, 2, 4, 8, 16)]
        self.inc = DoubleConv(in_channels, widths[0])
        self.down1 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(widths[0], widths[1]))
        self.down2 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(widths[1], widths[2]))
        self.down3 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(widths[2], widths[3]))
        self.down4 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(widths[3], widths[4]))
        self.up1 = nn.ConvTranspose2d(widths[4], widths[3], kernel_size=2, stride=2)
        self.conv1 = DoubleConv(widths[4], widths[3])
        self.up2 = nn.ConvTranspose2d(widths[3], widths[2], kernel_size=2, stride=2)
        self.conv2 = DoubleConv(widths[3], widths[2])
        self.up3 = nn.ConvTranspose2d(widths[2], widths[1], kernel_size=2, stride=2)
        self.conv3 = DoubleConv(widths[2], widths[1])
        self.up4 = nn.ConvTranspose2d(widths[1], widths[0], kernel_size=2, stride=2)
        self.conv4 = DoubleConv(widths[1], widths[0])
        self.outc = nn.Conv2d(widths[0], num_classes, kernel_size=1)

    @staticmethod
    def _merge(upsampled, skip, conv):
        """Match the skip connection size, concatenate and convolve."""
        if upsampled.shape[-2:] != skip.shape[-2:]:
            upsampled = F.interpolate(upsampled, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return conv(torch.cat([skip, upsampled], dim=1))

    def forward(self, images):
        """(B, 3, H, W) -> (B, num_classes, H, W) logits."""
        level1 = self.inc(images)
        level2 = self.down1(level1)
        level3 = self.down2(level2)
        level4 = self.down3(level3)
        bottom = self.down4(level4)
        decoded = self._merge(self.up1(bottom), level4, self.conv1)
        decoded = self._merge(self.up2(decoded), level3, self.conv2)
        decoded = self._merge(self.up3(decoded), level2, self.conv3)
        decoded = self._merge(self.up4(decoded), level1, self.conv4)
        return self.outc(decoded)


def build_plain_unet(state_dict):
    """Rebuild the U-Net from a state dictionary (base width and class count read from the weights)."""
    state_dict = common.strip_parallel_prefix(state_dict)
    if "inc.double_conv.0.weight" not in state_dict:
        raise ValueError("The state dictionary is neither a keypoint checkpoint nor the U-Net segmentation model")
    base_features = state_dict["inc.double_conv.0.weight"].shape[0]
    num_classes = state_dict["outc.weight"].shape[0]
    model = UNet(in_channels=3, num_classes=num_classes, base_features=base_features)
    model.load_state_dict(state_dict)
    return model


@torch.no_grad()
def run_plain_segmentation(state_dict, samples, cfg, device, output_dir):
    """Write one foreground mask per frame with the U-Net of the first submission."""
    model = common.wrap_data_parallel(build_plain_unet(state_dict), device).eval()
    LOG.info("Plain U-Net state dictionary: input %dx%d, threshold %.2f", cfg.PLAIN_IMG_WIDTH, cfg.PLAIN_IMG_HEIGHT,
             cfg.PLAIN_MASK_THRESHOLD)
    os.makedirs(output_dir, exist_ok=True)
    for start in tqdm(range(0, len(samples), cfg.BATCH_SIZE), desc="segmenting", unit="batch"):
        batch = samples[start:start + cfg.BATCH_SIZE]
        images = []
        for sample in batch:
            rgb = cv2.cvtColor(cv2.imread(sample["image"], cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)
            resized = cv2.resize(rgb, (cfg.PLAIN_IMG_WIDTH, cfg.PLAIN_IMG_HEIGHT), interpolation=cv2.INTER_LINEAR)
            images.append(resized.astype(np.float32) / 255.0)
        tensor = torch.from_numpy(np.stack(images).transpose(0, 3, 1, 2)).to(device)
        foreground = torch.sigmoid(model(tensor)[:, 0].float()) > cfg.PLAIN_MASK_THRESHOLD
        for sample, mask in zip(batch, foreground.cpu().numpy()):
            mask = mask.astype(np.uint8) * 255
            if cfg.PLAIN_MASK_AT_FRAME_SIZE:
                mask = cv2.resize(mask, (sample["width"], sample["height"]), interpolation=cv2.INTER_NEAREST)
            stem = os.path.splitext(os.path.basename(sample["image"]))[0]
            if not cv2.imwrite(os.path.join(output_dir, f"{stem}_mask.png"), mask):
                raise RuntimeError(f"Mask could not be written for {sample['image']}")


# ======================================================================================
#                                        main
# ======================================================================================
def keypoint_config(cfg):
    """Configuration of task3_keypoint_tracking.py with the inference options of this script."""
    kpt_cfg = kpt.clone_config(kpt.CONFIG)
    kpt_cfg.GPU_IDS, kpt_cfg.USE_AMP, kpt_cfg.SEED = cfg.GPU_IDS, cfg.USE_AMP, cfg.SEED
    kpt_cfg.NUM_WORKERS, kpt_cfg.INFER_BATCH_SIZE = cfg.NUM_WORKERS, cfg.BATCH_SIZE
    kpt_cfg.USE_EMA_FOR_INFERENCE = cfg.USE_EMA_WEIGHTS
    for key in DECODING_KEYS:
        setattr(kpt_cfg, key, getattr(cfg, key))
    return kpt_cfg


def predict(input_dir, output_dir, cfg, checkpoint_paths, device):
    """Run the checkpoint on every frame of `input_dir` and write tracks (or masks) to `output_dir`."""
    if len(checkpoint_paths) != 1:
        raise ValueError("Task 3 inference takes exactly one checkpoint")
    checkpoint_path = checkpoint_paths[0]
    state = common.read_checkpoint(checkpoint_path)
    kind = common.checkpoint_kind(state)
    LOG.info("Checkpoint %s (%s)", checkpoint_path, kind)
    os.makedirs(output_dir, exist_ok=True)
    work_dir = output_dir if cfg.KEEP_EXTRACTED_FRAMES else tempfile.mkdtemp(prefix="task3_frames_")
    try:
        kpt_cfg = keypoint_config(cfg)
        if kind == "pipeline":
            model, ckpt_cfg = kpt.load_model_from_checkpoint(checkpoint_path, kpt_cfg, device)
            LOG.info("Keypoint checkpoint: encoder %s, input %dx%d", ckpt_cfg.ENCODER, ckpt_cfg.IMG_WIDTH,
                     ckpt_cfg.IMG_HEIGHT)
            samples = kpt.load_prediction_samples(input_dir, ckpt_cfg, work_dir)
            results = kpt.run_inference(model, samples, ckpt_cfg, device, desc="predict")
            kpt.write_submission(results, output_dir, ckpt_cfg)
            LOG.info("Tracks for %d frames of %d videos written", len(samples), len(results))
        else:
            samples = kpt.load_prediction_samples(input_dir, kpt_cfg, work_dir)
            run_plain_segmentation(state, samples, cfg, device, output_dir)
            LOG.info("Masks for %d frames written", len(samples))
    finally:
        if not cfg.KEEP_EXTRACTED_FRAMES:
            shutil.rmtree(work_dir, ignore_errors=True)


def parse_args(argv=None):
    """Command-line interface: input folder, output folder, optional checkpoint and overrides."""
    parser = argparse.ArgumentParser(description="OSS challenge - Task 3 keypoint tracking inference")
    parser.add_argument("input_dir", help="folder with mp4 videos or png frames")
    parser.add_argument("output_dir", help="folder for the track files")
    parser.add_argument("--checkpoint", action="append", default=[], help="checkpoint file")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override a CONFIG entry")
    return parser.parse_args(argv)


def main(argv=None):
    """Entry point used by docker/Process_SkillEval.sh and the oss-infer-task3 command."""
    args = parse_args(argv)
    cfg = common.config_namespace(CONFIG)
    common.apply_overrides(cfg, args.set)
    common.export_visible_gpus(cfg.GPU_IDS)
    kpt.setup_logging(None)
    kpt.set_seed(cfg.SEED, deterministic=True)
    device = common.select_device(cfg.GPU_IDS)
    LOG.info("Task 3 inference | device %s | input %s | output %s", device, args.input_dir, args.output_dir)
    checkpoint_paths = common.resolve_checkpoints(cfg, args.checkpoint)
    start = time.time()
    predict(args.input_dir, args.output_dir, cfg, checkpoint_paths, device)
    LOG.info("Finished in %.1f s; results in %s", time.time() - start, args.output_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
