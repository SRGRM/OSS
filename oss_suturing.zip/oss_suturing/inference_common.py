# -*- coding: utf-8 -*-
"""
Shared helpers of the three inference entry points (inference_task1/2/3.py).

The entry points are what the challenge container runs. Each of them accepts two kinds of
checkpoint and detects the kind automatically:

* pipeline checkpoints - written by the training scripts of this repository (a dictionary with
  the configuration, the raw weights and the EMA weights). The network, the frame sampling and
  the decoding are rebuilt from the stored configuration, so inference always matches training.
* plain state dictionaries - the format of the first submissions (a bare r2plus1d_18 with its
  classifier replaced for Tasks 1 and 2, a U-Net for the segmentation model). They are handled
  with the preprocessing those models were trained with.

Everything here is task independent: device selection, override parsing, checkpoint inspection,
video listing, the frame sampler of the plain models and the CSV writer.
"""

import ast
import os
import types

import cv2
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset

VIDEO_EXTENSIONS = (".mp4", ".avi", ".mov", ".mkv")
KINETICS_MEAN = (0.43216, 0.394666, 0.37645)   # normalisation of the Kinetics-400 video models
KINETICS_STD = (0.22803, 0.22145, 0.216989)


# ======================================================================================
#                                  configuration helpers
# ======================================================================================
def default_weights_dir():
    """
    Folder that holds the model weights.

    OSS_WEIGHTS_DIR wins when it is set. Otherwise the folder "weights" next to the code folder
    is used, which is <repository>/weights in a checkout and /app/weights inside the container.
    """
    if os.environ.get("OSS_WEIGHTS_DIR"):
        return os.environ["OSS_WEIGHTS_DIR"]
    code_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(os.path.dirname(code_dir), "weights")


def config_namespace(config_class):
    """Independent namespace copy of an upper-case CONFIG class."""
    return types.SimpleNamespace(**{key: getattr(config_class, key) for key in dir(config_class) if key.isupper()})


def apply_overrides(cfg, items):
    """Apply 'KEY=VALUE' strings to a configuration namespace; values are parsed as Python literals."""
    for item in items:
        if "=" not in item:
            raise ValueError(f"--set expects KEY=VALUE, got '{item}'")
        key, raw_value = (part.strip() for part in item.split("=", 1))
        if not hasattr(cfg, key):
            raise KeyError(f"Unknown CONFIG entry '{key}'")
        try:
            value = ast.literal_eval(raw_value)
        except (ValueError, SyntaxError):
            value = raw_value                     # plain string such as a path or a mode name
        setattr(cfg, key, value)


def resolve_checkpoints(cfg, cli_checkpoints):
    """
    Checkpoint paths of the run: the --checkpoint arguments when given, otherwise CONFIG.CHECKPOINTS.
    Relative names are looked up in the weights folder; a missing file stops the program.
    """
    names = list(cli_checkpoints) if cli_checkpoints else list(cfg.CHECKPOINTS)
    if not names:
        raise ValueError("No checkpoint given: set CONFIG.CHECKPOINTS or pass --checkpoint")
    paths = []
    for name in names:
        path = name if os.path.isabs(name) or os.path.isfile(name) else os.path.join(default_weights_dir(), name)
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Checkpoint not found: {path}")
        paths.append(path)
    return paths


def export_visible_gpus(gpu_ids):
    """Expose only the listed GPUs (must run before the first CUDA call)."""
    os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str(gpu_id) for gpu_id in gpu_ids)


def select_device(gpu_ids):
    """cuda:0 (the first id of gpu_ids after export_visible_gpus) when a GPU is usable, otherwise the CPU."""
    if gpu_ids and torch.cuda.is_available():
        return torch.device("cuda:0")
    return torch.device("cpu")


def wrap_data_parallel(model, device):
    """Move the model to the device and wrap it in DataParallel when several GPUs are visible."""
    model.to(device)
    if device.type == "cuda" and torch.cuda.device_count() > 1:
        return nn.DataParallel(model)
    return model


# ======================================================================================
#                                  checkpoint inspection
# ======================================================================================
def read_checkpoint(path):
    """Load a checkpoint onto the CPU (full pickle: only load trusted files)."""
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:                         # torch < 1.13 has no weights_only argument
        return torch.load(path, map_location="cpu")


def checkpoint_kind(state):
    """
    'pipeline' for checkpoints of the training scripts, 'state_dict' for bare weight dictionaries.
    Anything else stops the program with an explanation.
    """
    if isinstance(state, dict) and "model_state" in state and "config" in state:
        return "pipeline"
    if isinstance(state, dict) and state and all(torch.is_tensor(value) for value in state.values()):
        return "state_dict"
    raise ValueError("Unrecognised checkpoint: expected a training checkpoint of this repository "
                     "or a plain PyTorch state dictionary")


def strip_parallel_prefix(state_dict):
    """Remove the 'module.' prefix that DataParallel adds to parameter names."""
    if all(key.startswith("module.") for key in state_dict):
        return {key[len("module."):]: value for key, value in state_dict.items()}
    return state_dict


def build_plain_r2plus1d(state_dict, expected_outputs, task_name):
    """
    Rebuild a bare r2plus1d_18 whose final layer was replaced by Linear(512, expected_outputs)
    and load the weights; a different output size stops the program.
    """
    from torchvision.models.video import r2plus1d_18
    state_dict = strip_parallel_prefix(state_dict)
    if "fc.weight" not in state_dict:
        raise ValueError(f"The {task_name} state dictionary has no 'fc.weight'; it is not an r2plus1d_18 classifier")
    outputs = state_dict["fc.weight"].shape[0]
    if outputs != expected_outputs:
        raise ValueError(f"The {task_name} model has {outputs} outputs, expected {expected_outputs}")
    model = r2plus1d_18()
    model.fc = nn.Linear(model.fc.in_features, expected_outputs)
    model.load_state_dict(state_dict)
    return model


# ======================================================================================
#                                   videos and frames
# ======================================================================================
def list_video_files(folder):
    """Sorted paths of all video files in a folder; an empty or missing folder stops the program."""
    if not os.path.isdir(folder):
        raise FileNotFoundError(f"Input folder not found: {folder}")
    files = sorted(name for name in os.listdir(folder) if name.lower().endswith(VIDEO_EXTENSIONS))
    if not files:
        raise FileNotFoundError(f"No video files ({', '.join(VIDEO_EXTENSIONS)}) found in {folder}")
    return [os.path.join(folder, name) for name in files]


def video_id(path):
    """Video identifier written to the result files: the file name without extension."""
    return os.path.splitext(os.path.basename(path))[0]


def sample_uniform_frames(path, num_frames):
    """
    Read `num_frames` evenly spaced RGB frames of a video with OpenCV.
    Returns None when the video cannot be opened, is too short or a frame cannot be decoded.
    """
    capture = cv2.VideoCapture(path)
    try:
        if not capture.isOpened():
            return None
        total = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        if total < num_frames:
            return None
        frames = []
        for index in np.linspace(0, total - 1, num_frames, dtype=int):
            capture.set(cv2.CAP_PROP_POS_FRAMES, int(index))
            success, bgr = capture.read()
            if not success or bgr is None:
                return None
            frames.append(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
        return frames
    finally:
        capture.release()


class UniformClipDataset(Dataset):
    """
    Clips for the plain r2plus1d_18 models, prepared exactly as those models were trained:
    `num_frames` evenly spaced frames, each resized to a square of `img_size` pixels and
    normalised with the Kinetics statistics. Returns (clip (3, T, S, S), index).
    Unreadable videos must be removed beforehand (see find_unreadable_videos).
    """

    def __init__(self, paths, num_frames, img_size):
        """Store the video paths and the clip geometry."""
        from torchvision import transforms
        self.paths, self.num_frames = paths, num_frames
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Resize((img_size, img_size)),
            transforms.Normalize(mean=KINETICS_MEAN, std=KINETICS_STD),
        ])

    def __len__(self):
        """Number of videos."""
        return len(self.paths)

    def __getitem__(self, index):
        """Decode and normalise the clip of one video."""
        frames = sample_uniform_frames(self.paths[index], self.num_frames)
        if frames is None:
            raise RuntimeError(f"Video could not be decoded: {self.paths[index]}")
        clip = torch.stack([self.transform(frame) for frame in frames])     # (T, 3, S, S)
        return clip.permute(1, 0, 2, 3), index


def find_unreadable_videos(paths, num_frames):
    """Paths whose first, middle and last sampled frames cannot be read (cheap pre-check)."""
    return [path for path in paths if sample_uniform_frames(path, min(num_frames, 3)) is None]


def handle_unreadable(unreadable, policy, log):
    """Stop on unreadable videos (policy 'error') or log them before a fallback prediction ('fallback')."""
    if not unreadable:
        return
    listing = ", ".join(os.path.basename(path) for path in unreadable[:10])
    if policy == "error":
        raise RuntimeError(f"{len(unreadable)} video(s) cannot be decoded: {listing}. "
                           "Set ON_UNREADABLE_VIDEO = 'fallback' to write a default prediction instead.")
    if policy != "fallback":
        raise ValueError(f"Unknown ON_UNREADABLE_VIDEO '{policy}'")
    log.warning("%d video(s) cannot be decoded and receive the fallback prediction: %s", len(unreadable), listing)


@torch.no_grad()
def run_plain_video_model(model, paths, cfg, device):
    """Raw outputs (N, C) of a plain r2plus1d_18 model, in the order of `paths`."""
    from tqdm import tqdm
    loader = DataLoader(UniformClipDataset(paths, cfg.PLAIN_NUM_FRAMES, cfg.PLAIN_IMG_SIZE),
                        batch_size=cfg.BATCH_SIZE, shuffle=False, num_workers=cfg.NUM_WORKERS,
                        pin_memory=device.type == "cuda")
    model.eval()
    outputs = [None] * len(paths)
    for clips, indices in tqdm(loader, desc="predicting", unit="batch"):
        logits = model(clips.to(device, non_blocking=True)).float().cpu().numpy()
        for position, index in enumerate(indices.tolist()):
            outputs[index] = logits[position]
    return np.stack(outputs)


def write_results(rows, output_dir, file_name):
    """Write the result rows (list of dicts, one per video) as CSV and return the file path."""
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, file_name)
    pd.DataFrame(rows).to_csv(path, index=False)
    return path
