# -*- coding: utf-8 -*-
"""
Clip encoders of Tasks 1 and 2.

Two families are available through CONFIG.BACKBONE:

* video networks (torchvision, Kinetics-400 weights) that read the whole clip at once:
  r2plus1d_18, r3d_18, mc3_18, s3d, mvit_v1_b, mvit_v2_s, swin3d_t, swin3d_s, swin3d_b;
* image networks (torchvision, ImageNet weights, or any timm model as "timm:<name>") applied
  to every frame, followed by a temporal head that turns the frame features into one clip
  feature (CONFIG.TEMPORAL_HEAD: mean, max, attention, lstm, gru, transformer, tcn).

build_clip_encoder(cfg) returns (encoder, feature_dim); every encoder maps a clip tensor
(B, 3, T, H, W) to a feature tensor (B, feature_dim). normalization_stats(cfg) returns the
mean / std the selected weights were trained with, so that the dataset normalises frames the
same way as the pre-training did.
"""

import functools

import torch
import torch.nn as nn

# name -> (weights enum in torchvision.models.video, weights tag)
VIDEO_BACKBONES = {
    "r2plus1d_18": ("R2Plus1D_18_Weights", "KINETICS400_V1"),
    "r3d_18": ("R3D_18_Weights", "KINETICS400_V1"),
    "mc3_18": ("MC3_18_Weights", "KINETICS400_V1"),
    "s3d": ("S3D_Weights", "KINETICS400_V1"),
    "mvit_v1_b": ("MViT_V1_B_Weights", "KINETICS400_V1"),
    "mvit_v2_s": ("MViT_V2_S_Weights", "KINETICS400_V1"),
    "swin3d_t": ("Swin3D_T_Weights", "KINETICS400_V1"),
    "swin3d_s": ("Swin3D_S_Weights", "KINETICS400_V1"),
    "swin3d_b": ("Swin3D_B_Weights", "KINETICS400_V1"),
}

# name -> weights enum in torchvision.models (the DEFAULT, i.e. best ImageNet weights, is used)
IMAGE_BACKBONES = {
    "resnet18": "ResNet18_Weights", "resnet34": "ResNet34_Weights", "resnet50": "ResNet50_Weights",
    "resnet101": "ResNet101_Weights", "resnext50_32x4d": "ResNeXt50_32X4D_Weights",
    "wide_resnet50_2": "Wide_ResNet50_2_Weights", "densenet121": "DenseNet121_Weights",
    "efficientnet_b0": "EfficientNet_B0_Weights", "efficientnet_b1": "EfficientNet_B1_Weights",
    "efficientnet_b2": "EfficientNet_B2_Weights", "efficientnet_b3": "EfficientNet_B3_Weights",
    "efficientnet_v2_s": "EfficientNet_V2_S_Weights", "mobilenet_v3_large": "MobileNet_V3_Large_Weights",
    "regnet_y_800mf": "RegNet_Y_800MF_Weights", "regnet_y_1_6gf": "RegNet_Y_1_6GF_Weights",
    "regnet_y_3_2gf": "RegNet_Y_3_2GF_Weights", "convnext_tiny": "ConvNeXt_Tiny_Weights",
    "convnext_small": "ConvNeXt_Small_Weights", "convnext_base": "ConvNeXt_Base_Weights",
    "vit_b_16": "ViT_B_16_Weights", "swin_t": "Swin_T_Weights", "swin_s": "Swin_S_Weights",
    "swin_v2_t": "Swin_V2_T_Weights",
}

TEMPORAL_HEADS = ("mean", "max", "attention", "lstm", "gru", "transformer", "tcn")
KINETICS_STATS = ((0.43216, 0.394666, 0.37645), (0.22803, 0.22145, 0.216989))
IMAGENET_STATS = ((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
FIXED_INPUT = {"mvit_v1_b": (16, 224), "mvit_v2_s": (16, 224), "vit_b_16": (None, 224)}


def is_video_backbone(name):
    """True for networks that read the whole clip, False for frame-wise image networks."""
    return name in VIDEO_BACKBONES


def check_backbone_name(name):
    """Stop with the list of valid names when BACKBONE is unknown."""
    if name in VIDEO_BACKBONES or name in IMAGE_BACKBONES or name.startswith("timm:"):
        return
    raise ValueError(f"Unknown BACKBONE '{name}'. Video networks: {sorted(VIDEO_BACKBONES)}; "
                     f"image networks: {sorted(IMAGE_BACKBONES)}; or 'timm:<model name>'")


def create_torchvision_model(namespace, name, weights_enum, weights_tag, pretrained):
    """
    Instantiate a torchvision model with or without pre-trained weights. torchvision >= 0.13 selects
    weights through enums (e.g. R2Plus1D_18_Weights.KINETICS400_V1); older releases use `pretrained=`.
    """
    if not hasattr(namespace, name):
        raise ValueError(f"'{name}' is not available in this torchvision version")
    constructor = getattr(namespace, name)
    enum = getattr(namespace, weights_enum, None)
    if enum is not None:
        return constructor(weights=getattr(enum, weights_tag) if pretrained else None)
    return constructor(pretrained=pretrained)


def normalization_stats(cfg):
    """
    (mean, std) used to normalise the frames.

    NORMALIZATION = "auto" takes the statistics of the selected pre-trained weights (Kinetics
    statistics for R(2+1)D / R3D / MC3 / S3D, 0.45 / 0.225 for MViT, ImageNet statistics for
    Swin3D and the image networks); "kinetics" and "imagenet" force one of the two common sets.
    """
    mode = getattr(cfg, "NORMALIZATION", "auto")
    if mode == "kinetics":
        return KINETICS_STATS
    if mode == "imagenet":
        return IMAGENET_STATS
    if mode != "auto":
        raise ValueError(f"Unknown NORMALIZATION '{mode}'")
    name = cfg.BACKBONE
    if name.startswith("timm:"):
        return timm_stats(name[len("timm:"):])
    try:
        if name in VIDEO_BACKBONES:
            from torchvision.models import video as namespace
            enum_name, tag = VIDEO_BACKBONES[name]
        else:
            from torchvision import models as namespace
            enum_name, tag = IMAGE_BACKBONES[name], "DEFAULT"
        transforms = getattr(getattr(namespace, enum_name), tag).transforms()
        return tuple(transforms.mean), tuple(transforms.std)
    except (AttributeError, KeyError, TypeError):
        # torchvision < 0.13 has no weight enums: fall back to the statistics of the family
        if name in ("r2plus1d_18", "r3d_18", "mc3_18", "s3d"):
            return KINETICS_STATS
        if name.startswith("mvit"):
            return (0.45, 0.45, 0.45), (0.225, 0.225, 0.225)
        return IMAGENET_STATS


@functools.lru_cache(maxsize=None)
def timm_stats(model_name):
    """Normalisation statistics of a timm model (ImageNet statistics when timm cannot tell)."""
    try:
        import timm  # pylint: disable=import-error
        config = timm.data.resolve_data_config({}, model=timm.create_model(model_name, pretrained=False))
        return tuple(config["mean"]), tuple(config["std"])
    except Exception:  # timm missing or unknown model: the caller fails later with a clear message
        return IMAGENET_STATS


def check_input_geometry(cfg):
    """Stop early for clip sizes a backbone cannot process."""
    name = cfg.BACKBONE
    if name in FIXED_INPUT:
        frames, size = FIXED_INPUT[name]
        if (frames is not None and cfg.NUM_FRAMES != frames) or cfg.IMG_SIZE != size:
            needed = f"NUM_FRAMES = {frames} and " if frames else ""
            raise ValueError(f"{name} expects {needed}IMG_SIZE = {size}")
    if name == "s3d" and cfg.IMG_SIZE < 224:
        raise ValueError("s3d needs IMG_SIZE >= 224 (its final 7x7 pooling acts on a stride-32 feature map)")


# ======================================================================================
#                                 video networks
# ======================================================================================
def build_video_network(cfg):
    """torchvision video network with its classifier removed; returns (network, feature_dim)."""
    from torchvision.models import video as video_models
    name = cfg.BACKBONE
    enum_name, tag = VIDEO_BACKBONES[name]
    model = create_torchvision_model(video_models, name, enum_name, tag, cfg.PRETRAINED)
    if name in ("r2plus1d_18", "r3d_18", "mc3_18"):
        feature_dim = model.fc.in_features
        model.fc = nn.Identity()
    elif name == "s3d":
        feature_dim = model.classifier[1].in_channels
        model.classifier = nn.Identity()           # the forward pass then averages the pooled features
    elif name.startswith("mvit"):
        feature_dim = model.head[1].in_features
        model.head = nn.Identity()
    else:                                          # swin3d_t / swin3d_s / swin3d_b
        feature_dim = model.head.in_features
        model.head = nn.Identity()
    return model, feature_dim


# ======================================================================================
#                          image networks + temporal heads
# ======================================================================================
def strip_classifier(model):
    """Replace the final linear layer of a torchvision classification model by Identity."""
    for attribute in ("fc", "classifier", "head", "heads"):
        module = getattr(model, attribute, None)
        if module is None:
            continue
        if isinstance(module, nn.Linear):
            setattr(model, attribute, nn.Identity())
            return model
        if isinstance(module, nn.Sequential):
            linear_positions = [index for index, layer in enumerate(module) if isinstance(layer, nn.Linear)]
            if linear_positions:
                module[linear_positions[-1]] = nn.Identity()
                return model
    raise ValueError(f"Cannot find the classifier of {type(model).__name__}")


def build_image_network(cfg):
    """Frame encoder (torchvision or timm) without classifier; returns (network, feature_dim)."""
    name = cfg.BACKBONE
    if name.startswith("timm:"):
        try:
            import timm  # pylint: disable=import-error
        except ImportError as exc:
            raise ImportError("BACKBONE = 'timm:<name>' needs `pip install timm`") from exc
        model = timm.create_model(name[len("timm:"):], pretrained=cfg.PRETRAINED, num_classes=0)
        return model, model.num_features
    from torchvision import models
    model = strip_classifier(create_torchvision_model(models, name, IMAGE_BACKBONES[name], "DEFAULT",
                                                      cfg.PRETRAINED))
    was_training = model.training
    model.eval()
    with torch.no_grad():
        feature_dim = model(torch.zeros(1, 3, cfg.IMG_SIZE, cfg.IMG_SIZE)).flatten(1).shape[1]
    model.train(was_training)
    return model, feature_dim


class AttentionPooling(nn.Module):
    """Learned weighted average over time (additive attention)."""

    def __init__(self, feature_dim, hidden_dim):
        """Two-layer scoring network producing one weight per frame."""
        super().__init__()
        self.score = nn.Sequential(nn.Linear(feature_dim, hidden_dim), nn.Tanh(), nn.Linear(hidden_dim, 1))

    def forward(self, sequence):
        """(B, T, D) -> (B, D)."""
        weights = torch.softmax(self.score(sequence).squeeze(-1), dim=1)
        return (weights.unsqueeze(-1) * sequence).sum(dim=1)


class TemporalConvNet(nn.Module):
    """Stack of residual dilated 1-D convolutions followed by average pooling over time."""

    def __init__(self, feature_dim, hidden_dim, num_layers, dropout):
        """Input projection and `num_layers` residual blocks with dilation 1, 2, 4, ..."""
        super().__init__()
        self.project = nn.Conv1d(feature_dim, hidden_dim, kernel_size=1)
        self.blocks = nn.ModuleList([
            nn.Sequential(nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, padding=2 ** level, dilation=2 ** level),
                          nn.BatchNorm1d(hidden_dim), nn.ReLU(inplace=True), nn.Dropout(dropout))
            for level in range(num_layers)])

    def forward(self, sequence):
        """(B, T, D) -> (B, hidden_dim)."""
        hidden = self.project(sequence.transpose(1, 2))
        for block in self.blocks:
            hidden = hidden + block(hidden)
        return hidden.mean(dim=2)


class TransformerTemporalHead(nn.Module):
    """Transformer encoder over the frame features with a learned class token and positions."""

    def __init__(self, feature_dim, hidden_dim, num_layers, num_heads, dropout, max_frames):
        """Projection to hidden_dim, positional embeddings for max_frames + 1 tokens, encoder layers."""
        super().__init__()
        self.project = nn.Linear(feature_dim, hidden_dim) if feature_dim != hidden_dim else nn.Identity()
        self.class_token = nn.Parameter(torch.zeros(1, 1, hidden_dim))
        self.positions = nn.Parameter(torch.zeros(1, max_frames + 1, hidden_dim))
        nn.init.trunc_normal_(self.positions, std=0.02)
        layer = nn.TransformerEncoderLayer(hidden_dim, num_heads, dim_feedforward=4 * hidden_dim, dropout=dropout,
                                           batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, sequence):
        """(B, T, D) -> (B, hidden_dim), read from the class token."""
        tokens = self.project(sequence)
        tokens = torch.cat([self.class_token.expand(tokens.shape[0], -1, -1), tokens], dim=1)
        tokens = tokens + self.positions[:, :tokens.shape[1]]
        return self.norm(self.encoder(tokens)[:, 0])


class RecurrentTemporalHead(nn.Module):
    """Bidirectional LSTM / GRU over the frame features, averaged over time."""

    def __init__(self, kind, feature_dim, hidden_dim, num_layers, dropout):
        """kind is "lstm" or "gru"; the output has 2 * hidden_dim features."""
        super().__init__()
        recurrent = nn.LSTM if kind == "lstm" else nn.GRU
        self.rnn = recurrent(feature_dim, hidden_dim, num_layers=num_layers, batch_first=True, bidirectional=True,
                             dropout=dropout if num_layers > 1 else 0.0)

    def forward(self, sequence):
        """(B, T, D) -> (B, 2 * hidden_dim)."""
        outputs, _ = self.rnn(sequence)
        return outputs.mean(dim=1)


def build_temporal_head(cfg, feature_dim):
    """Temporal head selected by CONFIG.TEMPORAL_HEAD; returns (head, output_dim)."""
    kind, hidden = cfg.TEMPORAL_HEAD, cfg.TEMPORAL_HIDDEN
    if kind == "mean":
        return None, feature_dim
    if kind == "max":
        return None, feature_dim
    if kind == "attention":
        return AttentionPooling(feature_dim, hidden), feature_dim
    if kind in ("lstm", "gru"):
        return RecurrentTemporalHead(kind, feature_dim, hidden, cfg.TEMPORAL_LAYERS, cfg.TEMPORAL_DROPOUT), 2 * hidden
    if kind == "transformer":
        heads = cfg.TEMPORAL_HEADS_NUM
        if hidden % heads:
            raise ValueError("TEMPORAL_HIDDEN must be divisible by TEMPORAL_HEADS_NUM")
        return TransformerTemporalHead(feature_dim, hidden, cfg.TEMPORAL_LAYERS, heads, cfg.TEMPORAL_DROPOUT,
                                       cfg.NUM_FRAMES), hidden
    if kind == "tcn":
        return TemporalConvNet(feature_dim, hidden, cfg.TEMPORAL_LAYERS, cfg.TEMPORAL_DROPOUT), hidden
    raise ValueError(f"Unknown TEMPORAL_HEAD '{kind}'; choose from {TEMPORAL_HEADS}")


class FrameTemporalEncoder(nn.Module):
    """Image network applied to every frame, then a temporal head over the frame features."""

    def __init__(self, cfg):
        """Build the frame network and the temporal head."""
        super().__init__()
        self.frame_network, frame_dim = build_image_network(cfg)
        self.kind = cfg.TEMPORAL_HEAD
        self.temporal, self.output_dim = build_temporal_head(cfg, frame_dim)
        self.chunk = max(1, int(getattr(cfg, "FRAME_CHUNK", 0)) or 10 ** 9)

    def forward(self, clips):
        """(B, 3, T, H, W) -> (B, output_dim)."""
        batch, channels, frames, height, width = clips.shape
        images = clips.permute(0, 2, 1, 3, 4).reshape(batch * frames, channels, height, width)
        features = torch.cat([self.frame_network(part).flatten(1) for part in torch.split(images, self.chunk)])
        sequence = features.view(batch, frames, -1)
        if self.kind == "mean":
            return sequence.mean(dim=1)
        if self.kind == "max":
            return sequence.max(dim=1).values
        return self.temporal(sequence)


def build_clip_encoder(cfg):
    """Clip encoder selected by CONFIG.BACKBONE; returns (encoder, feature_dim)."""
    check_backbone_name(cfg.BACKBONE)
    check_input_geometry(cfg)
    if is_video_backbone(cfg.BACKBONE):
        return build_video_network(cfg)
    encoder = FrameTemporalEncoder(cfg)
    return encoder, encoder.output_dim


def count_parameters(module):
    """Number of trainable parameters, in millions."""
    return sum(parameter.numel() for parameter in module.parameters() if parameter.requires_grad) / 1e6


def describe_encoder(cfg, feature_dim):
    """One-line description of the clip encoder for the log."""
    if is_video_backbone(cfg.BACKBONE):
        return f"{cfg.BACKBONE} (video network, {feature_dim}-d features)"
    return f"{cfg.BACKBONE} per frame + {cfg.TEMPORAL_HEAD} temporal head ({feature_dim}-d features)"
