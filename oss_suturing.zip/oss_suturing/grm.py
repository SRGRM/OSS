# -*- coding: utf-8 -*-
"""
Generative Reward Machine (GRM) for hyper-parameter optimisation of the OSS pipelines
=====================================================================================

Choosing the architecture and the hyper-parameters of a training pipeline can be seen as a
sequential decision problem: an agent picks a configuration, the pipeline is trained and the
training log provides the reward. The reward is noisy and non-stationary (random
initialisation, data order, non-deterministic GPU kernels, a small validation set), so an agent
learning directly from it struggles. The GRM puts a learned layer between the observation and
the reward:

    true state   ts  configuration plus every source of noise (not observable)
    observation  os  the training log of a short probe run of a configuration
    mapping      s   = m(configuration)   the GRM state, e.g. the batch-size class (default,
                     as in the OSS challenge paper) or the architecture (as for StepUP)
    estimator    es  = (s, f_s(P(os)))    signals P extracted from the log are mapped by a
                     state-specific estimator f_s to an estimate of the final performance
    reward machine   internal state u in {explore, exploit}; a labelling function turns the
                     transition es -> es' into symbols {improved, plateau, diverged, invalid},
                     the machine moves u -> u' on these symbols and r_u gives the reward
    agent            Q(s, a) over GRM states and actions (the remaining hyper-parameters),
                     epsilon-greedy / UCB / softmax exploration, Q-learning or bandit updates

The search runs in phases that can be started at different times, on different machines, and
resumed after an interruption, because everything is stored in the GRM folder (GRM_DIR):

    grm_calibrate  Phase 1, offline data collection. For every GRM state, GRM_CALIBRATION_PROBES
                   random actions are trained for GRM_CALIBRATION_EPOCHS. The signals of the
                   first GRM_PROBE_EPOCHS epochs and the true performance at the end are stored
                   (probes.jsonl). Re-running continues where it stopped; GRM_CALIBRATION_STATES
                   restricts a run to some states so that machines can share the work.
    grm_merge      Imports the probes of other GRM folders (GRM_MERGE_DIRS) with the same space.
    grm_fit        Fits the reward estimator of every state on the calibration probes
                   (estimators.json) and reports their leave-one-out accuracy.
    grm_search     Phase 2, online search. Every step trains one (state, action) pair for
                   GRM_PROBE_EPOCHS only, turns the early signals into a reward through the
                   estimator and the reward machine, and updates the Q-table
                   (search_state.json). Each call runs GRM_SEARCH_STEPS more steps.
    grm_final      Picks the best configuration (Q-value, estimated reward or a short
                   verification of the top candidates) and trains it in full.
    grm_full       All phases one after another.
    grm_report     Writes grm_summary.md from whatever has been stored so far.

The training scripts provide a small adapter (GRMTask) that trains one configuration for a
given number of epochs and returns its per-epoch history; the GRM itself is task independent.

Signals (GRM_SIGNAL_PRESET):
    "oss"     early training dynamics: per-epoch train loss, validation loss and validation
              score of the first GRM_PROBE_EPOCHS epochs, their slopes, the best score and the
              loss decrease (the dynamics feature vector of the OSS challenge entry);
    "stepup"  P1 = mean epoch loss, P2 = standard deviation of all batch losses (footstep
              recognition entry), estimator Perf = w1 * P1 + w2 * P2;
    "ogb"     P1 = mean of a score metric, P2 = mean of an error metric (genomic benchmark entry);
    "custom"  any list in GRM_SIGNALS, built from the names described in signal_value().
"""

import csv
import hashlib
import itertools
import json
import math
import os
import time

import numpy as np

STATUS_OK, STATUS_INVALID, STATUS_OOM = "ok", "invalid", "oom"
RM_EXPLORE, RM_EXPLOIT = "explore", "exploit"
LABELS = ("improved", "plateau", "diverged", "invalid")
PHASES = ("grm_calibrate", "grm_merge", "grm_fit", "grm_search", "grm_final", "grm_full", "grm_report")


# ======================================================================================
#                                      utilities
# ======================================================================================
def to_jsonable(value):
    """Convert numpy scalars / arrays and non-finite floats into plain JSON values."""
    if isinstance(value, dict):
        return {str(key): to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return to_jsonable(value.tolist())
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(float(value)) else None
    return value


def write_json(path, payload):
    """Write JSON atomically (temporary file + rename), so an interruption never leaves a broken file."""
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(to_jsonable(payload), handle, indent=2)
    os.replace(temporary, path)


def read_json(path, default=None):
    """Read a JSON file, or return `default` when it does not exist."""
    if not os.path.isfile(path):
        return default
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def slope_of(values):
    """Slope of a least-squares line through the values (0 for fewer than two finite values)."""
    values = [value for value in values if value is not None and math.isfinite(value)]
    if len(values) < 2:
        return 0.0
    return float(np.polyfit(np.arange(len(values)), values, 1)[0])


def finite_or(value, default):
    """`value` when it is a finite number, otherwise `default`."""
    return value if value is not None and isinstance(value, (int, float)) and math.isfinite(value) else default


def spearman(first, second):
    """Spearman rank correlation of two sequences (0 when undefined)."""
    if len(first) < 3:
        return 0.0
    ranks_a = np.argsort(np.argsort(first)).astype(float)
    ranks_b = np.argsort(np.argsort(second)).astype(float)
    if ranks_a.std() == 0 or ranks_b.std() == 0:
        return 0.0
    return float(np.corrcoef(ranks_a, ranks_b)[0, 1])


def numeric_history(history):
    """Keep only the numeric fields of the history rows (non-finite values become None)."""
    rows = []
    for row in history:
        clean = {}
        for key, value in row.items():
            if isinstance(value, bool):
                continue
            if isinstance(value, (int, float, np.integer, np.floating)):
                clean[key] = to_jsonable(value)
        rows.append(clean)
    return rows


# ======================================================================================
#                          search space and mapping function
# ======================================================================================
class GRMSpace:
    """
    GRM states and actions.

    The mapping function sends a configuration to its GRM state: the value of GRM_STATE_KEY, or
    the name of the bin of GRM_STATE_BINS that contains it (e.g. {"small": [2, 4], "large": [8, 16]}
    for batch-size classes). Actions are combinations of the remaining keys of GRM_SEARCH_SPACE;
    with bins, the concrete value of the state key inside the bin becomes part of the action.
    When a state has more combinations than GRM_MAX_ACTIONS, a fixed random subset is used.
    """

    def __init__(self, cfg):
        """Build states and per-state action lists from the configuration."""
        space = dict(cfg.GRM_SEARCH_SPACE)
        self.state_key = cfg.GRM_STATE_KEY
        if self.state_key not in space:
            raise ValueError(f"GRM_STATE_KEY '{self.state_key}' must be one of the GRM_SEARCH_SPACE keys")
        for key in space:
            if not hasattr(cfg, key):
                raise KeyError(f"GRM_SEARCH_SPACE key '{key}' is not a CONFIG entry")
        bins = cfg.GRM_STATE_BINS
        if bins:
            self.states = [str(name) for name in bins]
            members = {str(name): list(values) for name, values in bins.items()}
        else:
            self.states = [str(value) for value in space[self.state_key]]
            members = {str(value): [value] for value in space[self.state_key]}
        self.state_members = members
        self.action_keys = [key for key in space if key != self.state_key]
        rng = np.random.default_rng(cfg.SEED)
        self.actions = {}
        for state in self.states:
            dimensions = [members[state]] + [list(space[key]) for key in self.action_keys]
            combinations = list(itertools.product(*dimensions))
            if len(combinations) > cfg.GRM_MAX_ACTIONS:
                keep = sorted(rng.choice(len(combinations), size=cfg.GRM_MAX_ACTIONS, replace=False).tolist())
                combinations = [combinations[index] for index in keep]
            self.actions[state] = [{self.state_key: combo[0], **dict(zip(self.action_keys, combo[1:]))}
                                   for combo in combinations]

    def map_configuration(self, overrides):
        """The mapping function: GRM state of a configuration."""
        value = overrides[self.state_key]
        for state, values in self.state_members.items():
            if value in values:
                return state
        raise ValueError(f"{self.state_key} = {value!r} is outside the GRM state space")

    def overrides(self, state, action_index):
        """CONFIG overrides of an action of a state."""
        return dict(self.actions[state][action_index])

    def describe(self, state, action_index):
        """Short text of an action (without the state key when it equals the state)."""
        action = self.actions[state][action_index]
        return ", ".join(f"{key}={value}" for key, value in action.items())

    def to_dict(self):
        """Serialisable description of the space."""
        return {"state_key": self.state_key, "states": self.states, "state_members": self.state_members,
                "action_keys": self.action_keys, "actions": self.actions}


# ======================================================================================
#                              signals from the training log
# ======================================================================================
SIGNAL_PRESETS = {
    "oss": ["series:train_loss", "series:val_loss", "series:selection_score", "slope:train_loss",
            "slope:val_loss", "slope:selection_score", "best:selection_score", "loss_drop"],
    "stepup": ["mean:train_loss", "std_batch_loss"],
    "ogb": ["mean:{score}", "mean:{error}"],
}


def signal_names(cfg):
    """Signal specification selected by GRM_SIGNAL_PRESET (or GRM_SIGNALS for "custom")."""
    preset = cfg.GRM_SIGNAL_PRESET
    if preset == "custom":
        names = list(cfg.GRM_SIGNALS)
    elif preset in SIGNAL_PRESETS:
        names = [name.format(score=cfg.GRM_SCORE_METRIC, error=cfg.GRM_ERROR_METRIC)
                 for name in SIGNAL_PRESETS[preset]]
    else:
        raise ValueError(f"Unknown GRM_SIGNAL_PRESET '{preset}'; choose oss, stepup, ogb or custom")
    if not names:
        raise ValueError("The GRM needs at least one signal")
    return names


def pooled_batch_std(rows):
    """Standard deviation of all batch losses, pooled from the per-epoch mean / std / batch count."""
    counts = np.array([finite_or(row.get("train_batches"), 0) for row in rows], dtype=float)
    means = np.array([finite_or(row.get("train_loss"), 0.0) for row in rows], dtype=float)
    stds = np.array([finite_or(row.get("train_loss_std"), 0.0) for row in rows], dtype=float)
    total = counts.sum()
    if total <= 0:
        return 0.0
    overall = (counts * means).sum() / total
    return float(math.sqrt(max(0.0, (counts * (stds ** 2 + (means - overall) ** 2)).sum() / total)))


def signal_value(name, rows, probe_epochs):
    """
    Value(s) of one signal over the first `probe_epochs` history rows. Supported names:

        series:<key>        the per-epoch values (edge-padded to probe_epochs entries)
        mean:<key>  last:<key>  best:<key>  worst:<key>  slope:<key>
        std_batch_loss      pooled standard deviation of all batch losses
        loss_drop           train loss of the first epoch minus that of the last epoch
        generalization_gap  last validation loss minus last train loss

    <key> is any numeric column of the training report (train_loss, val_loss, selection_score,
    val_macro_f1, val_expected_cost, val_mae, val_hota, val_pck, ...).
    """
    rows = rows[:probe_epochs]
    if name == "std_batch_loss":
        return [pooled_batch_std(rows)]
    if name == "loss_drop":
        losses = [finite_or(row.get("train_loss"), np.nan) for row in rows]
        return [float(losses[0] - losses[-1])]
    if name == "generalization_gap":
        return [finite_or(rows[-1].get("val_loss"), np.nan) - finite_or(rows[-1].get("train_loss"), np.nan)]
    if ":" not in name:
        raise ValueError(f"Unknown GRM signal '{name}'")
    kind, key = name.split(":", 1)
    values = [finite_or(row.get(key), np.nan) for row in rows]
    if all(np.isnan(values)):
        raise KeyError(f"GRM signal '{name}': column '{key}' is missing from the training history")
    if kind == "series":
        return values + [values[-1]] * (probe_epochs - len(values))
    if kind == "mean":
        return [float(np.nanmean(values))]
    if kind == "last":
        return [values[-1]]
    if kind == "best":
        return [float(np.nanmax(values))]
    if kind == "worst":
        return [float(np.nanmin(values))]
    if kind == "slope":
        return [slope_of(values)]
    raise ValueError(f"Unknown GRM signal kind '{kind}' in '{name}'")


def extract_signals(names, history, probe_epochs):
    """Signal vector P(os) of a probe history (NaN entries mark a broken run)."""
    if len(history) < 1:
        return None
    vector = []
    for name in names:
        vector.extend(signal_value(name, history, probe_epochs))
    return [float(value) for value in vector]


def true_performance(history, target, last_k):
    """Performance the estimator learns to predict, from a complete history (selection_score)."""
    scores = [finite_or(row.get("selection_score"), np.nan) for row in history]
    if not scores or all(np.isnan(scores)):
        return None
    if target == "best":
        return float(np.nanmax(scores))
    if target == "last":
        return scores[-1] if math.isfinite(scores[-1]) else None
    if target == "mean_last_k":
        return float(np.nanmean(scores[-last_k:]))
    raise ValueError(f"Unknown GRM_TARGET '{target}'")


def is_diverged(history, factor):
    """A run diverged when a loss is not finite or the train loss grew by more than `factor`."""
    losses = [row.get("train_loss") for row in history]
    if any(loss is None or not math.isfinite(loss) for loss in losses):
        return True
    return len(losses) > 1 and losses[-1] > factor * max(losses[0], 1e-8)


# ======================================================================================
#                                    reward estimators
# ======================================================================================
class RewardEstimator:
    """
    Maps a signal vector P to an estimated performance.

    kind "linear"       Perf = sum_i w_i * P_i, least squares without intercept (the form used for
                        the footstep and genomic entries, where P are loss / metric penalties)
    kind "linear_bias"  ordinary least squares with intercept
    kind "ridge"        standardised features, L2-regularised weights, intercept (default; stable
                        with few calibration runs and many signals)
    kind "huber"        ridge fitted with Huber-weighted iterations (robust to outlier runs)
    kind "knn"          mean target of the k nearest calibration runs in standardised signal space
    With prior weights (scope "shrinkage") the ridge solution is pulled towards the global fit.
    """

    def __init__(self, kind, ridge_lambda, knn_k=3):
        """Store the estimator type and its regularisation."""
        self.kind, self.ridge_lambda, self.knn_k = kind, ridge_lambda, knn_k
        self.mean = self.std = self.weights = None
        self.features = self.targets = None

    def fit(self, features, targets, prior=None):
        """Fit on (n, d) features and (n,) targets; `prior` (d + 1,) shrinks the ridge weights."""
        features = np.asarray(features, dtype=float)
        targets = np.asarray(targets, dtype=float)
        if self.kind == "linear":
            self.weights, *_ = np.linalg.lstsq(features, targets, rcond=None)
            return self
        if self.kind == "linear_bias":
            design = np.hstack([features, np.ones((len(features), 1))])
            self.weights, *_ = np.linalg.lstsq(design, targets, rcond=None)
            return self
        self.mean, self.std = features.mean(axis=0), features.std(axis=0) + 1e-8
        standardised = (features - self.mean) / self.std
        if self.kind == "knn":
            self.features, self.targets = standardised, targets
            return self
        if self.kind not in ("ridge", "huber"):
            raise ValueError(f"Unknown GRM_ESTIMATOR '{self.kind}'")
        design = np.hstack([standardised, np.ones((len(features), 1))])
        prior = np.zeros(design.shape[1]) if prior is None else np.asarray(prior, dtype=float)
        sample_weights = np.ones(len(targets))
        for _ in range(20 if self.kind == "huber" else 1):
            weighted = design * sample_weights[:, None]
            regulariser = self.ridge_lambda * np.eye(design.shape[1])
            regulariser[-1, -1] = 1e-8                  # the intercept is (almost) not regularised
            self.weights = np.linalg.solve(weighted.T @ design + regulariser,
                                           weighted.T @ targets + regulariser @ prior)
            residuals = targets - design @ self.weights
            scale = 1.4826 * np.median(np.abs(residuals)) + 1e-8
            delta = 1.345 * scale
            sample_weights = np.where(np.abs(residuals) <= delta, 1.0, delta / np.maximum(np.abs(residuals), 1e-12))
        return self

    def predict(self, features):
        """Estimated performance of one signal vector."""
        features = np.asarray(features, dtype=float)
        if self.kind == "linear":
            return float(features @ self.weights)
        if self.kind == "linear_bias":
            return float(np.append(features, 1.0) @ self.weights)
        standardised = (features - self.mean) / self.std
        if self.kind == "knn":
            distances = np.linalg.norm(self.features - standardised, axis=1)
            nearest = np.argsort(distances)[:max(1, min(self.knn_k, len(distances)))]
            return float(self.targets[nearest].mean())
        return float(np.append(standardised, 1.0) @ self.weights)

    def to_dict(self):
        """Serialisable parameters."""
        return {"kind": self.kind, "ridge_lambda": self.ridge_lambda, "knn_k": self.knn_k, "mean": self.mean,
                "std": self.std, "weights": self.weights, "features": self.features, "targets": self.targets}

    @classmethod
    def from_dict(cls, payload):
        """Rebuild an estimator stored with to_dict()."""
        estimator = cls(payload["kind"], payload["ridge_lambda"], payload.get("knn_k", 3))
        for key in ("mean", "std", "weights", "features", "targets"):
            value = payload.get(key)
            setattr(estimator, key, None if value is None else np.asarray(value, dtype=float))
        return estimator


def leave_one_out(kind, ridge_lambda, knn_k, features, targets):
    """Leave-one-out predictions of an estimator type (empty when there are fewer than 3 samples)."""
    if len(targets) < 3:
        return []
    predictions = []
    for held_out in range(len(targets)):
        keep = [index for index in range(len(targets)) if index != held_out]
        estimator = RewardEstimator(kind, ridge_lambda, knn_k).fit([features[i] for i in keep],
                                                                   [targets[i] for i in keep])
        predictions.append(estimator.predict(features[held_out]))
    return predictions


# ======================================================================================
#                                     reward machine
# ======================================================================================
class RewardMachine:
    """
    Finite-state reward machine over the estimated state.

    States: explore (looking for new regions) and exploit (refining around a good region).
    Labelling function L(es, es') on the outcome of a probe:
        invalid   the configuration could not be trained (incompatible options, out of memory)
        diverged  non-finite loss or train loss exploding by GRM_DIVERGENCE_FACTOR
        improved  estimated performance above the best estimate so far + GRM_IMPROVEMENT_MARGIN
        plateau   anything else
    Transitions: improved -> exploit; invalid / diverged -> explore; plateau keeps the state,
    but GRM_RM_PATIENCE plateaus in a row while exploiting return the machine to explore.
    Rewards r_u: explore pays the estimate plus a novelty bonus that decays with the visits of
    the pair; exploit pays the estimate; invalid / diverged pay the penalty reward.
    """

    def __init__(self, cfg, penalty, scale):
        """
        `penalty` is the reward of failed runs (None: the worst reward seen so far minus GRM_PENALTY_MARGIN times
        `scale`, used by the raw-reward baseline) and `scale` the spread of the calibration targets.
        """
        self.enabled = cfg.GRM_REWARD_MACHINE
        self.patience = cfg.GRM_RM_PATIENCE
        self.margin = cfg.GRM_IMPROVEMENT_MARGIN * scale
        self.novelty = cfg.GRM_NOVELTY_BONUS * scale
        self.penalty, self.penalty_margin = penalty, cfg.GRM_PENALTY_MARGIN * scale
        self.state, self.plateaus, self.best, self.worst = RM_EXPLORE, 0, -np.inf, np.inf

    def label(self, status, diverged, estimate):
        """Labelling function: symbol describing the transition to the new estimated state."""
        if status != STATUS_OK:
            return "invalid"
        if diverged or estimate is None:
            return "diverged"
        return "improved" if estimate > self.best + self.margin else "plateau"

    def reward(self, label, estimate, visits):
        """r_u of the current machine state for the labelled transition."""
        if label in ("invalid", "diverged"):
            if self.penalty is not None:
                return self.penalty
            return (self.worst if math.isfinite(self.worst) else 0.0) - self.penalty_margin
        if not self.enabled:
            return estimate
        if self.state == RM_EXPLORE:
            return estimate + self.novelty / math.sqrt(max(1, visits))
        return estimate

    def step(self, label, estimate):
        """Move the machine on the symbol (and track the best estimate)."""
        if estimate is not None and label in ("improved", "plateau"):
            self.best = max(self.best, estimate)
            self.worst = min(self.worst, estimate)
        if not self.enabled:
            return
        if label in ("invalid", "diverged"):
            self.state, self.plateaus = RM_EXPLORE, 0
        elif label == "improved":
            self.state, self.plateaus = RM_EXPLOIT, 0
        elif self.state == RM_EXPLOIT:
            self.plateaus += 1
            if self.plateaus >= self.patience:
                self.state, self.plateaus = RM_EXPLORE, 0

    def to_dict(self):
        """Serialisable machine state."""
        return {"state": self.state, "plateaus": self.plateaus, "best": self.best, "worst": self.worst}

    def load(self, payload):
        """Restore the machine state."""
        self.state = payload.get("state", RM_EXPLORE)
        self.plateaus = payload.get("plateaus", 0)
        best, worst = payload.get("best"), payload.get("worst")
        self.best = -np.inf if best is None else best
        self.worst = np.inf if worst is None else worst


# ======================================================================================
#                                       Q agent
# ======================================================================================
class QAgent:
    """Tabular agent over GRM states and their actions (per-state action lists)."""

    def __init__(self, cfg, space, rng):
        """Q-values start at GRM_Q_INIT; visit counts, masks and estimate sums start empty."""
        self.cfg, self.space, self.rng = cfg, space, rng
        self.q = {state: [float(cfg.GRM_Q_INIT)] * len(space.actions[state]) for state in space.states}
        self.visits = {state: [0] * len(space.actions[state]) for state in space.states}
        self.estimate_sum = {state: [0.0] * len(space.actions[state]) for state in space.states}
        self.masked = {state: [False] * len(space.actions[state]) for state in space.states}

    def valid_actions(self, state):
        """Indices of the actions of a state that are not masked as invalid."""
        valid = [index for index, masked in enumerate(self.masked[state]) if not masked]
        if not valid:
            raise RuntimeError(f"Every action of GRM state {state} is invalid; check GRM_SEARCH_SPACE")
        return valid

    def select_state(self, step, epsilon):
        """Next GRM state according to GRM_STATE_SELECTION."""
        rule, states = self.cfg.GRM_STATE_SELECTION, self.space.states
        if rule == "random":
            return states[int(self.rng.integers(len(states)))]
        if rule == "round_robin":
            return states[step % len(states)]
        if rule == "least_visited":
            totals = [sum(self.visits[state]) for state in states]
            return states[int(np.argmin(totals))]
        if rule == "greedy":
            if self.rng.random() < epsilon:
                return states[int(self.rng.integers(len(states)))]
            values = [max(self.q[state][index] for index in self.valid_actions(state)) for state in states]
            return states[int(self.rng.choice(np.flatnonzero(np.isclose(values, max(values)))))]
        raise ValueError(f"Unknown GRM_STATE_SELECTION '{rule}'")

    def select_action(self, state, epsilon):
        """Action of a state according to GRM_ACTION_POLICY (epsilon_greedy, ucb or softmax)."""
        policy, valid = self.cfg.GRM_ACTION_POLICY, self.valid_actions(state)
        values = np.array([self.q[state][index] for index in valid])
        if policy == "epsilon_greedy":
            if self.rng.random() < epsilon:
                return int(self.rng.choice(valid))
            return int(valid[int(self.rng.choice(np.flatnonzero(np.isclose(values, values.max()))))])
        if policy == "ucb":
            counts = np.array([self.visits[state][index] for index in valid], dtype=float)
            if (counts == 0).any():
                return int(valid[int(self.rng.choice(np.flatnonzero(counts == 0)))])
            bonus = self.cfg.GRM_UCB_C * np.sqrt(np.log(counts.sum() + 1.0) / counts)
            return int(valid[int(np.argmax(values + bonus))])
        if policy == "softmax":
            logits = (values - values.max()) / max(self.cfg.GRM_SOFTMAX_TEMPERATURE, 1e-8)
            probs = np.exp(logits) / np.exp(logits).sum()
            return int(valid[int(self.rng.choice(len(valid), p=probs))])
        raise ValueError(f"Unknown GRM_ACTION_POLICY '{policy}'")

    def update(self, state, action, reward, next_state):
        """Q update: bandit Q += a (r - Q) or Q-learning Q += a (r + g max Q(s', .) - Q)."""
        self.visits[state][action] += 1
        alpha = (1.0 / self.visits[state][action] if self.cfg.GRM_ALPHA_SCHEDULE == "visits"
                 else self.cfg.GRM_Q_LEARNING_RATE)
        if self.cfg.GRM_Q_UPDATE == "bandit":
            target = reward
        elif self.cfg.GRM_Q_UPDATE == "q_learning":
            target = reward + self.cfg.GRM_Q_DISCOUNT * max(self.q[next_state][index]
                                                            for index in self.valid_actions(next_state))
        else:
            raise ValueError(f"Unknown GRM_Q_UPDATE '{self.cfg.GRM_Q_UPDATE}'")
        self.q[state][action] += alpha * (target - self.q[state][action])

    def to_dict(self):
        """Serialisable tables."""
        return {"q": self.q, "visits": self.visits, "estimate_sum": self.estimate_sum, "masked": self.masked}

    def load(self, payload):
        """Restore the tables."""
        for key in ("q", "visits", "estimate_sum", "masked"):
            setattr(self, key, {state: list(values) for state, values in payload[key].items()})


# ======================================================================================
#                                    task adapter
# ======================================================================================
class GRMTask:
    """
    What the GRM needs from a training script.

    run_probe(overrides, epochs, tag, data_fraction) trains one configuration without writing
    files and returns its per-epoch history (dicts with at least train_loss, train_loss_std,
    train_batches, val_loss and selection_score - higher is better).
    train_final(overrides) trains the chosen configuration in full and writes the usual run folder.
    """

    def __init__(self, name, cfg, run_probe, train_final, log):
        """Store the callbacks of the training script."""
        self.name, self.cfg, self.run_probe, self.train_final, self.log = name, cfg, run_probe, train_final, log


# ======================================================================================
#                                    the GRM runner
# ======================================================================================
class GRMRunner:
    """Runs and resumes the GRM phases; all state lives in GRM_DIR."""

    def __init__(self, task):
        """Create or open the GRM folder and check that the stored space matches the configuration."""
        self.task, self.cfg, self.log = task, task.cfg, task.log
        cfg = self.cfg
        self.dir = cfg.GRM_DIR or os.path.join(cfg.OUTPUT_ROOT, f"grm_{task.name}")
        os.makedirs(self.dir, exist_ok=True)
        self.space = GRMSpace(cfg)
        self.signals = signal_names(cfg)
        self.paths = {name: os.path.join(self.dir, file_name) for name, file_name in (
            ("space", "space.json"), ("probes", "probes.jsonl"), ("estimators", "estimators.json"),
            ("search", "search_state.json"), ("final", "best_configuration.json"),
            ("calibration_log", "calibration_log.csv"), ("search_log", "search_log.csv"),
            ("summary", "grm_summary.md"))}
        self.signature = self._signature()
        stored = read_json(self.paths["space"])
        if stored is None:
            write_json(self.paths["space"], {"task": task.name, "signature": self.signature, "signals": self.signals,
                                             "probe_epochs": cfg.GRM_PROBE_EPOCHS, **self.space.to_dict()})
        elif stored.get("signature") != self.signature:
            raise RuntimeError(f"The GRM folder {self.dir} belongs to a different search space or signal set. "
                               "Use another GRM_DIR or restore the GRM_* settings of that search.")
        self.log.info("GRM folder %s | state key %s | %d states | %s actions | signals %s", self.dir,
                      self.space.state_key, len(self.space.states),
                      "/".join(str(len(self.space.actions[state])) for state in self.space.states), self.signals)

    def _signature(self):
        """Hash of everything that must stay fixed between phases (space, signals, probe length)."""
        payload = json.dumps(to_jsonable({"space": self.space.to_dict(), "signals": self.signals,
                                          "probe_epochs": self.cfg.GRM_PROBE_EPOCHS, "task": self.task.name}),
                             sort_keys=True)
        return hashlib.sha1(payload.encode()).hexdigest()[:16]

    # ---------------------------------------------------------------- probe storage
    def load_probes(self, phase=None):
        """All stored probes (optionally of one phase), in the order they were written."""
        probes = []
        if os.path.isfile(self.paths["probes"]):
            with open(self.paths["probes"], "r", encoding="utf-8") as handle:
                probes = [json.loads(line) for line in handle if line.strip()]
        return [probe for probe in probes if phase is None or probe["phase"] == phase]

    def save_probe(self, probe):
        """Append one probe record (one JSON line)."""
        with open(self.paths["probes"], "a", encoding="utf-8") as handle:
            handle.write(json.dumps(to_jsonable(probe)) + "\n")

    def append_csv(self, key, row):
        """Append a row to one of the CSV logs (header written once)."""
        path = self.paths[key]
        new_file = not os.path.isfile(path)
        with open(path, "a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(row.keys()))
            if new_file:
                writer.writeheader()
            writer.writerow(to_jsonable(row))

    def execute_probe(self, phase, probe_id, state, action_index, epochs, data_fraction):
        """Train one configuration, classify the outcome and store the probe record."""
        overrides = self.space.overrides(state, action_index)
        self.log.info("[GRM %s] %s | state %s | %s | %d epochs", phase, probe_id, state,
                      self.space.describe(state, action_index), epochs)
        start, status, history, error = time.time(), STATUS_OK, [], ""
        try:
            history = self.task.run_probe(overrides, epochs, probe_id, data_fraction)
        except (ValueError, KeyError, NotImplementedError) as exc:
            status, error = STATUS_INVALID, str(exc)
        except RuntimeError as exc:
            if "out of memory" not in str(exc).lower():
                raise
            status, error = STATUS_OOM, "CUDA out of memory"
            release_gpu_memory()
        if error:
            self.log.warning("[GRM %s] %s cannot be trained (%s): %s", phase, probe_id, status, error)
        history = numeric_history(history)
        features = None
        if status == STATUS_OK and history:
            try:
                features = extract_signals(self.signals, history, self.cfg.GRM_PROBE_EPOCHS)
            except KeyError as exc:
                raise KeyError(f"{exc}. Choose signals that exist for task {self.task.name}") from exc
        probe = {"probe_id": probe_id, "phase": phase, "state": state, "action": action_index,
                 "overrides": overrides, "epochs": epochs, "data_fraction": data_fraction, "status": status,
                 "error": error, "history": history, "features": features,
                 "diverged": bool(status == STATUS_OK and is_diverged(history, self.cfg.GRM_DIVERGENCE_FACTOR)),
                 "target": true_performance(history, self.cfg.GRM_TARGET, self.cfg.GRM_TARGET_LAST_K)
                 if status == STATUS_OK else None, "seconds": round(time.time() - start, 1)}
        self.save_probe(probe)
        return probe

    # ---------------------------------------------------------------- phase 1: calibration
    def calibrate(self):
        """Collect calibration probes until every selected state has GRM_CALIBRATION_PROBES of them."""
        cfg = self.cfg
        states = [str(state) for state in (cfg.GRM_CALIBRATION_STATES or self.space.states)]
        unknown = [state for state in states if state not in self.space.states]
        if unknown:
            raise ValueError(f"GRM_CALIBRATION_STATES contains unknown states {unknown}")
        epochs = cfg.GRM_CALIBRATION_EPOCHS or cfg.NUM_EPOCHS
        if epochs < cfg.GRM_PROBE_EPOCHS:
            raise ValueError("GRM_CALIBRATION_EPOCHS must be at least GRM_PROBE_EPOCHS")
        done = {probe["probe_id"] for probe in self.load_probes("calibration")}
        self.log.info("GRM phase 1 (calibration): states %s, %d probes each, %d epochs per probe (signals from "
                      "the first %d)", states, cfg.GRM_CALIBRATION_PROBES, epochs, cfg.GRM_PROBE_EPOCHS)
        for state in states:
            # the actions of a state are drawn once from a seeded generator, so a resumed run
            # trains exactly the probes that are still missing
            rng = np.random.default_rng([cfg.SEED, self.space.states.index(state)])
            count = len(self.space.actions[state])
            order = rng.permutation(count).tolist()
            while len(order) < cfg.GRM_CALIBRATION_PROBES:
                order += rng.permutation(count).tolist()
            for number in range(cfg.GRM_CALIBRATION_PROBES):
                probe_id = f"calibration-{state}-{number + 1:02d}"
                if probe_id in done:
                    continue
                probe = self.execute_probe("calibration", probe_id, state, order[number], epochs,
                                           cfg.GRM_PROBE_DATA_FRACTION)
                self.append_csv("calibration_log", {
                    "probe_id": probe_id, "state": state, "action": self.space.describe(state, order[number]),
                    "status": probe["status"], "diverged": probe["diverged"], "target": probe["target"],
                    "seconds": probe["seconds"]})
                self.log.info("[GRM calibration] %s finished: status %s, true performance %s", probe_id,
                              probe["status"], probe["target"])
        self.write_summary()

    # ---------------------------------------------------------------- merge
    def merge(self):
        """Import probes of other GRM folders that use the same space (GRM_MERGE_DIRS)."""
        existing = {probe["probe_id"] for probe in self.load_probes()}
        imported = 0
        for folder in self.cfg.GRM_MERGE_DIRS:
            stored = read_json(os.path.join(folder, "space.json"))
            if stored is None or stored.get("signature") != self.signature:
                raise RuntimeError(f"{folder} is not a GRM folder of the same search space")
            with open(os.path.join(folder, "probes.jsonl"), "r", encoding="utf-8") as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    probe = json.loads(line)
                    if probe["probe_id"] not in existing:
                        self.save_probe(probe)
                        existing.add(probe["probe_id"])
                        imported += 1
        self.log.info("GRM merge: %d probes imported from %s", imported, self.cfg.GRM_MERGE_DIRS)

    # ---------------------------------------------------------------- estimator fitting
    def usable_calibration(self):
        """Calibration probes with finite signals and a true performance, grouped by state."""
        grouped = {state: [] for state in self.space.states}
        for probe in self.load_probes("calibration"):
            if probe["status"] != STATUS_OK or probe["features"] is None or probe["target"] is None:
                continue
            if probe["diverged"] or not all(math.isfinite(value) for value in probe["features"]):
                continue
            grouped.setdefault(probe["state"], []).append(probe)
        return grouped

    def fit(self):
        """Fit the state-specific reward estimators (GRM_ESTIMATOR, GRM_ESTIMATOR_SCOPE) and store them."""
        cfg = self.cfg
        grouped = self.usable_calibration()
        everything = [probe for probes in grouped.values() for probe in probes]
        if len(everything) < 2:
            raise RuntimeError("At least two successful calibration probes are needed; run grm_calibrate first")
        all_features = [probe["features"] for probe in everything]
        all_targets = [probe["target"] for probe in everything]
        global_estimator = RewardEstimator(cfg.GRM_ESTIMATOR, cfg.GRM_RIDGE_LAMBDA, cfg.GRM_KNN_K).fit(
            all_features, all_targets)
        prior = global_estimator.weights if cfg.GRM_ESTIMATOR in ("ridge", "huber") else None
        estimators, report = {}, {}
        for state in self.space.states:
            probes = grouped.get(state, [])
            features = [probe["features"] for probe in probes]
            targets = [probe["target"] for probe in probes]
            if cfg.GRM_ESTIMATOR_SCOPE == "global" or len(probes) < cfg.GRM_MIN_PROBES_PER_STATE:
                estimator, source = global_estimator, "global"
            elif cfg.GRM_ESTIMATOR_SCOPE == "per_state":
                estimator = RewardEstimator(cfg.GRM_ESTIMATOR, cfg.GRM_RIDGE_LAMBDA, cfg.GRM_KNN_K).fit(
                    features, targets)
                source = "state"
            elif cfg.GRM_ESTIMATOR_SCOPE == "shrinkage":
                estimator = RewardEstimator(cfg.GRM_ESTIMATOR, cfg.GRM_RIDGE_LAMBDA, cfg.GRM_KNN_K)
                if prior is not None:
                    # standardise with the global statistics so that the prior weights apply
                    estimator.mean, estimator.std = global_estimator.mean, global_estimator.std
                    standardised = (np.asarray(features) - estimator.mean) / estimator.std
                    design = np.hstack([standardised, np.ones((len(features), 1))])
                    regulariser = cfg.GRM_RIDGE_LAMBDA * np.eye(design.shape[1])
                    estimator.weights = np.linalg.solve(design.T @ design + regulariser,
                                                        design.T @ np.asarray(targets) + regulariser @ prior)
                else:
                    estimator.fit(features, targets)
                source = "shrinkage"
            else:
                raise ValueError(f"Unknown GRM_ESTIMATOR_SCOPE '{cfg.GRM_ESTIMATOR_SCOPE}'")
            predictions = leave_one_out(cfg.GRM_ESTIMATOR, cfg.GRM_RIDGE_LAMBDA, cfg.GRM_KNN_K, features, targets)
            estimators[state] = {"source": source, "estimator": estimator.to_dict()}
            report[state] = {
                "probes": len(probes), "source": source,
                "loo_mae": float(np.mean(np.abs(np.array(predictions) - np.array(targets)))) if predictions else None,
                "loo_spearman": spearman(predictions, targets) if predictions else None,
                "target_mean": float(np.mean(targets)) if targets else None,
                "weights": estimator.weights}
            self.log.info("GRM estimator for state %s: %s fit on %d probes, leave-one-out MAE %s, Spearman %s",
                          state, source, len(probes), report[state]["loo_mae"], report[state]["loo_spearman"])
        scale = float(np.std(all_targets)) or 1e-3
        penalty = float(min(all_targets) - cfg.GRM_PENALTY_MARGIN * scale)
        write_json(self.paths["estimators"], {"signature": self.signature, "signals": self.signals,
                                              "estimators": estimators, "report": report,
                                              "calibration_probes": len(everything), "target_scale": scale,
                                              "penalty_reward": penalty})
        self.write_summary()

    def load_estimators(self):
        """Estimators of every state, refitted when calibration probes were added since the last fit."""
        stored = read_json(self.paths["estimators"])
        usable = sum(len(probes) for probes in self.usable_calibration().values())
        if stored is None or stored.get("calibration_probes") != usable:
            self.log.info("GRM estimators are missing or outdated; fitting them now")
            self.fit()
            stored = read_json(self.paths["estimators"])
        estimators = {state: RewardEstimator.from_dict(item["estimator"]) for state, item in
                      stored["estimators"].items()}
        return estimators, stored["target_scale"], stored["penalty_reward"]

    # ---------------------------------------------------------------- phase 2: online search
    def raw_reward(self, history):
        """Reward of the plain RL baseline (GRM_REWARD_SOURCE = "raw"): a signal read straight from the log."""
        name = self.cfg.GRM_RAW_REWARD
        sign = -1.0 if name.startswith("-") else 1.0
        return sign * signal_value(name.lstrip("-"), history, self.cfg.GRM_PROBE_EPOCHS)[0]

    def search(self):
        """Run GRM_SEARCH_STEPS more steps of the online search and save the state after each step."""
        cfg = self.cfg
        if cfg.GRM_REWARD_SOURCE == "estimator":
            estimators, scale, penalty = self.load_estimators()
        elif cfg.GRM_REWARD_SOURCE == "raw":
            estimators, scale, penalty = {}, 1.0, None     # plain RL baseline: no calibration needed
        else:
            raise ValueError(f"Unknown GRM_REWARD_SOURCE '{cfg.GRM_REWARD_SOURCE}'")
        stored = read_json(self.paths["search"], {})
        rng = np.random.default_rng(cfg.SEED + 1)
        if stored.get("rng"):
            rng.bit_generator.state = stored["rng"]
        agent = QAgent(cfg, self.space, rng)
        machine = RewardMachine(cfg, penalty, scale)
        step = stored.get("step", 0)
        if stored:
            agent.load(stored["agent"])
            machine.load(stored["machine"])
            state = stored["current_state"]
        else:
            state = agent.select_state(0, cfg.GRM_EPSILON)
        last_step = min(step + cfg.GRM_SEARCH_STEPS, cfg.GRM_MAX_SEARCH_STEPS)
        self.log.info("GRM phase 2 (search): steps %d..%d of at most %d | reward %s | policy %s | update %s | "
                      "reward machine %s", step + 1, last_step, cfg.GRM_MAX_SEARCH_STEPS, cfg.GRM_REWARD_SOURCE,
                      cfg.GRM_ACTION_POLICY, cfg.GRM_Q_UPDATE, "on" if cfg.GRM_REWARD_MACHINE else "off")
        deadline = time.time() + cfg.GRM_MAX_HOURS * 3600 if cfg.GRM_MAX_HOURS else None
        while step < last_step:
            if deadline and time.time() > deadline:
                self.log.info("GRM search: time budget GRM_MAX_HOURS reached; run grm_search again to continue")
                break
            epsilon = self.epsilon(machine)
            action = agent.select_action(state, epsilon)
            probe = self.execute_probe("search", f"search-{step + 1:04d}", state, action, cfg.GRM_PROBE_EPOCHS,
                                       cfg.GRM_PROBE_DATA_FRACTION)
            estimate = None
            if probe["status"] == STATUS_OK and not probe["diverged"]:
                if cfg.GRM_REWARD_SOURCE == "estimator":
                    estimate = estimators[state].predict(probe["features"])
                else:
                    estimate = self.raw_reward(probe["history"])
            label = machine.label(probe["status"], probe["diverged"], estimate)
            machine_state = machine.state
            reward = machine.reward(label, estimate, agent.visits[state][action] + 1)
            machine.step(label, estimate)
            if label == "invalid":
                agent.masked[state][action] = True
            if estimate is not None:
                agent.estimate_sum[state][action] += estimate
            next_state = agent.select_state(step + 1, epsilon)
            agent.update(state, action, reward, next_state)
            observed = probe["history"][-1].get("selection_score") if probe["history"] else None
            self.append_csv("search_log", {
                "step": step + 1, "state": state, "action": self.space.describe(state, action),
                "status": probe["status"],
                "label": label, "machine_state": machine_state, "epsilon": round(epsilon, 4), "estimate": estimate,
                "reward": reward, "observed_score": observed, "q_value": agent.q[state][action],
                "seconds": probe["seconds"]})
            self.log.info("[GRM search] step %d | %s -> label %s | estimate %s | reward %.4f | Q %.4f | machine %s",
                          step + 1, probe["probe_id"], label, None if estimate is None else round(estimate, 4), reward,
                          agent.q[state][action], machine.state)
            step += 1
            state = next_state
            write_json(self.paths["search"], {"signature": self.signature, "step": step, "current_state": state,
                                              "agent": agent.to_dict(), "machine": machine.to_dict(),
                                              "rng": rng.bit_generator.state})
        self.write_summary()

    def epsilon(self, machine):
        """Exploration rate: per machine state when the reward machine is on, GRM_EPSILON otherwise."""
        if not self.cfg.GRM_REWARD_MACHINE:
            return self.cfg.GRM_EPSILON
        return self.cfg.GRM_EPSILON_EXPLORE if machine.state == RM_EXPLORE else self.cfg.GRM_EPSILON_EXPLOIT

    # ---------------------------------------------------------------- phase 3: final choice
    def candidates(self):
        """
        Candidates for the final choice as (comparable score, state, action, origin), best first.

        Search pairs are ordered by GRM_FINAL_SELECTION (visited Q-value or mean estimate); their comparable
        score is the mean estimated performance, which lives on the same scale as the true performance of the
        calibration probes. Calibration probes join (GRM_FINAL_INCLUDE_CALIBRATION) only when the reward comes
        from the estimators; with the raw-reward baseline the scales differ and only search pairs compete.
        """
        cfg = self.cfg
        stored = read_json(self.paths["search"])
        search = []
        if stored:
            agent = stored["agent"]
            for state in self.space.states:
                for action, visits in enumerate(agent["visits"][state]):
                    if visits == 0 or agent["masked"][state][action]:
                        continue
                    mean_estimate = agent["estimate_sum"][state][action] / visits
                    order_key = agent["q"][state][action] if cfg.GRM_FINAL_SELECTION == "q_value" else mean_estimate
                    search.append((order_key, mean_estimate, state, action))
        search.sort(key=lambda item: -item[0])
        ranked = [(mean_estimate, state, action, "search") for _, mean_estimate, state, action in search]
        same_scale = cfg.GRM_REWARD_SOURCE == "estimator"
        if (cfg.GRM_FINAL_INCLUDE_CALIBRATION and same_scale) or not ranked:
            calibration = [(probe["target"], probe["state"], probe["action"], "calibration")
                           for probes in self.usable_calibration().values() for probe in probes]
            calibration.sort(key=lambda item: -item[0])
            if cfg.GRM_FINAL_SELECTION == "q_value" and ranked:
                # the Q-best search pair competes with the best calibration probe on the performance scale
                head = max([ranked[0]] + calibration[:1], key=lambda item: item[0])
                rest = sorted([item for item in ranked + calibration if item is not head], key=lambda item: -item[0])
                ranked = [head] + rest
            else:
                ranked = sorted(ranked + calibration, key=lambda item: -item[0])
        if not ranked:
            raise RuntimeError("No usable GRM results yet; run grm_calibrate and grm_search first")
        unique, seen = [], set()
        for item in ranked:
            if (item[1], item[2]) not in seen:
                unique.append(item)
                seen.add((item[1], item[2]))
        return unique

    def choose(self):
        """Best (state, action): the top candidate, or the winner of a short verification of the top K."""
        cfg = self.cfg
        ranked = self.candidates()
        if cfg.GRM_FINAL_SELECTION in ("q_value", "estimated"):
            score, state, action, origin = ranked[0]
            self.log.info("GRM choice by %s: state %s | %s (score %.4f, from %s)", cfg.GRM_FINAL_SELECTION,
                          state, self.space.describe(state, action), score, origin)
            return state, action
        if cfg.GRM_FINAL_SELECTION != "verify_top_k":
            raise ValueError(f"Unknown GRM_FINAL_SELECTION '{cfg.GRM_FINAL_SELECTION}'")
        verified = {probe["probe_id"]: probe for probe in self.load_probes("verify")}
        results = []
        for rank, (_, state, action, _) in enumerate(ranked[:cfg.GRM_VERIFY_TOP_K]):
            probe_id = f"verify-{state}-{action:03d}"
            probe = verified.get(probe_id) or self.execute_probe("verify", probe_id, state, action,
                                                                 cfg.GRM_VERIFY_EPOCHS, 1.0)
            self.log.info("GRM verification %d/%d: %s -> %s", rank + 1, min(cfg.GRM_VERIFY_TOP_K, len(ranked)),
                          self.space.describe(state, action), probe["target"])
            if probe["target"] is not None:
                results.append((probe["target"], state, action))
        if not results:
            raise RuntimeError("None of the verified candidates could be trained")
        best = max(results, key=lambda item: item[0])
        return best[1], best[2]

    def final(self):
        """Choose the best configuration, store it and train it in full with the task's trainer."""
        state, action = self.choose()
        overrides = self.space.overrides(state, action)
        write_json(self.paths["final"], {"state": state, "action": action, "overrides": overrides,
                                         "selection": self.cfg.GRM_FINAL_SELECTION})
        self.write_summary()
        self.log.info("GRM final training with %s", overrides)
        return self.task.train_final(overrides)

    def full(self):
        """Run every phase in order (each phase resumes from what is already stored)."""
        if self.cfg.GRM_MERGE_DIRS:
            self.merge()
        if self.cfg.GRM_REWARD_SOURCE == "estimator":
            self.calibrate()
            self.fit()
        self.search()
        return self.final()

    # ---------------------------------------------------------------- report
    def write_summary(self):
        """Human-readable overview of the stored GRM state (grm_summary.md)."""
        probes = self.load_probes()
        estimators = read_json(self.paths["estimators"])
        search = read_json(self.paths["search"])
        final = read_json(self.paths["final"])
        phase_counts = {phase: sum(probe["phase"] == phase for probe in probes)
                        for phase in ("calibration", "search", "verify")}
        lines = [f"# GRM summary - {self.task.name}", "",
                 f"- state key: `{self.space.state_key}`, states: {', '.join(self.space.states)}",
                 f"- signals: {', '.join(self.signals)}",
                 f"- probes stored: {len(probes)} (calibration {phase_counts['calibration']}, "
                 f"search {phase_counts['search']}, verification {phase_counts['verify']})", ""]
        if estimators:
            lines += ["## Reward estimators", "", "| state | probes | source | LOO MAE | LOO Spearman |",
                      "|---|---|---|---|---|"]
            for state, item in estimators["report"].items():
                lines.append(f"| {state} | {item['probes']} | {item['source']} | {item['loo_mae']} | "
                             f"{item['loo_spearman']} |")
            lines.append("")
        if search:
            lines += [f"## Search ({search['step']} steps, machine state {search['machine']['state']})", "",
                      "| state | action | visits | Q | mean estimate |", "|---|---|---|---|---|"]
            agent = search["agent"]
            entries = [(agent["q"][state][action], state, action, visits)
                       for state in self.space.states for action, visits in enumerate(agent["visits"][state]) if visits]
            for q_value, state, action, visits in sorted(entries, reverse=True)[:15]:
                mean_estimate = ("invalid" if agent["masked"][state][action]
                                 else f"{agent['estimate_sum'][state][action] / visits:.4f}")
                lines.append(f"| {state} | {self.space.describe(state, action)} | {visits} | {q_value:.4f} | "
                             f"{mean_estimate} |")
            lines.append("")
        if final:
            lines += ["## Chosen configuration", "", "```", json.dumps(final["overrides"], indent=2), "```", ""]
        with open(self.paths["summary"], "w", encoding="utf-8") as handle:
            handle.write("\n".join(lines))

    def run(self, mode):
        """Dispatch one GRM mode."""
        if mode == "grm_calibrate":
            return self.calibrate()
        if mode == "grm_merge":
            return self.merge()
        if mode == "grm_fit":
            return self.fit()
        if mode == "grm_search":
            return self.search()
        if mode == "grm_final":
            return self.final()
        if mode == "grm_full":
            return self.full()
        if mode == "grm_report":
            return self.write_summary()
        raise ValueError(f"Unknown GRM mode '{mode}'; choose from {PHASES}")


def release_gpu_memory():
    """Free cached CUDA memory after an out-of-memory probe."""
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except ImportError:
        pass
