# -*- coding: utf-8 -*-
"""
Building blocks shared by the three training scripts.

* build_optimizer / build_scheduler - every optimiser and learning-rate schedule selectable in
  the CONFIG blocks (OPTIMIZER, SCHEDULER and their hyper-parameters);
* ordinal losses for the skill scores - soft ordinal targets (SORD), focal loss and the squared
  earth mover's distance, all working on the last dimension so that they serve both the
  (B, 4) GRS logits and the (B, 8, 5) OSATS logits;
* batch mixing (mixup / CutMix) for clips and sampling weights for class-balanced loaders;
* RunningStats - mean and spread of the batch losses of an epoch, one of the training-log
  signals used by the Generative Reward Machine (see grm.py).
"""

import math

import numpy as np
import torch
import torch.nn.functional as F

OPTIMIZERS = ("adamw", "adam", "nadam", "radam", "adamax", "sgd", "rmsprop", "adagrad")
SCHEDULERS = ("cosine", "cosine_restarts", "linear", "polynomial", "step", "multistep", "exponential", "onecycle",
              "plateau", "none")


# ======================================================================================
#                                optimisers and schedules
# ======================================================================================
def build_optimizer(param_groups, cfg):
    """Optimiser selected by CONFIG.OPTIMIZER for the given parameter groups (each with its own lr)."""
    name = cfg.OPTIMIZER
    decay = cfg.WEIGHT_DECAY
    betas = tuple(getattr(cfg, "BETAS", (0.9, 0.999)))
    momentum = getattr(cfg, "MOMENTUM", 0.9)
    if name == "adamw":
        return torch.optim.AdamW(param_groups, betas=betas, weight_decay=decay)
    if name == "adam":
        return torch.optim.Adam(param_groups, betas=betas, weight_decay=decay)
    if name == "adamax":
        return torch.optim.Adamax(param_groups, betas=betas, weight_decay=decay)
    if name in ("nadam", "radam"):
        constructor = getattr(torch.optim, "NAdam" if name == "nadam" else "RAdam", None)
        if constructor is None:
            raise ValueError(f"OPTIMIZER '{name}' needs torch >= 1.10")
        return constructor(param_groups, betas=betas, weight_decay=decay)
    if name == "sgd":
        return torch.optim.SGD(param_groups, momentum=momentum, nesterov=momentum > 0, weight_decay=decay)
    if name == "rmsprop":
        return torch.optim.RMSprop(param_groups, momentum=momentum, alpha=0.99, eps=1e-6, weight_decay=decay)
    if name == "adagrad":
        return torch.optim.Adagrad(param_groups, weight_decay=decay)
    raise ValueError(f"Unknown OPTIMIZER '{name}'; choose from {OPTIMIZERS}")


def warmup_factor(step, warmup_steps):
    """Linear warm-up factor in (0, 1]; 1 after the warm-up."""
    if warmup_steps > 0 and step < warmup_steps:
        return (step + 1) / warmup_steps
    return 1.0


def build_scheduler(optimizer, cfg, steps_per_epoch):
    """
    Learning-rate schedule selected by CONFIG.SCHEDULER.

    Returns (scheduler, stepped_per_batch). Batch-wise schedules share a linear warm-up of
    WARMUP_EPOCHS and decay towards MIN_LR; "plateau" is stepped once per epoch on the
    validation loss; "none" keeps the learning rate constant.
    """
    name = cfg.SCHEDULER
    total_steps = max(1, steps_per_epoch * cfg.NUM_EPOCHS)
    warmup_steps = steps_per_epoch * getattr(cfg, "WARMUP_EPOCHS", 0)
    base_lr = max(optimizer.param_groups[0]["lr"], 1e-12)
    floor = min(1.0, getattr(cfg, "MIN_LR", 0.0) / base_lr)

    def progress_of(step):
        """Fraction of the post-warm-up phase that has passed."""
        return min(1.0, max(0.0, (step - warmup_steps) / max(1, total_steps - warmup_steps)))

    if name == "cosine":
        def factor(step):
            """Warm-up, then cosine decay from 1 to the floor."""
            return warmup_factor(step, warmup_steps) * (
                floor + (1 - floor) * 0.5 * (1 + math.cos(math.pi * progress_of(step))))
    elif name == "cosine_restarts":
        period = max(1, steps_per_epoch * getattr(cfg, "RESTART_EPOCHS", 5))

        def factor(step):
            """Warm-up, then cosine cycles of RESTART_EPOCHS epochs (SGDR)."""
            phase = (max(0, step - warmup_steps) % period) / period
            return warmup_factor(step, warmup_steps) * (floor + (1 - floor) * 0.5 * (1 + math.cos(math.pi * phase)))
    elif name == "linear":
        def factor(step):
            """Warm-up, then linear decay to the floor."""
            return warmup_factor(step, warmup_steps) * (floor + (1 - floor) * (1 - progress_of(step)))
    elif name == "polynomial":
        power = getattr(cfg, "POLY_POWER", 0.9)

        def factor(step):
            """Warm-up, then polynomial decay (1 - progress) ** POLY_POWER."""
            return warmup_factor(step, warmup_steps) * (floor + (1 - floor) * (1 - progress_of(step)) ** power)
    elif name == "step":
        size = max(1, steps_per_epoch * getattr(cfg, "STEP_SIZE_EPOCHS", 5))
        gamma = getattr(cfg, "LR_GAMMA", 0.1)

        def factor(step):
            """Warm-up, then multiply by LR_GAMMA every STEP_SIZE_EPOCHS epochs."""
            return warmup_factor(step, warmup_steps) * max(floor, gamma ** (step // size))
    elif name == "multistep":
        milestones = [steps_per_epoch * epoch for epoch in getattr(cfg, "LR_MILESTONES", (10, 15))]
        gamma = getattr(cfg, "LR_GAMMA", 0.1)

        def factor(step):
            """Warm-up, then multiply by LR_GAMMA at every milestone epoch."""
            return warmup_factor(step, warmup_steps) * max(floor, gamma ** sum(step >= mark for mark in milestones))
    elif name == "exponential":
        gamma = getattr(cfg, "LR_GAMMA", 0.9)

        def factor(step):
            """Warm-up, then multiply by LR_GAMMA per epoch (applied smoothly per batch)."""
            return warmup_factor(step, warmup_steps) * max(floor, gamma ** (step / max(1, steps_per_epoch)))
    elif name == "onecycle":
        pct_start = min(0.5, max(0.05, getattr(cfg, "WARMUP_EPOCHS", 1) / max(1, cfg.NUM_EPOCHS)))
        scheduler = torch.optim.lr_scheduler.OneCycleLR(
            optimizer, max_lr=[group["lr"] for group in optimizer.param_groups], total_steps=total_steps,
            pct_start=pct_start, final_div_factor=1e3)
        return scheduler, True
    elif name == "plateau":
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode="min", factor=cfg.PLATEAU_FACTOR, patience=cfg.PLATEAU_PATIENCE,
            min_lr=getattr(cfg, "MIN_LR", 0.0))
        return scheduler, False
    elif name == "none":
        return None, False
    else:
        raise ValueError(f"Unknown SCHEDULER '{name}'; choose from {SCHEDULERS}")
    return torch.optim.lr_scheduler.LambdaLR(optimizer, factor), True


# ======================================================================================
#                                    ordinal losses
# ======================================================================================
def soft_ordinal_targets(hard, num_classes, alpha):
    """
    SORD targets: softmax(-alpha * (i - y)^2) over the classes i, so that neighbouring classes
    of the true class y receive some probability mass. `hard` holds class indices of any shape.
    """
    grid = torch.arange(num_classes, device=hard.device, dtype=torch.float32)
    distance = (grid - hard.unsqueeze(-1).float()) ** 2
    return torch.softmax(-alpha * distance, dim=-1)


def focal_loss(logits, target_dist, gamma, class_weights=None):
    """
    Focal loss with soft targets on the last dimension: -sum t * (1 - p)^gamma * log p.
    `class_weights` (C,) optionally re-weights the classes; returns the mean over all positions.
    """
    log_probs = F.log_softmax(logits.float(), dim=-1)
    modulation = (1.0 - log_probs.exp()).clamp_min(0.0) ** gamma
    terms = -(target_dist * modulation * log_probs)
    if class_weights is not None:
        terms = terms * class_weights
    return terms.sum(dim=-1).mean()


def emd_loss(logits, target_dist):
    """Squared earth mover's distance between predicted and target distributions (ordinal classes)."""
    probs = torch.softmax(logits.float(), dim=-1)
    return ((probs.cumsum(dim=-1) - target_dist.cumsum(dim=-1)) ** 2).sum(dim=-1).mean()


def expected_cost_term(logits, target_dist, cost_matrix):
    """Expected linear cost of the predicted distribution under the target distribution."""
    probs = torch.softmax(logits.float(), dim=-1)
    return ((target_dist @ cost_matrix) * probs).sum(dim=-1).mean()


def linear_cost_matrix(num_classes):
    """Cost |i - j| / (C - 1) of predicting class j for true class i (the challenge's expected-cost weights)."""
    return torch.tensor([[abs(i - j) / (num_classes - 1) for j in range(num_classes)] for i in range(num_classes)])


# ======================================================================================
#                              batch mixing and sampling
# ======================================================================================
def mix_batch(clips, cfg):
    """
    Mixup or CutMix between the clips of a batch (MIX_MODE, MIX_ALPHA, MIX_PROB).

    Returns (clips, permutation, lam); permutation is None when no mixing was applied. Targets
    are mixed by the caller as lam * y + (1 - lam) * y[permutation]. CutMix pastes the same
    spatial rectangle into every frame of the clip, and lam is the kept area fraction.
    """
    mode = getattr(cfg, "MIX_MODE", "none")
    if mode == "none" or clips.shape[0] < 2 or np.random.rand() >= getattr(cfg, "MIX_PROB", 1.0):
        return clips, None, 1.0
    if mode == "both":
        mode = "mixup" if np.random.rand() < 0.5 else "cutmix"
    lam = float(np.random.beta(cfg.MIX_ALPHA, cfg.MIX_ALPHA))
    permutation = torch.randperm(clips.shape[0], device=clips.device)
    if mode == "mixup":
        return lam * clips + (1 - lam) * clips[permutation], permutation, lam
    if mode != "cutmix":
        raise ValueError(f"Unknown MIX_MODE '{mode}'")
    height, width = clips.shape[-2:]
    cut_h, cut_w = int(height * math.sqrt(1 - lam)), int(width * math.sqrt(1 - lam))
    centre_y, centre_x = np.random.randint(height), np.random.randint(width)
    y0, y1 = max(0, centre_y - cut_h // 2), min(height, centre_y + cut_h // 2)
    x0, x1 = max(0, centre_x - cut_w // 2), min(width, centre_x + cut_w // 2)
    mixed = clips.clone()
    mixed[..., y0:y1, x0:x1] = clips[permutation][..., y0:y1, x0:x1]
    lam = 1.0 - (y1 - y0) * (x1 - x0) / float(height * width)
    return mixed, permutation, lam


def sampling_weights(labels, mode):
    """
    Per-sample weights for a WeightedRandomSampler (SAMPLER): "class_balanced" gives every class
    the same total weight, "sqrt_balanced" uses 1 / sqrt(class frequency); None for "random".
    """
    if mode == "random":
        return None
    counts = np.bincount(np.asarray(labels), minlength=max(labels) + 1).astype(np.float64)
    if mode == "class_balanced":
        per_class = 1.0 / np.maximum(counts, 1)
    elif mode == "sqrt_balanced":
        per_class = 1.0 / np.sqrt(np.maximum(counts, 1))
    else:
        raise ValueError(f"Unknown SAMPLER '{mode}'")
    return torch.as_tensor([per_class[label] for label in labels], dtype=torch.double)


class RunningStats:
    """Streaming mean and standard deviation (Welford) of the batch losses of one epoch."""

    def __init__(self):
        """Start empty."""
        self.count, self.mean, self.sum_squares = 0, 0.0, 0.0

    def add(self, value):
        """Add one batch loss."""
        self.count += 1
        delta = value - self.mean
        self.mean += delta / self.count
        self.sum_squares += delta * (value - self.mean)

    @property
    def std(self):
        """Population standard deviation (0 for fewer than two values)."""
        return math.sqrt(self.sum_squares / self.count) if self.count > 1 else 0.0
