#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSS Challenge (MICCAI EndoVis) - Task 2: OSATS score prediction
===============================================================

Purpose
-------
Train, validate and run inference for Task 2 of the Open Suturing Skills (OSS)
challenge: for every suturing video the score (1-5) of each of the eight OSATS
categories has to be predicted:

    OSATS_RESPECT        respect for tissue
    OSATS_MOTION         time and motion
    OSATS_INSTRUMENT     instrument handling
    OSATS_SUTURE         suture technique
    OSATS_FLOW           flow of operation
    OSATS_KNOWLEDGE      knowledge of specific procedure
    OSATS_PERFORMANCE    overall performance
    OSATS_FINAL_QUALITY  quality of final product

The challenge averages the three raters per video, computes the macro-averaged F1
score and the expected cost per category (five ordinal classes) and averages the
two metrics over the eight categories; both are implemented here exactly like that
and reported after every epoch, together with the per-category breakdown.

What this pipeline offers
-------------------------
* One CONFIG block at the top of the file holds every option of the pipeline;
  each entry carries a comment with its meaning and the alternatives understood
  by the code.
* Clip encoders shared with Task 1 (see video_backbones.py): Kinetics-400 video
  networks (R(2+1)D-18, R3D-18, MC3-18, S3D, MViT-v1-B, MViT-v2-S, Swin3D-T/S/B) or
  ImageNet image networks applied per frame (ResNet, EfficientNet, RegNet, ConvNeXt,
  ViT, Swin, timm models, ...) with a temporal head (mean, max, attention, LSTM, GRU,
  transformer, TCN); frames normalised with the statistics of the chosen weights.
* Four ways to model the ordinal 1-5 scores: regression (Huber / MSE / L1),
  five-way classification per category, CORAL ordinal regression, or a hybrid
  classification + regression head.
* Rater-aware targets (mean score, rounded score with label smoothing, or the
  distribution of the three individual raters); classification losses cross-entropy,
  focal, soft ordinal labels (SORD) or earth mover's distance, inverse-frequency class
  balancing and an expected-cost penalty that respects the ordinal structure.
* Auxiliary objectives that proved useful in the challenge: GRS consistency
  (the eight predicted scores should add up to the global rating) and suture
  count regression.
* Selectable frame sampling strategies on top of a one-off frame cache, grouped
  stratified validation split (all videos of one student on the same side),
  optional k-fold indexing, mixed precision, gradient accumulation, gradient
  clipping, weight EMA, eight optimisers and ten learning-rate schedules, early
  stopping, mixup / CutMix, rotation / grey-scale / blur augmentation, class-balanced
  sampling, multi-clip + flip test-time augmentation, checkpoint ensembles.
* Generative Reward Machine (GRM) hyper-parameter search (grm.py) over any subset of
  these options, run in phases that can be started at different times: calibration
  probes, estimator fitting, Q-learning search and final training.
* Every epoch writes its checkpoint, its submission file and a row in the
  training report into one run folder.
* Strict data verification: a video or annotation that cannot be loaded stops
  the program with a clear message instead of being skipped silently.

Expected input layout
---------------------
    <VIDEO_DIR>/<VIDEO>.mp4              one file per video
    <ANNOTATION_FILE>                    OSATS_MICCAI_trainset.xlsx, one row per
                                         (video, rater) pair with the eight OSATS
                                         columns, the GRS column and SUTURES

Columns are located by name (case and whitespace insensitive; the eight OSATS
columns are matched by their key words, so RESPECT, MOTION, INSTRUMENT, SUTURE,
FLOW, KNOWLEDGE, PERFORMANCE and FINAL/QUALITY are all recognised).

How to run
----------
    python task2_osats_prediction.py                         # RUN_MODE from CONFIG
    python task2_osats_prediction.py --mode train
    python task2_osats_prediction.py --mode grm_calibrate     # GRM phase 1 (then grm_fit, grm_search, grm_final)
    python task2_osats_prediction.py --mode grm_full          # every GRM phase in one go
    python task2_osats_prediction.py --mode predict --input /input --output /output \
                                     --checkpoint runs/<run>/checkpoints/best.pt
    python task2_osats_prediction.py --set TARGET_MODE=coral --set NUM_EPOCHS=30

`--set KEY=VALUE` overrides any CONFIG entry from the command line (values are
parsed as Python literals, strings may be given without quotes).

For the challenge container, docker/Process_SkillEval.sh calls inference_task2.py, which
loads the checkpoints written by this script (best.pt / epoch_XX.pt) and reuses the model,
the frame sampling, the decision rule and the test-time augmentation defined here.

Environment
-----------
Python >= 3.8, numpy, pandas, openpyxl, opencv-python, tqdm and PyTorch with
torchvision. The code is identical for both CUDA generations; only the wheel
index differs:

    CUDA 11.4 driver (R470 series) ->  pip install torch torchvision \
                                       --index-url https://download.pytorch.org/whl/cu118
    CUDA 12.2 driver (R535 series) ->  pip install torch torchvision \
                                       --index-url https://download.pytorch.org/whl/cu121

CONFIG.CUDA_BUILD documents which build the run was intended for; it is checked
against torch.version.cuda at start-up and a warning is printed on mismatch.

Output of a training run (one folder per run under OUTPUT_ROOT)
----------------------------------------------------------------
    config_used.json                 every CONFIG value of the run
    train.log                        full console log with time stamps
    training_report.csv / .json      one row per epoch: learning rate, losses,
                                     mean macro-F1, mean expected cost, MAE, the
                                     per-category F1 / EC, timing
    checkpoints/epoch_XX.pt          model (+ EMA) weights of every epoch
    checkpoints/best.pt, last.pt     best epoch by validation score, last epoch
    submissions/epoch_XX/            predicted scores of that epoch for the videos
                                     in PREDICT_INPUT_DIR (or the validation split)
    val_predictions/epoch_XX.csv     per-video validation predictions and targets

The GRM folder (GRM_DIR) holds space.json, probes.jsonl, estimators.json,
search_state.json, the CSV logs, best_configuration.json, grm_summary.md and the
run folder of the final training.

Coding conventions
------------------
PEP 8 naming (snake_case functions and variables, CapWords classes, UPPER_CASE
constants), 120-column lines. The only exceptions are the CONFIG entries, whose
inline comments deliberately stay on one line so that every option and its
alternatives can be read in one place, and the CONFIG class itself, which is
named like a constant because it is used as one.
"""

import argparse
import ast
import contextlib
import copy
import csv
import hashlib
import json
import logging
import math
import os
import random
import shutil
import sys
import time
import types
from collections import Counter, OrderedDict
from datetime import datetime

import cv2
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from tqdm import tqdm

if __package__:
    from . import grm
    from . import training_blocks as blocks
    from . import video_backbones
else:                                       # executed as a plain script
    import grm  # pylint: disable=import-error
    import training_blocks as blocks  # pylint: disable=import-error
    import video_backbones  # pylint: disable=import-error


# ======================================================================================
#                                      CONFIG
#   Every option of the pipeline lives here. Each entry carries a comment with its
#   meaning and the alternatives understood by the code. Nothing below this block
#   needs to be edited for a normal experiment.
# ======================================================================================
class CONFIG:
    """All options of the pipeline (edit here, or override with --set KEY=VALUE)."""

    # ---------------------------------------------------------------- run control
    RUN_MODE = "train"                 # "train": single configuration | "grm_calibrate" | "grm_merge" | "grm_fit" | "grm_search" | "grm_final" | "grm_full" | "grm_report": GRM phases (see the GRM block) | "predict": inference only
    RUN_NAME = None                    # folder name under OUTPUT_ROOT; None -> "task2_<backbone>_<timestamp>"
    OUTPUT_ROOT = "runs"               # parent folder of all run folders
    SEED = 42                          # random seed for python, numpy and torch (int)
    DETERMINISTIC = False              # True: cudnn deterministic algorithms (slower, reproducible) | False: cudnn benchmark mode (fastest)

    # ---------------------------------------------------------------- hardware
    GPU_IDS = [0]                      # physical GPU ids to expose, e.g. [0] | [0, 1] (DataParallel over both) | [] (CPU only)
    CUDA_BUILD = "cu121"               # wheel the environment was installed with: "cu118" (CUDA 11.4 driver) | "cu121" (CUDA 12.2 driver) | "cpu"; informational check only
    USE_AMP = True                     # True: automatic mixed precision on CUDA (faster, less memory) | False: full fp32
    NUM_WORKERS = 4                    # DataLoader worker processes (0 = load in the main process)
    PIN_MEMORY = True                  # True: pinned host memory for faster host->GPU copies | False
    PREFETCH_FACTOR = 2                # batches prefetched per worker (only used when NUM_WORKERS > 0)

    # ---------------------------------------------------------------- paths
    VIDEO_DIR = "data/Train/videos"                 # folder with the training videos (<VIDEO>.mp4)
    ANNOTATION_FILE = "OSATS_MICCAI_trainset.xlsx"  # annotation workbook (one row per video and rater)
    ANNOTATION_SHEET = "DATASET"                    # sheet name inside the workbook; None -> first sheet
    PREDICT_INPUT_DIR = None                        # folder of videos for which a submission is written after every epoch (e.g. "data/Test/videos"); None -> the validation split is used instead
    FRAME_CACHE_DIR = "cache/task2_frames"          # folder for the decoded frame pools (one .npy per video); None -> decode videos on the fly every epoch (slow)
    MISSING_VIDEO_POLICY = "error"                  # "error": stop when an annotated video file is missing | "skip": drop it with a warning

    # ---------------------------------------------------------------- video decoding and frame pool
    DECODER = "opencv"                 # "opencv" (cv2.VideoCapture, no extra dependency) | "decord" (faster, needs the decord package) | "torchvision" (torchvision.io.read_video, memory hungry)
    FRAME_POOL_SIZE = 64               # frames decoded per video (evenly spaced over the whole video) and kept in the cache; clips are sampled from this pool
    CACHE_IMG_SIZE = 160               # resolution (pixels, square) at which pool frames are stored; >= IMG_SIZE so that random crops are possible
    FRAME_RESIZE_MODE = "squash"       # "squash": resize to a square ignoring the aspect ratio | "center_crop": resize the short side, crop the centre | "pad": letterbox with black borders
    STRICT_DATA_CHECK = True           # True: every video is decoded once before training starts and any failure stops the program | False: failures surface during training
    MIN_VIDEO_FRAMES = 16              # a video with fewer frames than this is treated as unreadable

    # ---------------------------------------------------------------- clip construction
    NUM_FRAMES = 16                    # frames per clip fed to the encoder (MViT needs exactly 16; image networks accept any number)
    IMG_SIZE = 128                     # spatial size of the clip (pixels, square); 112 is the native R(2+1)D size, 224 for MViT / Swin3D / S3D / ViT
    FRAME_SAMPLING = "uniform"         # "uniform": evenly spaced | "end_weighted": denser towards the end of the video | "start_weighted": denser at the start | "segment_random": one random frame per segment (TSN style, uniform at test time)
    SAMPLING_POWER = 2.0               # strength of the end/start weighting (1.0 = uniform, larger = more concentrated)
    TEMPORAL_JITTER = True             # True: small random shifts of the sampled indices during training | False: fixed indices
    NORMALIZATION = "auto"             # "auto": statistics of the selected pre-trained weights | "kinetics": R(2+1)D statistics | "imagenet": ImageNet statistics

    # ---------------------------------------------------------------- augmentation (training only)
    AUG_HFLIP_PROB = 0.5               # probability of flipping the whole clip horizontally (0 disables)
    AUG_CROP_SCALE = (0.75, 1.0)       # area range of the random resized crop applied identically to all frames; (1.0, 1.0) disables cropping
    AUG_ROTATION_DEG = 0.0             # max rotation in degrees, identical for all frames of a clip (0 disables)
    AUG_BRIGHTNESS = 0.2               # max relative brightness change (0 disables)
    AUG_CONTRAST = 0.2                 # max relative contrast change (0 disables)
    AUG_SATURATION = 0.2               # max relative saturation change (0 disables)
    AUG_GRAYSCALE_PROB = 0.0           # probability of turning the clip grey (0 disables)
    AUG_BLUR_PROB = 0.0                # probability of a Gaussian blur of the clip (0 disables)
    MIX_MODE = "none"                  # "none" | "mixup" | "cutmix" | "both" (one of the two per batch); targets are mixed accordingly; ignored for TARGET_MODE = coral
    MIX_ALPHA = 0.4                    # Beta(alpha, alpha) parameter of mixup / CutMix
    MIX_PROB = 0.5                     # probability that a batch is mixed
    SAMPLER = "random"                 # "random": plain shuffling | "class_balanced": GRS classes drawn equally often | "sqrt_balanced": 1 / sqrt(GRS class frequency) weights

    # ---------------------------------------------------------------- split and validation
    VAL_STRATEGY = "grouped_stratified"  # "grouped_stratified": hold-out split, videos of one student stay together, GRS classes balanced | "kfold": fold FOLD_INDEX of N_FOLDS (grouped) | "none": train on everything, validate on the training videos (optimistic)
    VAL_FRACTION = 0.2                 # share of videos in the hold-out validation split (VAL_STRATEGY = grouped_stratified)
    N_FOLDS = 5                        # number of folds for VAL_STRATEGY = kfold
    FOLD_INDEX = 0                     # fold used for validation (0 .. N_FOLDS-1)
    GROUP_COLUMN = "STUDENT"           # annotation column defining groups that must not be split (pre/post videos of one person); None -> no grouping
    CLASS_BOUNDARIES = (16, 24, 32)    # GRS thresholds of the four skill classes, only used to stratify the split

    # ---------------------------------------------------------------- targets
    TARGET_MODE = "coral"              # "regression": one continuous value per category | "classification": 5-way softmax per category | "coral": ordinal head with 4 cumulative logits per category | "hybrid": classification head + auxiliary regression head
    LABEL_MODE = "hard"                # classification / hybrid targets: "hard": rounded mean of the raters | "smoothed": hard target with LABEL_SMOOTHING | "soft_raters": distribution of the three raters' scores (coral always uses the rounded mean)
    LABEL_SMOOTHING = 0.05             # smoothing mass spread over the other scores (LABEL_MODE = smoothed)
    CLASS_LOSS = "ce"                  # classification / hybrid loss per category: "ce" | "focal" | "sord" (soft ordinal labels) | "emd" (squared earth mover's distance)
    FOCAL_GAMMA = 2.0                  # focusing parameter of LOSS = focal
    SORD_ALPHA = 1.0                   # sharpness of the soft ordinal labels of LOSS = sord (larger = closer to one-hot)
    REGRESSION_LOSS = "huber"          # regression / hybrid: "huber" | "mse" | "l1"
    HUBER_DELTA = 0.5                  # transition point of the Huber loss (in score units)
    CLASS_BALANCE = True               # classification / hybrid: True: inverse-frequency weights per category and score | False: unweighted
    EC_LOSS_WEIGHT = 0.3               # classification / hybrid: weight of the expected-cost penalty (0 disables)
    HYBRID_REGRESSION_WEIGHT = 0.5     # hybrid: weight of the auxiliary regression loss
    AUX_GRS_WEIGHT = 0.1               # weight of the GRS-consistency loss (predicted scores should add up to the mean GRS); 0 disables
    AUX_SUTURES_WEIGHT = 0.1           # weight of the auxiliary suture-count regression; 0 disables (needs a SUTURES column)

    # ---------------------------------------------------------------- model
    BACKBONE = "r2plus1d_18"           # video: "r2plus1d_18" | "r3d_18" | "mc3_18" | "s3d" | "mvit_v1_b" | "mvit_v2_s" | "swin3d_t" | "swin3d_s" | "swin3d_b"; per frame: "resnet18" | "resnet34" | "resnet50" | "resnet101" | "resnext50_32x4d" | "wide_resnet50_2" | "densenet121" | "efficientnet_b0".."efficientnet_b3" | "efficientnet_v2_s" | "mobilenet_v3_large" | "regnet_y_800mf" | "regnet_y_1_6gf" | "regnet_y_3_2gf" | "convnext_tiny" | "convnext_small" | "convnext_base" | "vit_b_16" | "swin_t" | "swin_s" | "swin_v2_t" | "timm:<model name>"
    PRETRAINED = True                  # True: Kinetics-400 (video) / ImageNet (per frame) weights | False: random initialisation
    TEMPORAL_HEAD = "attention"        # per-frame backbones only: "mean" | "max" | "attention" (learned weighted average) | "lstm" | "gru" (bidirectional) | "transformer" (encoder with class token) | "tcn" (dilated temporal convolutions)
    TEMPORAL_HIDDEN = 256              # width of the temporal head (LSTM / GRU hidden size, transformer / TCN channels, attention scorer)
    TEMPORAL_LAYERS = 2                # layers of the LSTM / GRU / transformer / TCN temporal head
    TEMPORAL_HEADS_NUM = 4             # attention heads of the transformer temporal head (must divide TEMPORAL_HIDDEN)
    TEMPORAL_DROPOUT = 0.1             # dropout inside the temporal head
    FRAME_CHUNK = 0                    # per-frame backbones: frames processed per forward chunk to save memory (0 = all frames at once)
    HEAD_HIDDEN = 512                  # hidden units of the shared head; 0 -> linear heads directly on the backbone features
    HEAD_DROPOUT = 0.3                 # dropout probability inside the head
    FREEZE_BACKBONE_EPOCHS = 0         # number of initial epochs during which only the heads are trained (0 = fine-tune everything from the start)
    CHECKPOINT_INIT = None             # path of a checkpoint whose model weights initialise the network (e.g. a Task 1 run; non-matching layers are skipped); None -> backbone weights only

    # ---------------------------------------------------------------- optimisation
    OPTIMIZER = "adamw"                # "adamw" | "adam" | "nadam" | "radam" | "adamax" | "sgd" (Nesterov momentum) | "rmsprop" | "adagrad"
    LEARNING_RATE = 1e-5               # base learning rate of the backbone
    HEAD_LR_MULT = 10.0                # learning-rate multiplier of the freshly initialised heads
    WEIGHT_DECAY = 1e-2                # weight decay (L2 for adam/sgd, decoupled for adamw)
    MOMENTUM = 0.9                     # momentum for sgd / rmsprop
    BETAS = (0.9, 0.999)               # betas for the Adam family
    SCHEDULER = "cosine"               # "cosine" | "cosine_restarts" | "linear" | "polynomial" | "step" | "multistep" | "exponential" | "onecycle" | "plateau" (ReduceLROnPlateau on the validation loss) | "none"; all except plateau / none use WARMUP_EPOCHS
    WARMUP_EPOCHS = 1                  # linear warm-up epochs
    MIN_LR = 1e-7                      # lowest learning rate of the decaying schedules
    RESTART_EPOCHS = 5                 # cycle length of SCHEDULER = cosine_restarts
    STEP_SIZE_EPOCHS = 5               # epochs between decays of SCHEDULER = step
    LR_MILESTONES = (10, 15)           # epochs of the decays of SCHEDULER = multistep
    LR_GAMMA = 0.5                     # decay factor of step / multistep (per decay) and exponential (per epoch)
    POLY_POWER = 0.9                   # exponent of SCHEDULER = polynomial
    PLATEAU_PATIENCE = 3               # epochs without improvement before the plateau scheduler reduces the learning rate
    PLATEAU_FACTOR = 0.5               # multiplicative factor of the plateau scheduler
    NUM_EPOCHS = 20                    # training epochs
    BATCH_SIZE = 4                     # clips per optimisation step (split across GPU_IDS when DataParallel is used)
    GRAD_ACCUM_STEPS = 1               # gradient accumulation steps (effective batch = BATCH_SIZE * GRAD_ACCUM_STEPS)
    GRAD_CLIP_NORM = 1.0               # gradient norm clipping threshold; 0 disables
    EMA_DECAY = 0.999                  # exponential moving average of the weights, evaluated in addition to the raw weights; 0 disables
    EARLY_STOPPING_PATIENCE = 8        # stop when the validation score has not improved for this many epochs; 0 disables
    SELECTION_METRIC = "rank_score"    # metric used to pick the best epoch: "rank_score" (mean macro-F1 minus mean expected cost) | "macro_f1" | "expected_cost" | "mae" | "val_loss"

    # ---------------------------------------------------------------- evaluation and inference
    VAL_TTA_CLIPS = 1                  # clips per video during validation (1 = fast, deterministic single clip)
    TTA_NUM_CLIPS = 3                  # clips per video for submissions / predict mode (temporal test-time augmentation)
    TTA_HFLIP = True                   # True: also average the horizontally flipped clips
    USE_EMA_FOR_INFERENCE = True       # True: submissions use the EMA weights when EMA_DECAY > 0 | False: raw weights
    F1_INCLUDE_ABSENT_CLASSES = False  # True: scores absent from both truth and prediction count as F1 = 0 | False: average only over scores that occur
    SUBMISSION_FILENAME = "task2_osats_predictions.csv"  # name of the prediction file written to the submission folders / predict output folder
    ENSEMBLE_CHECKPOINTS = []          # predict mode: list of checkpoint paths whose outputs are averaged; empty -> --checkpoint from the command line
    SAVE_OPTIMIZER_STATE = False       # True: optimizer / scheduler state inside every epoch checkpoint (large files) | False: weights only
    INFER_BATCH_SIZE = 4               # videos per batch during inference

    # ---------------------------------------------------------------- GRM search (grm_* modes, see grm.py)
    GRM_DIR = None                     # folder that keeps the GRM state between phases; None -> <OUTPUT_ROOT>/grm_task2
    GRM_SEARCH_SPACE = {               # every key is a CONFIG entry, every value the list of candidates; one key is the GRM state, the others form the actions
        "BATCH_SIZE": [2, 4, 8],                                    # batch-size classes (GRM state of the OSS challenge entry)
        "BACKBONE": ["r2plus1d_18", "r3d_18", "mc3_18", "resnet50"],   # clip encoders
        "TARGET_MODE": ["coral", "classification", "regression", "hybrid"],   # score parameterisations
        "CLASS_LOSS": ["ce", "sord", "focal"],                      # per-category classification losses
        "LEARNING_RATE": [1e-5, 3e-5, 1e-4],                        # backbone learning rates
        "OPTIMIZER": ["adamw", "sgd", "radam"],                     # optimisers
        "SCHEDULER": ["cosine", "plateau", "onecycle"],             # learning-rate schedules
        "AUX_GRS_WEIGHT": [0.0, 0.1, 0.3],                          # weight of the GRS-consistency loss
    }
    GRM_STATE_KEY = "BATCH_SIZE"       # search-space key used as GRM state by the mapping function: "BATCH_SIZE" (OSS / genomic entries) | "BACKBONE" (footstep entry) | any other key of GRM_SEARCH_SPACE
    GRM_STATE_BINS = None              # optional grouping of state values into classes, e.g. {"small": [2, 4], "large": [8]}; None -> one GRM state per value
    GRM_MAX_ACTIONS = 48               # largest number of actions per state; bigger products are replaced by a fixed random subset
    GRM_SIGNAL_PRESET = "oss"          # training-log signals: "oss" (early training dynamics vector) | "stepup" (mean loss + batch-loss spread) | "ogb" (mean score metric + mean error metric) | "custom" (GRM_SIGNALS)
    GRM_SIGNALS = ["mean:train_loss", "std_batch_loss", "best:selection_score"]  # signals for GRM_SIGNAL_PRESET = "custom": series:/mean:/last:/best:/worst:/slope:<column>, std_batch_loss, loss_drop, generalization_gap
    GRM_SCORE_METRIC = "val_macro_f1"  # score column of the "ogb" preset (P1, higher is better)
    GRM_ERROR_METRIC = "val_mae"       # error column of the "ogb" preset (P2, lower is better)
    GRM_PROBE_EPOCHS = 3               # epochs of a search probe; the signals always use the first GRM_PROBE_EPOCHS epochs
    GRM_CALIBRATION_PROBES = 4         # calibration probes per GRM state (random actions); 10-15 per state gives more reliable estimators
    GRM_CALIBRATION_EPOCHS = 8         # epochs of a calibration probe (its end performance is the estimator target); None -> NUM_EPOCHS (train to completion)
    GRM_CALIBRATION_STATES = None      # restrict a grm_calibrate call to some states, e.g. ["2", "4"] to share the work between machines; None -> all states
    GRM_MERGE_DIRS = []                # GRM folders (same search space) whose probes grm_merge imports
    GRM_PROBE_DATA_FRACTION = 1.0      # share of the training videos used by probes (stratified subset, faster probes); 1.0 -> all
    GRM_TARGET = "best"                # true performance learned by the estimators: "best" | "last" | "mean_last_k" of the selection score over the calibration run
    GRM_TARGET_LAST_K = 3              # epochs averaged by GRM_TARGET = mean_last_k
    GRM_ESTIMATOR = "ridge"            # "ridge" (standardised, L2, intercept) | "linear" (Perf = sum w_i * P_i, no intercept) | "linear_bias" | "huber" (robust ridge) | "knn"
    GRM_ESTIMATOR_SCOPE = "per_state"  # "per_state": one estimator per GRM state | "global": one shared estimator | "shrinkage": per-state ridge pulled towards the global one
    GRM_MIN_PROBES_PER_STATE = 3       # states with fewer usable calibration probes fall back to the global estimator
    GRM_RIDGE_LAMBDA = 1.0             # L2 strength of the ridge / huber / shrinkage estimators
    GRM_KNN_K = 3                      # neighbours of the knn estimator
    GRM_REWARD_SOURCE = "estimator"    # "estimator": GRM reward from the estimators | "raw": plain RL baseline rewarded directly with GRM_RAW_REWARD
    GRM_RAW_REWARD = "last:selection_score"  # signal used as reward by GRM_REWARD_SOURCE = "raw"; prefix "-" for losses, e.g. "-mean:train_loss"
    GRM_REWARD_MACHINE = True          # True: explore / exploit reward machine with labelling function | False: reward = estimate
    GRM_RM_PATIENCE = 3                # plateau steps in a row that send the reward machine from exploit back to explore
    GRM_IMPROVEMENT_MARGIN = 0.05      # an estimate counts as "improved" when it beats the best one by this share of the calibration-target spread
    GRM_NOVELTY_BONUS = 0.25           # explore-state bonus (share of the target spread), divided by sqrt(visits of the pair)
    GRM_DIVERGENCE_FACTOR = 3.0        # a probe whose train loss grows by this factor (or becomes non-finite) is labelled "diverged"
    GRM_PENALTY_MARGIN = 1.0           # reward of invalid / diverged probes: worst calibration target minus this many target standard deviations
    GRM_STATE_SELECTION = "random"     # next GRM state: "random" | "round_robin" | "least_visited" | "greedy" (best max-Q, epsilon exploration)
    GRM_ACTION_POLICY = "epsilon_greedy"  # action choice: "epsilon_greedy" | "ucb" | "softmax"
    GRM_EPSILON = 0.3                  # exploration rate when the reward machine is off
    GRM_EPSILON_EXPLORE = 0.5          # exploration rate in the explore state of the reward machine
    GRM_EPSILON_EXPLOIT = 0.1          # exploration rate in the exploit state of the reward machine
    GRM_UCB_C = 1.0                    # exploration constant of GRM_ACTION_POLICY = ucb
    GRM_SOFTMAX_TEMPERATURE = 0.05     # temperature of GRM_ACTION_POLICY = softmax
    GRM_Q_UPDATE = "q_learning"        # "q_learning": Q += a (r + g max Q(s', .) - Q) | "bandit": Q += a (r - Q)
    GRM_Q_LEARNING_RATE = 0.5          # step size alpha of the Q update (GRM_ALPHA_SCHEDULE = constant)
    GRM_ALPHA_SCHEDULE = "constant"    # "constant": GRM_Q_LEARNING_RATE | "visits": 1 / visits of the pair (running average)
    GRM_Q_DISCOUNT = 0.9               # discount gamma of the Q-learning update
    GRM_Q_INIT = 0.0                   # initial Q-values
    GRM_SEARCH_STEPS = 6               # search steps run by one grm_search call
    GRM_MAX_SEARCH_STEPS = 60          # total search steps over all calls
    GRM_MAX_HOURS = None               # time budget of one grm_search call in hours; None -> no limit
    GRM_FINAL_SELECTION = "q_value"    # "q_value": best visited Q | "estimated": best mean estimate | "verify_top_k": short real training of the top candidates
    GRM_FINAL_INCLUDE_CALIBRATION = True  # True: calibration probes (with their true performance) also compete for the final choice
    GRM_VERIFY_TOP_K = 3               # candidates trained by GRM_FINAL_SELECTION = verify_top_k
    GRM_VERIFY_EPOCHS = 8              # epochs of a verification run
    GRM_FINAL_EPOCHS = None            # epochs of the final training of the chosen configuration; None -> NUM_EPOCHS


cv2.setNumThreads(1)  # the DataLoader workers parallelise already; OpenCV threads would only compete

NUM_CATEGORIES = 8
NUM_SCORES = 5                                  # OSATS scores 1..5 -> class indices 0..4
NUM_CLASSES = 4                                 # GRS skill classes (used only to stratify the split)
CATEGORY_NAMES = ["OSATS_RESPECT", "OSATS_MOTION", "OSATS_INSTRUMENT", "OSATS_SUTURE",
                  "OSATS_FLOW", "OSATS_KNOWLEDGE", "OSATS_PERFORMANCE", "OSATS_FINAL_QUALITY"]
CATEGORY_KEYWORDS = [("RESPECT",), ("MOTION",), ("INSTRUMENT",), ("SUTURE",), ("FLOW",),
                     ("KNOWLEDGE",), ("PERFORMANCE",), ("FINAL", "QUALITY")]   # any key word identifies the column
KINETICS_MEAN = (0.43216, 0.394666, 0.37645)   # normalisation used by the Kinetics-400 pre-trained weights
KINETICS_STD = (0.22803, 0.22145, 0.216989)
VIDEO_EXTENSIONS = (".mp4", ".avi", ".mov", ".mkv")
GRM_MODES = ("grm_calibrate", "grm_merge", "grm_fit", "grm_search", "grm_final", "grm_full", "grm_report")
LOG = logging.getLogger("task2")


# ======================================================================================
#                                  general utilities
# ======================================================================================
def set_seed(seed, deterministic):
    """Seed every random number generator used by the pipeline and set the cudnn mode."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = bool(deterministic)
    torch.backends.cudnn.benchmark = not deterministic


def worker_init_fn(worker_id):
    """Give every DataLoader worker its own, reproducible random state."""
    seed = (torch.initial_seed() + worker_id) % (2 ** 32)
    np.random.seed(seed)
    random.seed(seed)


def setup_logging(run_dir):
    """Log to the console and, when a run folder is given, to <run_dir>/train.log."""
    LOG.handlers.clear()
    LOG.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", "%Y-%m-%d %H:%M:%S")
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    LOG.addHandler(console)
    if run_dir is not None:
        os.makedirs(run_dir, exist_ok=True)
        file_handler = logging.FileHandler(os.path.join(run_dir, "train.log"), encoding="utf-8")
        file_handler.setFormatter(formatter)
        LOG.addHandler(file_handler)


def config_to_dict(cfg):
    """Return all upper-case CONFIG entries as a plain, JSON-friendly dictionary."""
    entries = OrderedDict()
    for key in dir(cfg):
        if key.isupper():
            value = getattr(cfg, key)
            entries[key] = list(value) if isinstance(value, tuple) else value
    return entries


def clone_config(cfg):
    """
    Return an independent namespace copy of a configuration.

    CONFIG is a class; copy.deepcopy would return the same class object, so the
    copy is built attribute by attribute. Probe runs of the GRM search and the
    predict mode work on such copies without touching the global defaults.
    """
    return types.SimpleNamespace(**{key: copy.deepcopy(getattr(cfg, key)) for key in dir(cfg) if key.isupper()})


def apply_overrides(cfg, overrides):
    """Apply KEY=VALUE overrides (command line or GRM probes); string values are parsed as literals."""
    for key, raw_value in overrides.items():
        if not hasattr(cfg, key):
            raise KeyError(f"Unknown CONFIG entry '{key}'")
        value = raw_value
        if isinstance(raw_value, str):
            try:
                value = ast.literal_eval(raw_value)
            except (ValueError, SyntaxError):
                value = raw_value  # plain string such as a path or a mode name
        setattr(cfg, key, value)


def check_cuda_build(cfg):
    """Warn when the CUDA build torch was compiled with differs from CONFIG.CUDA_BUILD."""
    built = torch.version.cuda
    if built is None:
        LOG.warning("This torch build has no CUDA support; the run will use the CPU.")
        return
    tag = "cu" + built.replace(".", "")[:3]
    if cfg.CUDA_BUILD != "cpu" and not tag.startswith(cfg.CUDA_BUILD[:4]):
        LOG.warning("CONFIG.CUDA_BUILD = %s but torch was built for CUDA %s (%s). "
                    "Make sure the driver of this machine supports the installed build.", cfg.CUDA_BUILD, built, tag)


def export_visible_gpus(cfg):
    """Expose only the GPUs listed in CONFIG.GPU_IDS (must run before the first CUDA call)."""
    os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str(gpu_id) for gpu_id in cfg.GPU_IDS)


def get_device(cfg):
    """Return the torch device of the run (cuda:0 = first id of GPU_IDS, or the CPU)."""
    if torch.cuda.is_available() and len(cfg.GPU_IDS) > 0:
        device = torch.device("cuda:0")
        names = ", ".join(torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count()))
        LOG.info("Using %d GPU(s): physical ids %s -> %s", torch.cuda.device_count(), cfg.GPU_IDS, names)
    else:
        device = torch.device("cpu")
        LOG.info("Using the CPU (no GPU requested or available)")
    return device


def make_grad_scaler(enabled):
    """Create a GradScaler that works across torch versions (torch.amp.GradScaler appeared in 2.3)."""
    if hasattr(torch, "amp") and hasattr(torch.amp, "GradScaler"):
        return torch.amp.GradScaler("cuda", enabled=enabled)
    return torch.cuda.amp.GradScaler(enabled=enabled)


def autocast_context(device, enabled):
    """
    Return the autocast context for mixed precision (a no-op context on the CPU or when disabled).
    torch.autocast appeared in torch 1.10; older builds only offer torch.cuda.amp.autocast without dtype.
    """
    if device.type != "cuda" or not enabled:
        return contextlib.nullcontext()
    if hasattr(torch, "autocast"):
        return torch.autocast(device_type="cuda", dtype=torch.float16)
    return torch.cuda.amp.autocast(enabled=True)


def load_checkpoint(path):
    """
    Load a checkpoint written by this repository onto the CPU.

    The files hold the configuration next to the weights, so they are read as full pickles
    (weights_only=False on torch >= 1.13, where the argument exists). Only load trusted files.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:                     # torch < 1.13 has no weights_only argument
        return torch.load(path, map_location="cpu")


def unwrap(model):
    """Return the underlying module of a DataParallel wrapper (or the model itself)."""
    return model.module if isinstance(model, nn.DataParallel) else model


def write_json(path, payload):
    """Write a JSON file with indentation (UTF-8)."""
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


# ======================================================================================
#                                   annotations
# ======================================================================================
def normalise_column(name):
    """Normalise a column name for matching: upper case, no surrounding blanks, underscores."""
    return str(name).strip().upper().replace(" ", "_").replace("-", "_")


def find_column(columns, *patterns, required=True):
    """Return the first column whose normalised name contains all given patterns (None if optional and absent)."""
    patterns = [normalise_column(pattern) for pattern in patterns]
    for column in columns:
        normalised = normalise_column(column)
        if all(pattern in normalised for pattern in patterns):
            return column
    if required:
        raise KeyError(f"No annotation column matching {patterns}; available columns: {list(columns)}")
    return None


def grs_to_class(grs, boundaries):
    """Map a GRS value to the ordinal class index using the configured thresholds."""
    return int(sum(grs >= boundary for boundary in boundaries))


def find_osats_columns(columns):
    """Locate the eight OSATS columns by key word and return them in the canonical category order."""
    osats_columns = [column for column in columns if normalise_column(column).startswith("OSATS")]
    ordered = []
    for keywords in CATEGORY_KEYWORDS:
        matches = [column for column in osats_columns
                   if any(keyword in normalise_column(column) for keyword in keywords)]
        if len(matches) != 1:
            raise KeyError(f"Expected exactly one OSATS column for {keywords}, found {matches}; "
                           f"OSATS columns: {osats_columns}")
        ordered.append(matches[0])
    return ordered


def find_sutures_column(columns):
    """Return the suture-count column (contains SUTURE but is not an OSATS item), or None."""
    for column in columns:
        normalised = normalise_column(column)
        if "SUTURE" in normalised and not normalised.startswith("OSATS"):
            return column
    return None


def round_score(value):
    """Round a mean rater score to the nearest integer score (halves round up), clipped to 1..5."""
    return int(min(NUM_SCORES, max(1, math.floor(value + 0.5))))


def rater_distribution(scores):
    """(8, 5) distribution of the individual raters' scores from a (raters, 8) array."""
    distribution = np.zeros((NUM_CATEGORIES, NUM_SCORES), dtype=np.float32)
    for rater_scores in scores:
        for category, score in enumerate(rater_scores):
            distribution[category, round_score(float(score)) - 1] += 1.0
    return distribution / distribution.sum(axis=1, keepdims=True)


def load_annotations(cfg):
    """
    Read the annotation workbook and aggregate the rows of the three raters per video.

    Each record holds the mean OSATS scores (regression target), the rounded scores as
    class indices 0..4 (classification / CORAL target and evaluation ground truth), the
    distribution of the raters' scores (soft target), the mean GRS, the suture count and
    the grouping key. Any problem with the workbook stops the program.
    """
    if not os.path.isfile(cfg.ANNOTATION_FILE):
        raise FileNotFoundError(f"Annotation file not found: {cfg.ANNOTATION_FILE}")
    sheet = cfg.ANNOTATION_SHEET if cfg.ANNOTATION_SHEET is not None else 0
    table = pd.read_excel(cfg.ANNOTATION_FILE, sheet_name=sheet)
    table.columns = [str(column).strip() for column in table.columns]
    LOG.info("Annotation sheet loaded: %d rows, columns = %s", len(table), list(table.columns))

    video_col = find_column(table.columns, "VIDEO")
    osats_cols = find_osats_columns(table.columns)
    grs_col = find_column(table.columns, "RATING", required=False)   # GLOBAL_RATING_SCORE or GLOBA_RATING_SCORE
    sutures_col = find_sutures_column(table.columns)
    group_col = find_column(table.columns, cfg.GROUP_COLUMN, required=False) if cfg.GROUP_COLUMN else None
    LOG.info("OSATS columns in canonical order: %s | GRS column: %s | sutures column: %s",
             osats_cols, grs_col, sutures_col)

    table[video_col] = table[video_col].astype(str).str.strip()
    for column in osats_cols:
        table[column] = pd.to_numeric(table[column], errors="coerce")
    invalid = table[table[osats_cols].isna().any(axis=1)]
    if len(invalid) > 0:
        raise ValueError(f"{len(invalid)} annotation rows have missing or non-numeric OSATS scores, "
                         f"e.g. video {invalid[video_col].iloc[0]}")
    if ((table[osats_cols] < 1) | (table[osats_cols] > NUM_SCORES)).any().any():
        raise ValueError("OSATS scores outside the range 1..5 were found in the annotation sheet")
    if grs_col is not None:
        table[grs_col] = pd.to_numeric(table[grs_col], errors="coerce")
    if sutures_col is not None:
        table[sutures_col] = pd.to_numeric(table[sutures_col], errors="coerce")
    elif cfg.AUX_SUTURES_WEIGHT > 0:
        LOG.warning("No SUTURES column found: the auxiliary suture-count loss is disabled for this run")
        cfg.AUX_SUTURES_WEIGHT = 0.0

    records = []
    for video_id, rows in table.groupby(video_col, sort=True):
        scores = rows[osats_cols].to_numpy(dtype=np.float32)                 # (raters, 8)
        mean_scores = scores.mean(axis=0)
        if grs_col is not None and not rows[grs_col].isna().any():
            grs_mean = float(rows[grs_col].mean())
        else:
            grs_mean = float(scores.sum(axis=1).mean())
        has_sutures = sutures_col is not None and not rows[sutures_col].isna().any()
        records.append({
            "video_id": video_id,
            "path": os.path.join(cfg.VIDEO_DIR, f"{video_id}.mp4"),
            "osats_mean": mean_scores,                                                    # (8,) floats in [1, 5]
            "osats_hard": np.array([round_score(float(value)) - 1 for value in mean_scores], dtype=np.int64),
            "osats_soft": rater_distribution(scores),                                     # (8, 5)
            "osats_raters": scores,
            "grs_mean": grs_mean,
            "sutures": float(rows[sutures_col].mean()) if has_sutures else 0.0,
            "label": grs_to_class(grs_mean, cfg.CLASS_BOUNDARIES),                       # GRS class, split only
            "group": str(rows[group_col].iloc[0]) if group_col else video_id,
            "num_raters": len(rows),
        })

    missing = [record["video_id"] for record in records if not os.path.isfile(record["path"])]
    if missing:
        message = f"{len(missing)} annotated videos are missing in {cfg.VIDEO_DIR} (e.g. {missing[:5]})"
        if cfg.MISSING_VIDEO_POLICY == "error":
            raise FileNotFoundError(message + ". Set MISSING_VIDEO_POLICY = 'skip' to drop them.")
        LOG.warning("%s; they are skipped", message)
        records = [record for record in records if os.path.isfile(record["path"])]
    if not records:
        raise RuntimeError("No video with annotations was found; check VIDEO_DIR and ANNOTATION_FILE")

    means = np.stack([record["osats_mean"] for record in records])
    LOG.info("%d videos with labels; mean score per category: %s", len(records),
             {name: round(float(value), 2) for name, value in zip(CATEGORY_NAMES, means.mean(axis=0))})
    return records


def split_records(records, cfg, seed):
    """
    Split the videos into training and validation sets.

    grouped_stratified: groups (students) are assigned greedily to the validation side while
    it still needs videos of their classes, which keeps pre/post videos of one person on the
    same side and balances the four classes.
    kfold: groups are distributed round-robin over N_FOLDS folds after a stratified shuffle.
    none: the training videos double as validation set (optimistic numbers).
    """
    if cfg.VAL_STRATEGY == "none":
        LOG.warning("VAL_STRATEGY = none: validation is performed on the training videos (optimistic numbers)")
        return list(records), list(records)

    rng = random.Random(seed)
    groups = OrderedDict()
    for record in records:
        groups.setdefault(record["group"], []).append(record)
    group_items = list(groups.items())
    rng.shuffle(group_items)
    # sort groups by their dominant class so that the greedy assignment sees the classes in turn
    group_items.sort(key=lambda item: Counter(record["label"] for record in item[1]).most_common(1)[0][0])

    if cfg.VAL_STRATEGY == "kfold":
        folds = [[] for _ in range(cfg.N_FOLDS)]
        for index, (_, members) in enumerate(group_items):
            folds[index % cfg.N_FOLDS].extend(members)
        val_fold = cfg.FOLD_INDEX % cfg.N_FOLDS
        val_records = folds[val_fold]
        train_records = [record for fold_idx, fold in enumerate(folds) if fold_idx != val_fold for record in fold]
    elif cfg.VAL_STRATEGY == "grouped_stratified":
        totals = Counter(record["label"] for record in records)
        target_val = {class_id: count * cfg.VAL_FRACTION for class_id, count in totals.items()}
        val_counts = Counter()
        train_records, val_records = [], []
        for _, members in group_items:
            member_counts = Counter(record["label"] for record in members)
            demand = sum(min(member_counts[class_id], max(0.0, target_val[class_id] - val_counts[class_id]))
                         for class_id in member_counts)
            if demand >= 0.5 * len(members):   # the group fills at least half of its size in validation demand
                val_records.extend(members)
                val_counts.update(member_counts)
            else:
                train_records.extend(members)
    else:
        raise ValueError(f"Unknown VAL_STRATEGY '{cfg.VAL_STRATEGY}'")

    if not train_records or not val_records:
        raise RuntimeError("The split produced an empty training or validation set; adjust VAL_FRACTION / N_FOLDS")
    LOG.info("Split: %d training videos %s | %d validation videos %s",
             len(train_records), dict(Counter(record["label"] for record in train_records)),
             len(val_records), dict(Counter(record["label"] for record in val_records)))
    return train_records, val_records


# ======================================================================================
#                              video decoding and frame cache
# ======================================================================================
def resize_frame(frame, size, mode):
    """Bring one RGB frame to a square of `size` pixels with the configured strategy."""
    height, width = frame.shape[:2]
    if mode == "squash":
        return cv2.resize(frame, (size, size), interpolation=cv2.INTER_AREA)
    if mode == "center_crop":
        scale = size / min(height, width)
        new_size = (max(size, round(width * scale)), max(size, round(height * scale)))
        resized = cv2.resize(frame, new_size, interpolation=cv2.INTER_AREA)
        top, left = (resized.shape[0] - size) // 2, (resized.shape[1] - size) // 2
        return resized[top:top + size, left:left + size]
    if mode == "pad":
        scale = size / max(height, width)
        new_size = (max(1, round(width * scale)), max(1, round(height * scale)))
        resized = cv2.resize(frame, new_size, interpolation=cv2.INTER_AREA)
        canvas = np.zeros((size, size, 3), dtype=np.uint8)
        top, left = (size - resized.shape[0]) // 2, (size - resized.shape[1]) // 2
        canvas[top:top + resized.shape[0], left:left + resized.shape[1]] = resized
        return canvas
    raise ValueError(f"Unknown FRAME_RESIZE_MODE '{mode}'")


def pool_indices(total_frames, pool_size):
    """Indices of `pool_size` frames spread evenly over a video of `total_frames` frames."""
    return np.linspace(0, total_frames - 1, pool_size).round().astype(int)


def decode_with_opencv(path, cfg):
    """Decode the frame pool of one video with cv2.VideoCapture (seek per frame)."""
    capture = cv2.VideoCapture(path)
    try:
        if not capture.isOpened():
            raise RuntimeError(f"{path}: cannot be opened by OpenCV")
        total = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        if total < cfg.MIN_VIDEO_FRAMES:
            raise RuntimeError(f"{path}: frame count {total} is below MIN_VIDEO_FRAMES")
        pool = []
        for index in pool_indices(total, cfg.FRAME_POOL_SIZE):
            frame = None
            # the frame count reported by the container is occasionally too large; step back a few frames
            for back in range(8):
                capture.set(cv2.CAP_PROP_POS_FRAMES, max(0, int(index) - back))
                success, bgr = capture.read()
                if success and bgr is not None and bgr.size > 0:
                    frame = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
                    break
            if frame is None:
                raise RuntimeError(f"{path}: frame {index} of {total} could not be decoded")
            pool.append(resize_frame(frame, cfg.CACHE_IMG_SIZE, cfg.FRAME_RESIZE_MODE))
        return np.stack(pool)
    finally:
        capture.release()


def decode_frame_pool(path, cfg):
    """
    Decode FRAME_POOL_SIZE evenly spaced frames of one video and return them as a
    uint8 array of shape (P, S, S, 3) in RGB order. Raises on any decoding problem.
    """
    if cfg.DECODER == "opencv":
        return decode_with_opencv(path, cfg)
    if cfg.DECODER == "decord":
        try:
            import decord  # optional dependency, imported only when selected
        except ImportError as exc:
            raise ImportError("DECODER = 'decord' requires `pip install decord`") from exc
        reader = decord.VideoReader(path, num_threads=1)
        if len(reader) < cfg.MIN_VIDEO_FRAMES:
            raise RuntimeError(f"{path}: only {len(reader)} frames")
        frames = reader.get_batch(pool_indices(len(reader), cfg.FRAME_POOL_SIZE).tolist()).asnumpy()
        return np.stack([resize_frame(frame, cfg.CACHE_IMG_SIZE, cfg.FRAME_RESIZE_MODE) for frame in frames])
    if cfg.DECODER == "torchvision":
        from torchvision.io import read_video
        video, _, _ = read_video(path, pts_unit="sec", output_format="THWC")
        if video.shape[0] < cfg.MIN_VIDEO_FRAMES:
            raise RuntimeError(f"{path}: only {video.shape[0]} frames")
        return np.stack([resize_frame(video[index].numpy(), cfg.CACHE_IMG_SIZE, cfg.FRAME_RESIZE_MODE)
                         for index in pool_indices(video.shape[0], cfg.FRAME_POOL_SIZE)])
    raise ValueError(f"Unknown DECODER '{cfg.DECODER}'")


def cache_file_name(path, cfg):
    """File name of the cached pool; it changes whenever the decoding parameters or the video change."""
    stat = os.stat(path)
    tag = f"{os.path.basename(path)}|{stat.st_size}|{cfg.FRAME_POOL_SIZE}|{cfg.CACHE_IMG_SIZE}|{cfg.FRAME_RESIZE_MODE}"
    digest = hashlib.md5(tag.encode()).hexdigest()[:10]
    return f"{os.path.splitext(os.path.basename(path))[0]}_{digest}.npy"


def load_frame_pool(path, cfg):
    """Return the frame pool of a video, building and storing the cache entry when needed."""
    if cfg.FRAME_CACHE_DIR is None:
        return decode_frame_pool(path, cfg)
    os.makedirs(cfg.FRAME_CACHE_DIR, exist_ok=True)
    cache_path = os.path.join(cfg.FRAME_CACHE_DIR, cache_file_name(path, cfg))
    expected_shape = (cfg.FRAME_POOL_SIZE, cfg.CACHE_IMG_SIZE, cfg.CACHE_IMG_SIZE, 3)
    if os.path.isfile(cache_path):
        pool = np.load(cache_path, mmap_mode="r")
        if pool.shape == expected_shape:
            return np.ascontiguousarray(pool)
        LOG.warning("Cache entry %s has an unexpected shape and is rebuilt", cache_path)
    pool = decode_frame_pool(path, cfg)
    temporary = cache_path + ".tmp.npy"
    np.save(temporary, pool)
    os.replace(temporary, cache_path)
    return pool


def verify_and_cache(records, cfg, description):
    """
    Decode every video once (and fill the cache). Any failure stops the program: a
    training run on a silently shrunken dataset is worse than a clear error message.
    """
    LOG.info("Checking %d videos (%s) ...", len(records), description)
    failures = []
    for record in tqdm(records, desc=f"data check: {description}", unit="video"):
        try:
            pool = load_frame_pool(record["path"], cfg)
            if pool.shape[0] != cfg.FRAME_POOL_SIZE:
                failures.append((record["path"], f"pool size {pool.shape[0]}"))
        except Exception as exc:  # every failure is reported, then the run stops
            failures.append((record["path"], str(exc)))
    if failures:
        for path, reason in failures[:20]:
            LOG.error("  %s -> %s", path, reason)
        raise RuntimeError(f"{len(failures)} of {len(records)} videos could not be decoded; the run is stopped")
    LOG.info("All %d videos decoded successfully", len(records))


# ======================================================================================
#                                clip sampling and dataset
# ======================================================================================
def sample_indices(pool_size, num_frames, strategy, power, train, rng, jitter, clip_idx=0, num_clips=1):
    """
    Select `num_frames` indices from a pool of `pool_size` frames.

    train=True adds randomness (TSN-style segments / temporal jitter); at inference the
    clip position inside each segment is spread evenly over the `num_clips` TTA clips.
    """
    segment = pool_size / num_frames
    if train and strategy == "segment_random":
        positions = np.array([rng.uniform(i * segment, (i + 1) * segment) for i in range(num_frames)])
    else:
        offset = (clip_idx + 0.5) / num_clips if num_clips > 1 else 0.5
        fractions = (np.arange(num_frames) + offset) / num_frames    # evenly spaced in [0, 1)
        if strategy == "end_weighted":
            fractions = fractions ** (1.0 / power)                       # pushes samples towards the end
        elif strategy == "start_weighted":
            fractions = fractions ** power                               # pushes samples towards the start
        elif strategy not in ("uniform", "segment_random"):
            raise ValueError(f"Unknown FRAME_SAMPLING '{strategy}'")
        positions = fractions * (pool_size - 1)
        if train and jitter:
            positions = positions + rng.uniform(-0.5 * segment, 0.5 * segment, size=num_frames)
    return np.clip(positions.round().astype(int), 0, pool_size - 1)


class ClipDataset(Dataset):
    """
    Builds training / evaluation clips from the cached frame pools.

    Returns (clip, targets, record_index) where the clip has shape (3, T, S, S) and is normalised
    with the statistics of the selected pre-trained weights. `targets` is a dictionary of
    tensors (mean scores, rounded scores, rater distributions, GRS, suture count).
    """

    def __init__(self, records, cfg, train, num_clips=1):
        """Store the records and configuration; `num_clips` > 1 yields several TTA clips per video."""
        self.records = records
        self.cfg = cfg
        self.train = train
        self.num_clips = num_clips
        mean, std = video_backbones.normalization_stats(cfg)
        self.mean = torch.tensor(mean, dtype=torch.float32).view(3, 1, 1, 1)
        self.std = torch.tensor(std, dtype=torch.float32).view(3, 1, 1, 1)

    def __len__(self):
        """Number of clips (videos times TTA clips)."""
        return len(self.records) * self.num_clips

    def _augment(self, clip, rng):
        """Clip-level geometric augmentation on a uint8 array (T, S, S, 3); identical for all frames."""
        cfg = self.cfg
        size = clip.shape[1]                                   # frames are square at this point
        low, high = cfg.AUG_CROP_SCALE
        if high < 1.0 or low < 1.0:
            area = rng.uniform(low, high) * size * size
            ratio = math.exp(rng.uniform(math.log(3 / 4), math.log(4 / 3)))
            crop_w = min(max(int(round(math.sqrt(area * ratio))), 8), size)
            crop_h = min(max(int(round(math.sqrt(area / ratio))), 8), size)
            x0, y0 = rng.integers(0, size - crop_w + 1), rng.integers(0, size - crop_h + 1)
            clip = clip[:, y0:y0 + crop_h, x0:x0 + crop_w]
        if rng.random() < cfg.AUG_HFLIP_PROB:
            clip = clip[:, :, ::-1]
        clip = np.ascontiguousarray(clip)
        if cfg.AUG_ROTATION_DEG > 0:
            height, width = clip.shape[1:3]
            matrix = cv2.getRotationMatrix2D((width / 2, height / 2),
                                             rng.uniform(-cfg.AUG_ROTATION_DEG, cfg.AUG_ROTATION_DEG), 1.0)
            clip = np.stack([cv2.warpAffine(frame, matrix, (width, height), borderMode=cv2.BORDER_REFLECT)
                             for frame in clip])
        if cfg.AUG_BLUR_PROB > 0 and rng.random() < cfg.AUG_BLUR_PROB:
            kernel = int(rng.choice([3, 5]))
            clip = np.stack([cv2.GaussianBlur(frame, (kernel, kernel), 0) for frame in clip])
        return clip

    def _to_tensor(self, clip, rng):
        """uint8 (T, H, W, 3) -> float tensor (3, T, S, S) with colour jitter and normalisation."""
        cfg = self.cfg
        frames = torch.from_numpy(clip).permute(3, 0, 1, 2).float() / 255.0      # (3, T, H, W)
        if frames.shape[-1] != cfg.IMG_SIZE or frames.shape[-2] != cfg.IMG_SIZE:
            frames = F.interpolate(frames.permute(1, 0, 2, 3), size=(cfg.IMG_SIZE, cfg.IMG_SIZE),
                                   mode="bilinear", align_corners=False).permute(1, 0, 2, 3)
        if self.train:
            if cfg.AUG_BRIGHTNESS > 0:
                frames = frames * (1.0 + rng.uniform(-cfg.AUG_BRIGHTNESS, cfg.AUG_BRIGHTNESS))
            if cfg.AUG_CONTRAST > 0:
                mean = frames.mean()
                frames = (frames - mean) * (1.0 + rng.uniform(-cfg.AUG_CONTRAST, cfg.AUG_CONTRAST)) + mean
            if cfg.AUG_SATURATION > 0:
                grey = frames.mean(dim=0, keepdim=True)
                frames = (frames - grey) * (1.0 + rng.uniform(-cfg.AUG_SATURATION, cfg.AUG_SATURATION)) + grey
            if cfg.AUG_GRAYSCALE_PROB > 0 and rng.random() < cfg.AUG_GRAYSCALE_PROB:
                frames = frames.mean(dim=0, keepdim=True).expand_as(frames).clone()
            frames = frames.clamp(0.0, 1.0)
        return (frames - self.mean) / self.std

    def __getitem__(self, item):
        """Build one clip: sample frame indices from the pool, augment (training only) and normalise."""
        record_idx, clip_idx = divmod(item, self.num_clips)
        record = self.records[record_idx]
        cfg = self.cfg
        rng = np.random.default_rng(None if self.train else (cfg.SEED * 1000 + item))
        pool = load_frame_pool(record["path"], cfg)
        indices = sample_indices(pool.shape[0], cfg.NUM_FRAMES, cfg.FRAME_SAMPLING, cfg.SAMPLING_POWER,
                                 self.train, rng, cfg.TEMPORAL_JITTER, clip_idx, self.num_clips)
        clip = pool[indices]
        if self.train:
            clip = self._augment(clip, rng)
        tensor = self._to_tensor(clip, rng)
        targets = {
            "scores_mean": torch.tensor(record["osats_mean"], dtype=torch.float32),      # (8,) in [1, 5]
            "scores_hard": torch.tensor(record["osats_hard"], dtype=torch.long),         # (8,) class index 0..4
            "scores_soft": torch.tensor(record["osats_soft"], dtype=torch.float32),      # (8, 5) rater distribution
            "grs": torch.tensor([record["grs_mean"]], dtype=torch.float32),             # (1,)
            "sutures": torch.tensor([record["sutures"]], dtype=torch.float32),          # (1,)
        }
        return tensor, targets, record_idx


def make_loader(records, cfg, train, num_clips=1, batch_size=None):
    """
    Create the DataLoader of a record list: shuffled (or class-balanced, SAMPLER) with persistent
    workers for training, in order for evaluation.
    """
    dataset = ClipDataset(records, cfg, train=train, num_clips=num_clips)
    sampler = None
    if train:
        weights = blocks.sampling_weights([record["label"] for record in records], cfg.SAMPLER)
        if weights is not None:
            sampler = WeightedRandomSampler(weights, num_samples=len(dataset), replacement=True)
    kwargs = {"batch_size": batch_size or cfg.BATCH_SIZE, "shuffle": train and sampler is None, "sampler": sampler,
              "num_workers": cfg.NUM_WORKERS, "pin_memory": cfg.PIN_MEMORY and torch.cuda.is_available(),
              "drop_last": False, "worker_init_fn": worker_init_fn}
    if cfg.NUM_WORKERS > 0:
        kwargs["prefetch_factor"] = cfg.PREFETCH_FACTOR
        kwargs["persistent_workers"] = bool(train)   # evaluation loaders are short-lived
    return DataLoader(dataset, **kwargs)


# ======================================================================================
#                                        model
# ======================================================================================
def build_backbone(cfg):
    """Clip encoder selected by CONFIG.BACKBONE (see video_backbones.py); returns (encoder, feature_dim)."""
    encoder, feature_dim = video_backbones.build_clip_encoder(cfg)
    LOG.info("Clip encoder: %s, %.1f M trainable parameters", video_backbones.describe_encoder(cfg, feature_dim),
             video_backbones.count_parameters(encoder))
    return encoder, feature_dim


def pretrained_parameters(core):
    """
    Parameters that start from pre-trained weights (lower learning rate, optional freezing): the whole
    video network, or only the frame network of a per-frame backbone (its temporal head is new).
    """
    backbone = core.backbone
    if isinstance(backbone, video_backbones.FrameTemporalEncoder):
        return list(backbone.frame_network.parameters())
    return list(backbone.parameters())


def make_mlp_head(in_dim, hidden, dropout, out_dim):
    """Dropout -> (Linear -> GELU -> Dropout ->) Linear."""
    layers = [nn.Dropout(dropout)]
    if hidden > 0:
        layers += [nn.Linear(in_dim, hidden), nn.GELU(), nn.Dropout(dropout), nn.Linear(hidden, out_dim)]
    else:
        layers += [nn.Linear(in_dim, out_dim)]
    return nn.Sequential(*layers)


class OSATSModel(nn.Module):
    """
    Video backbone + OSATS heads.

    forward() returns a dictionary whose keys depend on TARGET_MODE:
        "cls"     (B, 8, 5)  score logits           classification, hybrid
        "reg"     (B, 8)     continuous scores      regression, hybrid
        "coral"   (B, 8, 4)  cumulative logits      coral      (P(score > 1), ..., P(score > 4))
        "sutures" (B, 1)     standardised count     when AUX_SUTURES_WEIGHT > 0
    """

    def __init__(self, cfg):
        """Build the backbone, the shared trunk and the heads selected by TARGET_MODE."""
        super().__init__()
        self.backbone, feature_dim = build_backbone(cfg)
        self.mode = cfg.TARGET_MODE
        if self.mode not in ("regression", "classification", "coral", "hybrid"):
            raise ValueError(f"Unknown TARGET_MODE '{self.mode}'")
        if cfg.HEAD_HIDDEN > 0:
            self.trunk = nn.Sequential(nn.Dropout(cfg.HEAD_DROPOUT), nn.Linear(feature_dim, cfg.HEAD_HIDDEN),
                                       nn.GELU(), nn.Dropout(cfg.HEAD_DROPOUT))
            trunk_dim = cfg.HEAD_HIDDEN
        else:
            self.trunk = nn.Dropout(cfg.HEAD_DROPOUT)
            trunk_dim = feature_dim
        if self.mode in ("classification", "hybrid"):
            self.cls_head = nn.Linear(trunk_dim, NUM_CATEGORIES * NUM_SCORES)
        if self.mode in ("regression", "hybrid"):
            self.reg_head = nn.Linear(trunk_dim, NUM_CATEGORIES)
        if self.mode == "coral":
            # CORAL: one shared logit per category plus four ordered, score-specific biases
            self.coral_head = nn.Linear(trunk_dim, NUM_CATEGORIES)
            self.coral_bias = nn.Parameter(torch.linspace(1.5, -1.5, NUM_SCORES - 1).repeat(NUM_CATEGORIES, 1))
        self.use_sutures = cfg.AUX_SUTURES_WEIGHT > 0
        if self.use_sutures:
            self.sutures_head = nn.Linear(trunk_dim, 1)

    def forward(self, clips):
        """(B, 3, T, S, S) clips -> dictionary of head outputs (see the class docstring)."""
        features = self.trunk(self.backbone(clips))
        outputs = {}
        if self.mode in ("classification", "hybrid"):
            outputs["cls"] = self.cls_head(features).view(-1, NUM_CATEGORIES, NUM_SCORES)
        if self.mode in ("regression", "hybrid"):
            outputs["reg"] = 3.0 + 2.0 * torch.tanh(self.reg_head(features))   # keeps the raw output inside 1..5
        if self.mode == "coral":
            outputs["coral"] = self.coral_head(features).unsqueeze(-1) + self.coral_bias.unsqueeze(0)
        if self.use_sutures:
            outputs["sutures"] = self.sutures_head(features)
        return outputs

    @staticmethod
    def score_probabilities(outputs):
        """(B, 8, 5) probability of every score; for pure regression a soft distribution around the value."""
        if "cls" in outputs:
            return torch.softmax(outputs["cls"].float(), dim=-1)
        if "coral" in outputs:
            cumulative = torch.sigmoid(outputs["coral"].float())              # P(score > k), k = 1..4
            upper = torch.cat([torch.ones_like(cumulative[..., :1]), cumulative], dim=-1)
            lower = torch.cat([cumulative, torch.zeros_like(cumulative[..., :1])], dim=-1)
            return (upper - lower).clamp_min(1e-6)
        values = outputs["reg"].float().unsqueeze(-1)                         # (B, 8, 1)
        grid = torch.arange(1, NUM_SCORES + 1, device=values.device, dtype=values.dtype).view(1, 1, -1)
        return torch.softmax(-((values - grid) ** 2) / 0.5, dim=-1)          # peaked at the predicted value

    def expected_scores(self, outputs):
        """(B, 8) differentiable expected score in [1, 5] (used by the GRS-consistency loss)."""
        if "reg" in outputs and "cls" not in outputs:
            return outputs["reg"].float()
        probs = self.score_probabilities(outputs)
        grid = torch.arange(1, NUM_SCORES + 1, device=probs.device, dtype=probs.dtype).view(1, 1, -1)
        return (probs * grid).sum(dim=-1)


class ModelEMA:
    """Exponential moving average of the model weights, evaluated as a second model."""

    def __init__(self, model, decay):
        """Copy the model as the EMA shadow and freeze its parameters."""
        self.decay = decay
        self.ema = copy.deepcopy(unwrap(model)).eval()
        for parameter in self.ema.parameters():
            parameter.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        """Move the shadow weights towards the current model weights (buffers are copied)."""
        source = unwrap(model).state_dict()
        for key, value in self.ema.state_dict().items():
            if value.dtype.is_floating_point:
                value.mul_(self.decay).add_(source[key].detach(), alpha=1.0 - self.decay)
            else:
                value.copy_(source[key])


# ======================================================================================
#                                    losses and metrics
# ======================================================================================
def score_class_weights(records):
    """Inverse-frequency weights per category and score, (8, 5), normalised to mean 1 per category."""
    counts = np.zeros((NUM_CATEGORIES, NUM_SCORES), dtype=np.float64)
    for record in records:
        for category, score_index in enumerate(record["osats_hard"]):
            counts[category, score_index] += 1
    weights = counts.sum(axis=1, keepdims=True) / np.maximum(counts, 1) / NUM_SCORES
    return torch.tensor(weights, dtype=torch.float32)


def sutures_statistics(records):
    """Mean and standard deviation of the suture counts (used to standardise the auxiliary target)."""
    values = np.array([record["sutures"] for record in records], dtype=np.float64)
    return float(values.mean()), float(values.std() + 1e-6)


class OSATSLoss(nn.Module):
    """
    Loss of the OSATS heads (TARGET_MODE dependent) plus the auxiliary objectives.

    Targets passed by the trainer: `score_dist` (B, 8, 5) score distribution (one-hot,
    smoothed, rater distribution or mixed), `mean_scores` (B, 8), `grs` (B,), `sutures` (B,).
    forward() returns (total_loss, {part_name: value}) so that the parts can be reported.
    """

    def __init__(self, cfg, class_weights, sutures_mean, sutures_std):
        """Register the class weights, the linear cost matrix, the CORAL levels and the suture statistics."""
        super().__init__()
        self.cfg = cfg
        self.register_buffer("class_weights", class_weights)
        if cfg.CLASS_LOSS not in ("ce", "focal", "sord", "emd"):
            raise ValueError(f"Unknown CLASS_LOSS '{cfg.CLASS_LOSS}'")
        self.register_buffer("cost_matrix", blocks.linear_cost_matrix(NUM_SCORES))   # (5, 5) expected-cost weights
        self.register_buffer("sord_matrix", blocks.soft_ordinal_targets(torch.arange(NUM_SCORES), NUM_SCORES,
                                                                        cfg.SORD_ALPHA))
        self.register_buffer("levels", torch.arange(NUM_SCORES - 1).view(1, 1, -1))
        self.sutures_mean, self.sutures_std = sutures_mean, sutures_std

    def _regression(self, predicted, target):
        """Huber / MSE / L1 loss between predicted and mean scores."""
        kind = self.cfg.REGRESSION_LOSS
        if kind == "huber":
            return F.huber_loss(predicted, target, delta=self.cfg.HUBER_DELTA)
        if kind == "mse":
            return F.mse_loss(predicted, target)
        if kind == "l1":
            return F.l1_loss(predicted, target)
        raise ValueError(f"Unknown REGRESSION_LOSS '{kind}'")

    def _classification(self, logits, score_dist):
        """
        Per-category classification loss (CLASS_LOSS) on (B, 8, 5) logits with soft targets, optional class
        balancing (cross-entropy / SORD / focal) and the expected-cost penalty.
        """
        cfg = self.cfg
        balance = self.class_weights.unsqueeze(0) if cfg.CLASS_BALANCE else None      # (1, 8, 5)
        if cfg.CLASS_LOSS == "emd":
            loss = blocks.emd_loss(logits, score_dist)
        elif cfg.CLASS_LOSS == "focal":
            loss = blocks.focal_loss(logits, score_dist, cfg.FOCAL_GAMMA, balance)
        else:
            targets = score_dist @ self.sord_matrix if cfg.CLASS_LOSS == "sord" else score_dist
            log_probs = F.log_softmax(logits.float(), dim=-1)             # (B, 8, 5)
            per_category = -(targets * log_probs).sum(dim=-1)             # (B, 8)
            if balance is not None:
                per_category = per_category * (score_dist * balance).sum(dim=-1)
            loss = per_category.mean()
        if cfg.EC_LOSS_WEIGHT > 0:
            loss = loss + cfg.EC_LOSS_WEIGHT * blocks.expected_cost_term(logits, score_dist, self.cost_matrix)
        return loss

    def _coral(self, logits, score_dist):
        """CORAL binary cross-entropy on the cumulative targets [y > 0, y > 1, y > 2, y > 3]."""
        hard = score_dist.argmax(dim=-1, keepdim=True)                     # (B, 8, 1) class index 0..4
        cumulative_targets = (hard > self.levels).float()                  # (B, 8, 4)
        return F.binary_cross_entropy_with_logits(logits.float(), cumulative_targets)

    def forward(self, outputs, score_dist, mean_scores, grs, sutures, core_model):
        """Total loss of a batch and its named parts; `core_model` provides expected_scores() for the GRS term."""
        cfg, parts = self.cfg, {}
        if cfg.TARGET_MODE == "regression":
            parts["reg"] = self._regression(outputs["reg"].float(), mean_scores)
        elif cfg.TARGET_MODE == "classification":
            parts["cls"] = self._classification(outputs["cls"], score_dist)
        elif cfg.TARGET_MODE == "hybrid":
            parts["cls"] = self._classification(outputs["cls"], score_dist)
            parts["reg"] = cfg.HYBRID_REGRESSION_WEIGHT * self._regression(outputs["reg"].float(), mean_scores)
        elif cfg.TARGET_MODE == "coral":
            parts["coral"] = self._coral(outputs["coral"], score_dist)
        else:
            raise ValueError(f"Unknown TARGET_MODE '{cfg.TARGET_MODE}'")
        if cfg.AUX_GRS_WEIGHT > 0:
            predicted_grs = core_model.expected_scores(outputs).sum(dim=1)                # (B,)
            parts["grs"] = cfg.AUX_GRS_WEIGHT * F.smooth_l1_loss(predicted_grs / NUM_CATEGORIES, grs / NUM_CATEGORIES)
        if cfg.AUX_SUTURES_WEIGHT > 0 and "sutures" in outputs:
            target = (sutures - self.sutures_mean) / self.sutures_std
            predicted = outputs["sutures"].float().squeeze(-1)
            parts["sutures"] = cfg.AUX_SUTURES_WEIGHT * F.smooth_l1_loss(predicted, target)
        total = sum(parts.values())
        return total, {name: float(value.detach()) for name, value in parts.items()}


def macro_f1(y_true, y_pred, num_classes, include_absent):
    """Macro-averaged F1 as defined in the challenge paper (F1 per class, then averaged over the classes)."""
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    scores = []
    for class_id in range(num_classes):
        true_pos = np.sum((y_true == class_id) & (y_pred == class_id))
        false_pos = np.sum((y_true != class_id) & (y_pred == class_id))
        false_neg = np.sum((y_true == class_id) & (y_pred != class_id))
        if true_pos + false_pos + false_neg == 0:
            if include_absent:
                scores.append(0.0)
            continue
        scores.append(2 * true_pos / (2 * true_pos + false_pos + false_neg))
    return float(np.mean(scores)) if scores else 0.0


def expected_cost(y_true, y_pred, num_classes):
    """Expected cost with linear weights |i - j| / (C - 1), i.e. a normalised absolute error."""
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    return float(np.mean(np.abs(y_true - y_pred) / (num_classes - 1))) if len(y_true) else 0.0


def compute_metrics(true_hard, pred_hard, true_mean, cfg):
    """
    Challenge metrics for Task 2: macro-F1 and expected cost per category (5 ordinal
    scores), averaged over the eight categories; plus MAE against the mean rater score.
    true_hard / pred_hard: (N, 8) class indices 0..4; true_mean: (N, 8) mean scores 1..5.
    """
    true_hard, pred_hard, true_mean = np.asarray(true_hard), np.asarray(pred_hard), np.asarray(true_mean)
    per_category_f1, per_category_ec = [], []
    for category in range(NUM_CATEGORIES):
        per_category_f1.append(macro_f1(true_hard[:, category], pred_hard[:, category], NUM_SCORES,
                                        cfg.F1_INCLUDE_ABSENT_CLASSES))
        per_category_ec.append(expected_cost(true_hard[:, category], pred_hard[:, category], NUM_SCORES))
    mean_f1, mean_ec = float(np.mean(per_category_f1)), float(np.mean(per_category_ec))
    mae = float(np.mean(np.abs((pred_hard + 1) - true_mean))) if len(true_mean) else 0.0
    exact_match = float(np.mean(true_hard == pred_hard)) if len(true_hard) else 0.0
    return {"macro_f1": mean_f1, "expected_cost": mean_ec, "rank_score": mean_f1 - mean_ec, "mae": mae,
            "exact_match": exact_match,
            "per_category_f1": dict(zip(CATEGORY_NAMES, [round(value, 4) for value in per_category_f1])),
            "per_category_ec": dict(zip(CATEGORY_NAMES, [round(value, 4) for value in per_category_ec]))}


# ======================================================================================
#                                      inference
# ======================================================================================
@torch.no_grad()
def predict_outputs(model, records, cfg, device, num_clips, hflip, batch_size=None, desc="inference"):
    """
    Average the score probabilities (N, 8, 5) and the expected scores (N, 8) over
    `num_clips` temporal clips (and their horizontal flips when requested).
    """
    model.eval()
    loader = make_loader(records, cfg, train=False, num_clips=num_clips,
                         batch_size=batch_size or cfg.INFER_BATCH_SIZE)
    prob_sum = np.zeros((len(records), NUM_CATEGORIES, NUM_SCORES), dtype=np.float64)
    value_sum = np.zeros((len(records), NUM_CATEGORIES), dtype=np.float64)
    counts = np.zeros(len(records), dtype=np.float64)
    core = unwrap(model)
    for clips, _, record_indices in tqdm(loader, desc=desc, unit="batch", leave=False):
        clips = clips.to(device, non_blocking=True)
        views = [clips, torch.flip(clips, dims=[-1])] if hflip else [clips]
        for view in views:
            with autocast_context(device, cfg.USE_AMP):
                outputs = model(view)
            probs = core.score_probabilities(outputs).cpu().numpy()
            values = core.expected_scores(outputs).cpu().numpy()
            for batch_pos, record_idx in enumerate(record_indices.tolist()):
                prob_sum[record_idx] += probs[batch_pos]
                value_sum[record_idx] += values[batch_pos]
                counts[record_idx] += 1
    if np.any(counts == 0):
        raise RuntimeError("Some videos received no prediction; the inference loader is inconsistent")
    return prob_sum / counts[:, None, None], value_sum / counts[:, None]


def final_scores(cfg, probs, values):
    """Integer scores 1..5 (N, 8): rounded expected value for regression, most probable score otherwise."""
    if cfg.TARGET_MODE == "regression":
        return np.clip(np.floor(values + 0.5), 1, NUM_SCORES).astype(int)
    return probs.argmax(axis=-1) + 1


def write_predictions(records, scores, values, path_csv):
    """Submission file: one row per video with the eight integer scores, their sum and the expected values."""
    rows = []
    for record, score_row, value_row in zip(records, scores, values):
        row = OrderedDict([("VIDEO", record["video_id"])])
        row.update((name, int(score_row[category])) for category, name in enumerate(CATEGORY_NAMES))
        row["GRS_PREDICTED"] = int(np.sum(score_row))
        row.update((f"{name}_EXPECTED", round(float(value_row[category]), 4))
                   for category, name in enumerate(CATEGORY_NAMES))
        rows.append(row)
    pd.DataFrame(rows).to_csv(path_csv, index=False)
    write_json(os.path.splitext(path_csv)[0] + ".json",
               {row["VIDEO"]: {name: int(row[name]) for name in CATEGORY_NAMES} for row in rows})


def list_videos(folder):
    """Records (with neutral placeholder targets) for every video file of a folder, sorted by file name."""
    files = sorted(name for name in os.listdir(folder) if name.lower().endswith(VIDEO_EXTENSIONS))
    if not files:
        raise FileNotFoundError(f"No video files found in {folder}")
    return [{"video_id": os.path.splitext(name)[0], "path": os.path.join(folder, name), "label": -1, "group": name,
             "osats_mean": np.zeros(NUM_CATEGORIES, dtype=np.float32),
             "osats_hard": np.zeros(NUM_CATEGORIES, dtype=np.int64),
             "osats_soft": np.full((NUM_CATEGORIES, NUM_SCORES), 1.0 / NUM_SCORES, dtype=np.float32),
             "grs_mean": 0.0, "sutures": 0.0} for name in files]


# ======================================================================================
#                                       trainer
# ======================================================================================
class Trainer:
    """
    Runs one training configuration: builds data, model, optimiser and schedule, trains
    for the requested number of epochs and (unless `probe` is set) writes checkpoints,
    submissions and the training report after every epoch.
    """

    def __init__(self, cfg, train_records, val_records, run_dir, device, probe=False, tag="main"):
        """Prepare loaders, model, EMA, loss, optimiser, scheduler, scaler and the run folders."""
        self.cfg = cfg
        self.device = device
        self.run_dir = run_dir
        self.probe = probe
        self.tag = tag
        self.train_records, self.val_records = train_records, val_records
        self.history = []
        self.batch_stats = blocks.RunningStats()
        self.best_score, self.best_epoch, self.epochs_without_improvement = -1e9, -1, 0

        self.train_loader = make_loader(train_records, cfg, train=True)
        self.model = OSATSModel(cfg)
        if cfg.CHECKPOINT_INIT:
            self._load_initial_weights(cfg.CHECKPOINT_INIT)
        self.model.to(device)
        if device.type == "cuda" and torch.cuda.device_count() > 1:
            self.model = nn.DataParallel(self.model)
            LOG.info("DataParallel over %d GPUs", torch.cuda.device_count())
        self.ema = ModelEMA(self.model, cfg.EMA_DECAY) if cfg.EMA_DECAY > 0 else None

        sutures_mean, sutures_std = sutures_statistics(train_records)
        self.criterion = OSATSLoss(cfg, score_class_weights(train_records), sutures_mean, sutures_std).to(device)
        self.optimizer = self._build_optimizer()
        self.steps_per_epoch = max(1, math.ceil(len(self.train_loader) / cfg.GRAD_ACCUM_STEPS))
        self.scheduler, self.scheduler_per_step = self._build_scheduler()
        self.scaler = make_grad_scaler(enabled=(cfg.USE_AMP and device.type == "cuda"))

        self.submission_records = None
        if not probe:
            for sub_folder in ("checkpoints", "submissions", "val_predictions"):
                os.makedirs(os.path.join(run_dir, sub_folder), exist_ok=True)
            if cfg.PREDICT_INPUT_DIR:
                self.submission_records = list_videos(cfg.PREDICT_INPUT_DIR)
                verify_and_cache(self.submission_records, cfg, "submission videos")

    # ---------------------------------------------------------------- set-up helpers
    def _load_initial_weights(self, checkpoint_path):
        """Initialise the network from a checkpoint (shape-compatible tensors only)."""
        state = load_checkpoint(checkpoint_path)
        weights = state.get("ema_state") or state["model_state"]
        own = self.model.state_dict()
        compatible = {key: value for key, value in weights.items() if key in own and own[key].shape == value.shape}
        self.model.load_state_dict(compatible, strict=False)
        LOG.info("Initialised %d of %d tensors from %s", len(compatible), len(own), checkpoint_path)

    def _build_optimizer(self):
        """Create the optimiser with a lower learning rate for the pre-trained weights than for the new layers."""
        cfg, core = self.cfg, unwrap(self.model)
        pretrained = pretrained_parameters(core)
        pretrained_ids = {id(parameter) for parameter in pretrained}
        new_layers = [parameter for parameter in core.parameters() if id(parameter) not in pretrained_ids]
        groups = [{"params": pretrained, "lr": cfg.LEARNING_RATE},
                  {"params": new_layers, "lr": cfg.LEARNING_RATE * cfg.HEAD_LR_MULT}]
        return blocks.build_optimizer(groups, cfg)

    def _build_scheduler(self):
        """Create the learning-rate schedule; returns (scheduler, stepped_per_batch)."""
        return blocks.build_scheduler(self.optimizer, self.cfg, self.steps_per_epoch)

    def _set_backbone_trainable(self, trainable):
        """Freeze or unfreeze the pre-trained weights (used by FREEZE_BACKBONE_EPOCHS)."""
        for parameter in pretrained_parameters(unwrap(self.model)):
            parameter.requires_grad_(trainable)

    def _targets(self, targets):
        """
        Loss targets of a batch from the dataset dictionary, as device tensors:
        (score distribution (B, 8, 5), mean scores (B, 8), GRS (B,), suture count (B,)).
        The score distribution follows LABEL_MODE; the CORAL head always uses the rounded mean.
        """
        cfg, device = self.cfg, self.device
        hard = targets["scores_hard"].to(device)                             # (B, 8)
        if cfg.LABEL_MODE == "hard" or cfg.TARGET_MODE == "coral":
            score_dist = F.one_hot(hard, NUM_SCORES).float()
        elif cfg.LABEL_MODE == "smoothed":
            one_hot = F.one_hot(hard, NUM_SCORES).float()
            score_dist = one_hot * (1 - cfg.LABEL_SMOOTHING) + cfg.LABEL_SMOOTHING / NUM_SCORES
        elif cfg.LABEL_MODE == "soft_raters":
            score_dist = targets["scores_soft"].to(device)
        else:
            raise ValueError(f"Unknown LABEL_MODE '{cfg.LABEL_MODE}'")
        return (score_dist, targets["scores_mean"].to(device), targets["grs"].to(device).squeeze(1),
                targets["sutures"].to(device).squeeze(1))

    # ---------------------------------------------------------------- one epoch
    def train_epoch(self, epoch):
        """
        Train for one epoch; returns (mean training loss, mean value of every loss part). The batch-loss
        statistics of the epoch (a GRM signal) are kept in self.batch_stats.
        """
        cfg, model, device = self.cfg, self.model, self.device
        model.train()
        self._set_backbone_trainable(epoch >= cfg.FREEZE_BACKBONE_EPOCHS)
        running_loss, seen, part_sums = 0.0, 0, Counter()
        self.batch_stats = blocks.RunningStats()
        self.optimizer.zero_grad(set_to_none=True)
        progress = tqdm(self.train_loader, desc=f"[{self.tag}] epoch {epoch + 1}/{cfg.NUM_EPOCHS} train",
                        unit="batch", leave=False)
        for step, (clips, targets, _) in enumerate(progress):
            clips = clips.to(device, non_blocking=True)
            score_dist, mean_scores, grs, sutures = self._targets(targets)
            permutation, lam = None, 1.0
            if cfg.TARGET_MODE != "coral":
                clips, permutation, lam = blocks.mix_batch(clips, cfg)
            if permutation is not None:
                score_dist = lam * score_dist + (1 - lam) * score_dist[permutation]
                mean_scores = lam * mean_scores + (1 - lam) * mean_scores[permutation]
                grs = lam * grs + (1 - lam) * grs[permutation]
                sutures = lam * sutures + (1 - lam) * sutures[permutation]
            with autocast_context(device, cfg.USE_AMP):
                outputs = model(clips)
                loss, parts = self.criterion(outputs, score_dist, mean_scores, grs, sutures, unwrap(model))
                loss = loss / cfg.GRAD_ACCUM_STEPS
            self.scaler.scale(loss).backward()
            if (step + 1) % cfg.GRAD_ACCUM_STEPS == 0 or (step + 1) == len(self.train_loader):
                if cfg.GRAD_CLIP_NORM > 0:
                    self.scaler.unscale_(self.optimizer)
                    nn.utils.clip_grad_norm_(model.parameters(), cfg.GRAD_CLIP_NORM)
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.optimizer.zero_grad(set_to_none=True)
                if self.ema is not None:
                    self.ema.update(model)
                if self.scheduler is not None and self.scheduler_per_step:
                    self.scheduler.step()
            batch_loss = loss.item() * cfg.GRAD_ACCUM_STEPS
            self.batch_stats.add(batch_loss)
            running_loss += batch_loss * clips.shape[0]
            seen += clips.shape[0]
            for name, value in parts.items():
                part_sums[name] += value * clips.shape[0]
            progress.set_postfix(loss=f"{running_loss / max(seen, 1):.4f}",
                                 lr=f"{self.optimizer.param_groups[0]['lr']:.2e}")
        return running_loss / max(seen, 1), {name: value / max(seen, 1) for name, value in part_sums.items()}

    @torch.no_grad()
    def evaluate(self, model, desc):
        """
        Validation loss and challenge metrics of one model (raw or EMA weights).
        Returns (metrics, (probabilities (N, 8, 5), expected values (N, 8), integer scores (N, 8))).
        """
        cfg, device = self.cfg, self.device
        model.eval()
        loader = make_loader(self.val_records, cfg, train=False, num_clips=cfg.VAL_TTA_CLIPS,
                             batch_size=cfg.INFER_BATCH_SIZE)
        core = unwrap(model)
        prob_sum = np.zeros((len(self.val_records), NUM_CATEGORIES, NUM_SCORES))
        value_sum = np.zeros((len(self.val_records), NUM_CATEGORIES))
        counts = np.zeros(len(self.val_records))
        total_loss, seen = 0.0, 0
        for clips, targets, record_indices in tqdm(loader, desc=desc, unit="batch", leave=False):
            clips = clips.to(device, non_blocking=True)
            score_dist = F.one_hot(targets["scores_hard"].to(device), NUM_SCORES).float()
            with autocast_context(device, cfg.USE_AMP):
                outputs = model(clips)
            loss, _ = self.criterion(outputs, score_dist, targets["scores_mean"].to(device),
                                     targets["grs"].to(device).squeeze(1), targets["sutures"].to(device).squeeze(1),
                                     core)
            total_loss += loss.item() * clips.shape[0]
            seen += clips.shape[0]
            probs = core.score_probabilities(outputs).cpu().numpy()
            values = core.expected_scores(outputs).cpu().numpy()
            for batch_pos, record_idx in enumerate(record_indices.tolist()):
                prob_sum[record_idx] += probs[batch_pos]
                value_sum[record_idx] += values[batch_pos]
                counts[record_idx] += 1
        probs = prob_sum / np.maximum(counts, 1)[:, None, None]
        values = value_sum / np.maximum(counts, 1)[:, None]
        pred_scores = final_scores(cfg, probs, values)                                # integer scores 1..5
        true_hard = np.stack([record["osats_hard"] for record in self.val_records])
        true_mean = np.stack([record["osats_mean"] for record in self.val_records])
        metrics = compute_metrics(true_hard, pred_scores - 1, true_mean, cfg)
        metrics["val_loss"] = total_loss / max(seen, 1)
        return metrics, (probs, values, pred_scores)

    # ---------------------------------------------------------------- bookkeeping
    def _save_checkpoint(self, epoch, metrics, file_name):
        """Save weights (raw + EMA), configuration and metrics of an epoch under checkpoints/<file_name>."""
        cfg = self.cfg
        payload = {"epoch": epoch, "task": "task2_osats", "config": config_to_dict(cfg), "metrics": metrics,
                   "category_names": CATEGORY_NAMES, "model_state": unwrap(self.model).state_dict(),
                   "ema_state": self.ema.ema.state_dict() if self.ema is not None else None,
                   "sutures_statistics": [self.criterion.sutures_mean, self.criterion.sutures_std]}
        if cfg.SAVE_OPTIMIZER_STATE:
            payload["optimizer_state"] = self.optimizer.state_dict()
            payload["scheduler_state"] = self.scheduler.state_dict() if self.scheduler is not None else None
        torch.save(payload, os.path.join(self.run_dir, "checkpoints", file_name))

    def _write_val_predictions(self, epoch, values, pred_scores):
        """Per-video validation predictions and targets of an epoch (val_predictions/epoch_XX.csv)."""
        rows = []
        for record, score_row, value_row in zip(self.val_records, pred_scores, values):
            row = OrderedDict([("VIDEO", record["video_id"]), ("grs_mean", record["grs_mean"])])
            row.update((f"true_{name}", round(float(record["osats_mean"][category]), 3))
                       for category, name in enumerate(CATEGORY_NAMES))
            row.update((f"pred_{name}", int(score_row[category])) for category, name in enumerate(CATEGORY_NAMES))
            row.update((f"expected_{name}", round(float(value_row[category]), 3))
                       for category, name in enumerate(CATEGORY_NAMES))
            rows.append(row)
        pd.DataFrame(rows).to_csv(os.path.join(self.run_dir, "val_predictions", f"epoch_{epoch + 1:02d}.csv"),
                                  index=False)

    def _write_submission(self, epoch):
        """Predictions of this epoch for the inference videos (or the validation split); returns the folder."""
        cfg = self.cfg
        model = self.ema.ema if (self.ema is not None and cfg.USE_EMA_FOR_INFERENCE) else unwrap(self.model)
        records = self.submission_records if self.submission_records is not None else self.val_records
        probs, values = predict_outputs(model, records, cfg, self.device, cfg.TTA_NUM_CLIPS, cfg.TTA_HFLIP,
                                        desc=f"submission epoch {epoch + 1}")
        folder = os.path.join(self.run_dir, "submissions", f"epoch_{epoch + 1:02d}")
        os.makedirs(folder, exist_ok=True)
        write_predictions(records, final_scores(cfg, probs, values), values,
                          os.path.join(folder, cfg.SUBMISSION_FILENAME))
        return folder

    def _write_report(self, row):
        """Append the epoch row to training_report.csv and refresh training_report.json."""
        csv_path = os.path.join(self.run_dir, "training_report.csv")
        flat_row = OrderedDict((key, value) for key, value in row.items() if not isinstance(value, (list, dict)))
        write_header = not os.path.isfile(csv_path)
        with open(csv_path, "a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(flat_row.keys()))
            if write_header:
                writer.writeheader()
            writer.writerow(flat_row)
        write_json(os.path.join(self.run_dir, "training_report.json"),
                   {"config": config_to_dict(self.cfg), "best_epoch": self.best_epoch + 1,
                    "best_score": self.best_score, "epochs": self.history})

    def _selection_score(self, metrics):
        """Scalar used to compare epochs (higher is better) according to SELECTION_METRIC."""
        value = metrics[self.cfg.SELECTION_METRIC]
        return -value if self.cfg.SELECTION_METRIC in ("expected_cost", "mae", "val_loss") else value

    # ---------------------------------------------------------------- main loop
    def fit(self):
        """Run the training loop; returns the per-epoch history (list of report rows)."""
        cfg = self.cfg
        LOG.info("[%s] training %d epochs | %d train / %d val videos | backbone %s | target mode %s | class loss %s | "
                 "optimizer %s | scheduler %s | batch %d x %d", self.tag, cfg.NUM_EPOCHS, len(self.train_records),
                 len(self.val_records), cfg.BACKBONE, cfg.TARGET_MODE, cfg.CLASS_LOSS, cfg.OPTIMIZER, cfg.SCHEDULER,
                 cfg.BATCH_SIZE, cfg.GRAD_ACCUM_STEPS)
        for epoch in range(cfg.NUM_EPOCHS):
            epoch_start = time.time()
            train_loss, loss_parts = self.train_epoch(epoch)
            metrics, outputs = self.evaluate(self.model, f"[{self.tag}] epoch {epoch + 1} val")
            ema_metrics, ema_outputs = None, None
            if self.ema is not None:
                ema_metrics, ema_outputs = self.evaluate(self.ema.ema, f"[{self.tag}] epoch {epoch + 1} val (EMA)")
            if self.scheduler is not None and not self.scheduler_per_step:
                self.scheduler.step(metrics["val_loss"])

            # the epoch score used for model selection prefers the EMA weights when they are better
            use_ema = ema_metrics is not None and self._selection_score(ema_metrics) > self._selection_score(metrics)
            chosen_metrics, chosen_outputs = (ema_metrics, ema_outputs) if use_ema else (metrics, outputs)
            score = self._selection_score(chosen_metrics)
            improved = score > self.best_score
            if improved:
                self.best_score, self.best_epoch, self.epochs_without_improvement = score, epoch, 0
            else:
                self.epochs_without_improvement += 1

            row = OrderedDict([
                ("epoch", epoch + 1), ("tag", self.tag),
                ("lr_backbone", self.optimizer.param_groups[0]["lr"]),
                ("lr_head", self.optimizer.param_groups[1]["lr"]), ("train_loss", train_loss),
                ("train_loss_std", self.batch_stats.std), ("train_batches", self.batch_stats.count),
            ])
            row.update((f"train_loss_{name}", value) for name, value in loss_parts.items())
            row.update([
                ("val_loss", metrics["val_loss"]), ("val_macro_f1", metrics["macro_f1"]),
                ("val_expected_cost", metrics["expected_cost"]), ("val_mae", metrics["mae"]),
                ("val_exact_match", metrics["exact_match"]), ("val_rank_score", metrics["rank_score"]),
                ("ema_macro_f1", ema_metrics["macro_f1"] if ema_metrics else None),
                ("ema_expected_cost", ema_metrics["expected_cost"] if ema_metrics else None),
                ("ema_rank_score", ema_metrics["rank_score"] if ema_metrics else None),
                ("selected_weights", "ema" if use_ema else "raw"), ("selection_score", score),
                ("best_so_far", improved), ("epoch_seconds", round(time.time() - epoch_start, 1)),
                ("batch_size", cfg.BATCH_SIZE), ("backbone", cfg.BACKBONE), ("target_mode", cfg.TARGET_MODE),
                ("class_loss", cfg.CLASS_LOSS), ("optimizer", cfg.OPTIMIZER), ("scheduler", cfg.SCHEDULER),
                ("learning_rate", cfg.LEARNING_RATE), ("frame_sampling", cfg.FRAME_SAMPLING),
                ("weight_decay", cfg.WEIGHT_DECAY),
            ])
            row.update((f"f1_{name}", value) for name, value in chosen_metrics["per_category_f1"].items())
            row.update((f"ec_{name}", value) for name, value in chosen_metrics["per_category_ec"].items())
            self.history.append(row)
            ema_text = (f" | EMA F1 {ema_metrics['macro_f1']:.4f} EC {ema_metrics['expected_cost']:.4f}"
                        if ema_metrics else "")
            LOG.info("[%s] epoch %d/%d | train loss %.4f | val loss %.4f | mean macro-F1 %.4f | mean EC %.4f "
                     "| MAE %.3f%s | %.0fs%s", self.tag, epoch + 1, cfg.NUM_EPOCHS, train_loss, metrics["val_loss"],
                     metrics["macro_f1"], metrics["expected_cost"], metrics["mae"], ema_text,
                     time.time() - epoch_start, " | new best" if improved else "")
            LOG.info("[%s] per-category F1: %s", self.tag, chosen_metrics["per_category_f1"])
            LOG.info("[%s] per-category EC: %s", self.tag, chosen_metrics["per_category_ec"])

            if not self.probe:
                self._save_checkpoint(epoch, chosen_metrics, f"epoch_{epoch + 1:02d}.pt")
                self._save_checkpoint(epoch, chosen_metrics, "last.pt")
                if improved:
                    self._save_checkpoint(epoch, chosen_metrics, "best.pt")
                _, chosen_values, chosen_scores = chosen_outputs
                self._write_val_predictions(epoch, chosen_values, chosen_scores)
                folder = self._write_submission(epoch)
                if improved:
                    best_dir = os.path.join(self.run_dir, "best_submission")
                    shutil.rmtree(best_dir, ignore_errors=True)
                    shutil.copytree(folder, best_dir)
                self._write_report(row)

            if 0 < cfg.EARLY_STOPPING_PATIENCE <= self.epochs_without_improvement:
                LOG.info("[%s] early stopping: no improvement for %d epochs", self.tag, cfg.EARLY_STOPPING_PATIENCE)
                break
        LOG.info("[%s] finished: best epoch %d with %s = %.4f", self.tag, self.best_epoch + 1,
                 cfg.SELECTION_METRIC, self.best_score)
        return self.history


# ======================================================================================
#                      GRM hyper-parameter search (adapter to grm.py)
# ======================================================================================
def stratified_subset(records, fraction, seed):
    """Stratified (by class label) random subset with `fraction` of the records, at least one per class."""
    if fraction >= 1.0:
        return list(records)
    rng = random.Random(seed)
    by_label = OrderedDict()
    for record in records:
        by_label.setdefault(record["label"], []).append(record)
    subset = []
    for members in by_label.values():
        members = list(members)
        rng.shuffle(members)
        subset.extend(members[:max(1, int(round(fraction * len(members))))])
    return subset


def prepare_data(cfg):
    """Load and verify the annotated videos and split them; returns (train_records, val_records)."""
    records = load_annotations(cfg)
    if cfg.STRICT_DATA_CHECK or cfg.FRAME_CACHE_DIR is not None:
        verify_and_cache(records, cfg, "training videos")
    return split_records(records, cfg, cfg.SEED)


def build_grm_task(task_name, cfg, device):
    """
    GRM adapter of this script. Data are loaded only when a phase trains something, so that
    grm_fit / grm_report run without touching the videos.
    """
    data = {}

    def splits():
        """Training / validation records, loaded once per call of the script."""
        if not data:
            data["train"], data["val"] = prepare_data(cfg)
        return data["train"], data["val"]

    def run_probe(overrides, epochs, tag, data_fraction):
        """Train one configuration for `epochs` epochs without writing files; returns its history."""
        train_records, val_records = splits()
        probe_cfg = clone_config(cfg)
        apply_overrides(probe_cfg, overrides)
        probe_cfg.NUM_EPOCHS = epochs
        probe_cfg.EARLY_STOPPING_PATIENCE = 0
        subset = stratified_subset(train_records, data_fraction, cfg.SEED)
        trainer = Trainer(probe_cfg, subset, val_records, cfg.GRM_DIR, device, probe=True, tag=tag)
        try:
            return trainer.fit()
        finally:
            del trainer
            if device.type == "cuda":
                torch.cuda.empty_cache()

    def train_final(overrides):
        """Full training of the configuration chosen by the GRM, in <GRM_DIR>/final_<backbone>."""
        train_records, val_records = splits()
        final_cfg = clone_config(cfg)
        apply_overrides(final_cfg, overrides)
        if cfg.GRM_FINAL_EPOCHS:
            final_cfg.NUM_EPOCHS = cfg.GRM_FINAL_EPOCHS
        run_dir = os.path.join(cfg.GRM_DIR, f"final_{final_cfg.BACKBONE.replace(':', '_')}")
        os.makedirs(run_dir, exist_ok=True)
        write_json(os.path.join(run_dir, "config_used.json"), config_to_dict(final_cfg))
        history = Trainer(final_cfg, train_records, val_records, run_dir, device, tag="grm-final").fit()
        LOG.info("Final run folder: %s", run_dir)
        return history

    return grm.GRMTask(task_name, cfg, run_probe, train_final, LOG)


# ======================================================================================
#                                    entry points
# ======================================================================================
def run_training(cfg, run_dir, device):
    """Load annotations, verify videos, split and train one configuration."""
    train_records, val_records = prepare_data(cfg)
    write_json(os.path.join(run_dir, "config_used.json"), config_to_dict(cfg))
    Trainer(cfg, train_records, val_records, run_dir, device, tag="main").fit()
    LOG.info("Run folder: %s", run_dir)


ARCHITECTURE_KEYS = ("BACKBONE", "TARGET_MODE", "HEAD_HIDDEN", "HEAD_DROPOUT", "AUX_SUTURES_WEIGHT", "NUM_FRAMES",
                     "IMG_SIZE", "FRAME_SAMPLING", "SAMPLING_POWER", "FRAME_POOL_SIZE", "CACHE_IMG_SIZE",
                     "FRAME_RESIZE_MODE", "NORMALIZATION", "TEMPORAL_HEAD", "TEMPORAL_HIDDEN", "TEMPORAL_LAYERS",
                     "TEMPORAL_HEADS_NUM", "TEMPORAL_DROPOUT")


def load_model_from_checkpoint(checkpoint_path, cfg, device):
    """Rebuild the network described by a checkpoint and load its (EMA) weights; returns (model, config)."""
    state = load_checkpoint(checkpoint_path)
    ckpt_cfg = clone_config(cfg)
    # the architecture and the clip geometry come from the checkpoint, everything else from CONFIG
    for key in ARCHITECTURE_KEYS:
        if key in state["config"]:
            setattr(ckpt_cfg, key, state["config"][key])
    if "NORMALIZATION" not in state["config"]:
        ckpt_cfg.NORMALIZATION = "kinetics"       # checkpoints written before the option existed
    ckpt_cfg.PRETRAINED = False
    model = OSATSModel(ckpt_cfg)
    use_ema = cfg.USE_EMA_FOR_INFERENCE and state.get("ema_state")
    model.load_state_dict(state["ema_state"] if use_ema else state["model_state"])
    model.to(device)
    if device.type == "cuda" and torch.cuda.device_count() > 1:
        model = nn.DataParallel(model)
    return model, ckpt_cfg


def run_prediction(cfg, args, device):
    """Predict mode: videos of args.input -> CSV + JSON in args.output (checkpoint ensemble)."""
    if not args.input or not args.output:
        raise ValueError("predict mode needs --input <video folder> and --output <folder>")
    checkpoints = list(cfg.ENSEMBLE_CHECKPOINTS) or ([args.checkpoint] if args.checkpoint else [])
    if not checkpoints:
        raise ValueError("predict mode needs --checkpoint <file> or CONFIG.ENSEMBLE_CHECKPOINTS")
    os.makedirs(args.output, exist_ok=True)
    records = list_videos(args.input)
    LOG.info("Predicting %d videos from %s with %d checkpoint(s)", len(records), args.input, len(checkpoints))
    prob_sum = np.zeros((len(records), NUM_CATEGORIES, NUM_SCORES))
    value_sum = np.zeros((len(records), NUM_CATEGORIES))
    decision_cfg = None                      # the decision rule (TARGET_MODE) of the first checkpoint is used
    for checkpoint_path in checkpoints:
        model, ckpt_cfg = load_model_from_checkpoint(checkpoint_path, cfg, device)
        decision_cfg = decision_cfg or ckpt_cfg
        verify_and_cache(records, ckpt_cfg, f"videos for {os.path.basename(checkpoint_path)}")
        probs, values = predict_outputs(model, records, ckpt_cfg, device, cfg.TTA_NUM_CLIPS, cfg.TTA_HFLIP,
                                        desc=f"predict {os.path.basename(checkpoint_path)}")
        prob_sum += probs
        value_sum += values
        del model
    probs, values = prob_sum / len(checkpoints), value_sum / len(checkpoints)
    output_csv = os.path.join(args.output, cfg.SUBMISSION_FILENAME)
    write_predictions(records, final_scores(decision_cfg, probs, values), values, output_csv)
    LOG.info("Predictions written to %s", output_csv)


def parse_args():
    """Command-line interface (every CONFIG entry can also be overridden with --set)."""
    parser = argparse.ArgumentParser(description="OSS challenge - Task 2 OSATS score prediction")
    parser.add_argument("--mode", choices=("train", "predict") + GRM_MODES, default=None,
                        help="overrides CONFIG.RUN_MODE")
    parser.add_argument("--input", default=None, help="predict mode: folder with the videos to score")
    parser.add_argument("--output", default=None, help="predict mode: folder for the prediction files")
    parser.add_argument("--checkpoint", default=None, help="predict mode: checkpoint file (.pt)")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override any CONFIG entry")
    return parser.parse_args()


def build_config(args):
    """Working copy of CONFIG with the command-line overrides applied."""
    overrides = {}
    for item in args.set:
        if "=" not in item:
            raise ValueError(f"--set expects KEY=VALUE, got '{item}'")
        key, value = item.split("=", 1)
        overrides[key.strip()] = value.strip()
    cfg = clone_config(CONFIG)
    apply_overrides(cfg, overrides)
    if args.mode:
        cfg.RUN_MODE = args.mode
    return cfg


def main():
    """Entry point: dispatch to training, a GRM phase or prediction."""
    args = parse_args()
    cfg = build_config(args)
    export_visible_gpus(cfg)          # before the first CUDA call

    if cfg.RUN_MODE == "predict":
        setup_logging(None)
        set_seed(cfg.SEED, cfg.DETERMINISTIC)
        check_cuda_build(cfg)
        run_prediction(cfg, args, get_device(cfg))
        return

    if cfg.RUN_MODE in GRM_MODES:
        cfg.GRM_DIR = cfg.GRM_DIR or os.path.join(cfg.OUTPUT_ROOT, "grm_task2")
        log_dir = cfg.GRM_DIR
    elif cfg.RUN_MODE == "train":
        run_name = cfg.RUN_NAME or f"task2_{cfg.BACKBONE.replace(':', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        log_dir = os.path.join(cfg.OUTPUT_ROOT, run_name)
    else:
        raise ValueError(f"Unknown RUN_MODE '{cfg.RUN_MODE}'")
    setup_logging(log_dir)
    LOG.info("Task 2 - OSATS score prediction | mode %s | folder %s", cfg.RUN_MODE, log_dir)
    LOG.info("Configuration: %s", json.dumps(grm.to_jsonable(config_to_dict(cfg))))
    set_seed(cfg.SEED, cfg.DETERMINISTIC)
    check_cuda_build(cfg)
    device = get_device(cfg)
    start = time.time()
    if cfg.RUN_MODE == "train":
        run_training(cfg, log_dir, device)
    else:
        grm.GRMRunner(build_grm_task("task2", cfg, device)).run(cfg.RUN_MODE)
    LOG.info("Total time: %.1f minutes", (time.time() - start) / 60)


if __name__ == "__main__":
    main()
