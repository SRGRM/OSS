#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSS Challenge - Task 2 inference: the eight OSATS scores of every video in a folder
===================================================================================

This is the entry point of the challenge container for the task identifier "OSATS":

    python inference_task2.py <input folder with mp4 videos> <output folder>

For every video one row is written to <output>/<OUTPUT_FILENAME> with the column VIDEO (file
name without extension) and one integer score 1..5 per category:

    OSATS_RESPECT, OSATS_MOTION, OSATS_INSTRUMENT, OSATS_SUTURE,
    OSATS_FLOW, OSATS_KNOWLEDGE, OSATS_PERFORMANCE, OSATS_FINAL_QUALITY

Optional columns (WRITE_EXPECTED_VALUES) add the continuous expected score of every category
and the predicted GRS (sum of the eight integer scores).

Checkpoints
-----------
CHECKPOINTS lists one or more files; their score distributions and expected scores are averaged.
Each file may be
  * a checkpoint of task2_osats_prediction.py (best.pt, epoch_XX.pt): network, target
    parameterisation (regression / classification / CORAL / hybrid) and clip geometry come from
    the stored configuration, and the multi-clip / flip test-time augmentation below is applied;
  * a plain state dictionary of an r2plus1d_18 regressing the eight mean scores (the format of
    the first submission): clips of PLAIN_NUM_FRAMES frames at PLAIN_IMG_SIZE pixels.

Decision rule
-------------
DECISION_RULE = "checkpoint" follows the first checkpoint: the rounded expected score for
regression models, the most probable score for classification / CORAL / hybrid models.
"rounded_expectation" and "most_probable" force one rule for every checkpoint.

Usage
-----
    python inference_task2.py /input /output
    python inference_task2.py /input /output --checkpoint runs/<run>/checkpoints/best.pt
    python inference_task2.py /input /output --set DECISION_RULE=rounded_expectation
"""

import argparse
import math
import os
import shutil
import sys
import tempfile
import time

import numpy as np

if __package__:
    from . import inference_common as common
    from . import task2_osats_prediction as osats
else:                                       # executed as a plain script (e.g. inside the container)
    import inference_common as common  # pylint: disable=import-error
    import task2_osats_prediction as osats  # pylint: disable=import-error


# ======================================================================================
#                                      CONFIG
# ======================================================================================
class CONFIG:
    """All options of Task 2 inference (edit here, or override with --set KEY=VALUE)."""

    CHECKPOINTS = ["task2_osats_model.pth"]    # checkpoint files (absolute, or relative to the weights folder); several files -> ensemble
    GPU_IDS = [0]                              # physical GPU ids to use, e.g. [0] | [0, 1] (DataParallel) | [] (CPU only)
    USE_AMP = True                             # True: fp16 autocast on CUDA (faster) | False: full fp32
    BATCH_SIZE = 4                             # videos per forward pass
    NUM_WORKERS = 4                            # DataLoader worker processes (0 = main process)
    USE_EMA_WEIGHTS = True                     # pipeline checkpoints: True: EMA weights when stored | False: raw weights
    TTA_NUM_CLIPS = 3                          # pipeline checkpoints: temporal clips averaged per video (1 = single clip)
    TTA_HFLIP = True                           # pipeline checkpoints: True: also average the horizontally flipped clips | False
    FRAME_CACHE_DIR = None                     # pipeline checkpoints: folder for decoded frame pools; None -> temporary folder removed at the end
    PLAIN_NUM_FRAMES = 16                      # plain state dictionaries: frames per clip (as trained)
    PLAIN_IMG_SIZE = 128                       # plain state dictionaries: clip resolution in pixels (as trained)
    DECISION_RULE = "checkpoint"               # "checkpoint": rule of the first checkpoint | "rounded_expectation": round the expected score | "most_probable": argmax of the score distribution
    ON_UNREADABLE_VIDEO = "error"              # "error": stop when a video cannot be decoded | "fallback": write FALLBACK_SCORE in every category and continue
    FALLBACK_SCORE = 3                         # score written for unreadable videos with ON_UNREADABLE_VIDEO = "fallback" (middle of the 1..5 scale)
    OUTPUT_FILENAME = "task2_results.csv"      # result file written to the output folder
    WRITE_EXPECTED_VALUES = False              # True: add GRS_PREDICTED and <category>_EXPECTED columns | False: VIDEO and the eight scores only
    SEED = 42                                  # seed of the clip sampling (inference is deterministic for a fixed seed)


CATEGORY_NAMES = osats.CATEGORY_NAMES
NUM_CATEGORIES, NUM_SCORES = osats.NUM_CATEGORIES, osats.NUM_SCORES
LOG = osats.LOG


def round_half_up(values):
    """Round mean scores to integers (halves round up, as for the ground truth) and clip to 1..5."""
    return np.clip(np.floor(np.asarray(values) + 0.5), 1, NUM_SCORES).astype(int)


def distribution_around(values, temperature=0.5):
    """(N, 8, 5) score distribution peaked at continuous predictions (used for regression outputs)."""
    grid = np.arange(1, NUM_SCORES + 1, dtype=np.float64).reshape(1, 1, -1)
    logits = -((np.asarray(values)[..., None] - grid) ** 2) / temperature
    logits -= logits.max(axis=-1, keepdims=True)
    return np.exp(logits) / np.exp(logits).sum(axis=-1, keepdims=True)


# ======================================================================================
#                                  prediction per checkpoint
# ======================================================================================
def pipeline_outputs(checkpoint_path, input_dir, paths, cfg, device, cache_dir):
    """(probabilities (N, 8, 5), expected scores (N, 8), decision rule) of a task2_osats_prediction.py checkpoint."""
    base_cfg = osats.clone_config(osats.CONFIG)
    base_cfg.GPU_IDS, base_cfg.USE_AMP, base_cfg.SEED = cfg.GPU_IDS, cfg.USE_AMP, cfg.SEED
    base_cfg.NUM_WORKERS, base_cfg.INFER_BATCH_SIZE = cfg.NUM_WORKERS, cfg.BATCH_SIZE
    base_cfg.USE_EMA_FOR_INFERENCE, base_cfg.FRAME_CACHE_DIR = cfg.USE_EMA_WEIGHTS, cache_dir
    model, ckpt_cfg = osats.load_model_from_checkpoint(checkpoint_path, base_cfg, device)
    LOG.info("Pipeline checkpoint: backbone %s, target mode %s, %d frames at %d px", ckpt_cfg.BACKBONE,
             ckpt_cfg.TARGET_MODE, ckpt_cfg.NUM_FRAMES, ckpt_cfg.IMG_SIZE)
    wanted = set(paths)
    records = [record for record in osats.list_videos(input_dir) if record["path"] in wanted]
    osats.verify_and_cache(records, ckpt_cfg, "test videos")
    probs, values = osats.predict_outputs(model, records, ckpt_cfg, device, cfg.TTA_NUM_CLIPS, cfg.TTA_HFLIP,
                                          desc=f"predict {os.path.basename(checkpoint_path)}")
    rule = "rounded_expectation" if ckpt_cfg.TARGET_MODE == "regression" else "most_probable"
    return probs, values, rule


def plain_outputs(state_dict, paths, cfg, device):
    """(probabilities, expected scores, decision rule) of a plain r2plus1d_18 regressing the eight scores."""
    model = common.build_plain_r2plus1d(state_dict, NUM_CATEGORIES, "Task 2")
    model = common.wrap_data_parallel(model, device)
    LOG.info("Plain r2plus1d_18 state dictionary: %d frames at %d px", cfg.PLAIN_NUM_FRAMES, cfg.PLAIN_IMG_SIZE)
    values = np.clip(common.run_plain_video_model(model, paths, cfg, device), 1.0, float(NUM_SCORES))
    return distribution_around(values), values, "rounded_expectation"


# ======================================================================================
#                                        main
# ======================================================================================
def predict(input_dir, output_dir, cfg, checkpoint_paths, device):
    """Predict every video of `input_dir` and write the result file; returns its path."""
    if cfg.DECISION_RULE not in ("checkpoint", "rounded_expectation", "most_probable"):
        raise ValueError(f"Unknown DECISION_RULE '{cfg.DECISION_RULE}'")
    paths = common.list_video_files(input_dir)
    LOG.info("Found %d videos in %s", len(paths), input_dir)
    unreadable = common.find_unreadable_videos(paths, cfg.PLAIN_NUM_FRAMES)
    common.handle_unreadable(unreadable, cfg.ON_UNREADABLE_VIDEO, LOG)
    readable = [path for path in paths if path not in unreadable]

    prob_sum = np.zeros((len(readable), NUM_CATEGORIES, NUM_SCORES))
    value_sum = np.zeros((len(readable), NUM_CATEGORIES))
    rules = []
    cache_dir = cfg.FRAME_CACHE_DIR or tempfile.mkdtemp(prefix="task2_frames_")
    try:
        for checkpoint_path in checkpoint_paths:
            state = common.read_checkpoint(checkpoint_path)
            kind = common.checkpoint_kind(state)
            LOG.info("Checkpoint %s (%s)", checkpoint_path, kind)
            if not readable:
                continue
            if kind == "pipeline":
                probs, values, rule = pipeline_outputs(checkpoint_path, input_dir, readable, cfg, device,
                                                       cache_dir)
            else:
                probs, values, rule = plain_outputs(state, readable, cfg, device)
            prob_sum += probs
            value_sum += values
            rules.append(rule)
    finally:
        if cfg.FRAME_CACHE_DIR is None:
            shutil.rmtree(cache_dir, ignore_errors=True)

    rule = cfg.DECISION_RULE if cfg.DECISION_RULE != "checkpoint" else (rules[0] if rules else "rounded_expectation")
    probs, values = prob_sum / len(checkpoint_paths), value_sum / len(checkpoint_paths)
    scores = round_half_up(values) if rule == "rounded_expectation" else probs.argmax(axis=-1) + 1
    LOG.info("Decision rule: %s", rule)

    predictions = {path: (score_row, value_row) for path, score_row, value_row in zip(readable, scores, values)}
    fallback = (np.full(NUM_CATEGORIES, cfg.FALLBACK_SCORE), np.full(NUM_CATEGORIES, float(cfg.FALLBACK_SCORE)))
    rows = []
    for path in paths:
        score_row, value_row = predictions.get(path, fallback)
        row = {"VIDEO": common.video_id(path)}
        row.update({name: int(score_row[category]) for category, name in enumerate(CATEGORY_NAMES)})
        if cfg.WRITE_EXPECTED_VALUES:
            row["GRS_PREDICTED"] = int(np.sum(score_row))
            row.update({f"{name}_EXPECTED": round(float(value_row[category]), 4)
                        for category, name in enumerate(CATEGORY_NAMES)})
        rows.append(row)
    if any(math.isnan(float(value)) for row in rows for value in row.values() if not isinstance(value, str)):
        raise RuntimeError("The predictions contain NaN values; the checkpoint is probably damaged")
    return common.write_results(rows, output_dir, cfg.OUTPUT_FILENAME)


def parse_args(argv=None):
    """Command-line interface: input folder, output folder, optional checkpoints and overrides."""
    parser = argparse.ArgumentParser(description="OSS challenge - Task 2 OSATS score inference")
    parser.add_argument("input_dir", help="folder with the videos to score")
    parser.add_argument("output_dir", help="folder for the result file")
    parser.add_argument("--checkpoint", action="append", default=[], help="checkpoint file; repeat for an ensemble")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override a CONFIG entry")
    return parser.parse_args(argv)


def main(argv=None):
    """Entry point used by docker/Process_SkillEval.sh and the oss-infer-task2 command."""
    args = parse_args(argv)
    cfg = common.config_namespace(CONFIG)
    common.apply_overrides(cfg, args.set)
    common.export_visible_gpus(cfg.GPU_IDS)
    osats.setup_logging(None)
    osats.set_seed(cfg.SEED, deterministic=True)
    device = common.select_device(cfg.GPU_IDS)
    LOG.info("Task 2 inference | device %s | input %s | output %s", device, args.input_dir, args.output_dir)
    checkpoint_paths = common.resolve_checkpoints(cfg, args.checkpoint)
    start = time.time()
    output_path = predict(args.input_dir, args.output_dir, cfg, checkpoint_paths, device)
    LOG.info("Results written to %s (%.1f s)", output_path, time.time() - start)
    return 0


if __name__ == "__main__":
    sys.exit(main())
