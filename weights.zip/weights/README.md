# Model weights

Put the checkpoints used by the inference scripts (and copied into the container) in this folder.
The file names below are the defaults of `CONFIG.CHECKPOINTS` in the inference scripts; any other
name can be given with `--checkpoint` or `--set CHECKPOINTS=[...]`.

| File | Used by | Format |
|------|---------|--------|
| `task1_grs_model.pth` | `inference_task1.py` (task `GRS`) | `best.pt` of `task1_grs_classification.py`, or a plain `r2plus1d_18` state dict with a 4-way final layer |
| `task2_osats_model.pth` | `inference_task2.py` (task `OSATS`) | `best.pt` of `task2_osats_prediction.py`, or a plain `r2plus1d_18` state dict with 8 regression outputs |
| `task3_keypoint_model.pt` | `inference_task3.py` (task `TRACK`) | `best.pt` of `task3_keypoint_tracking.py` (a plain U-Net state dict is accepted and produces masks) |

A checkpoint of the training scripts can simply be copied and renamed, e.g.

```bash
cp runs/task1_r2plus1d_18_<run>/checkpoints/best.pt weights/task1_grs_model.pth
```

The inference scripts look for this folder next to the code folder; set `OSS_WEIGHTS_DIR` to use
another location. Weight files are excluded from git by `.gitignore`.
