#!/usr/bin/env bash
# --------------------------------------------------------------------------------------
# Entry point of the OSS challenge container.
#
# The evaluation system mounts the test data at /input and an empty folder at /output and runs
#     /usr/local/bin/Process_SkillEval.sh <task>
# where <task> is "GRS" (Task 1) or "OSATS" (Task 2). The keypoint tracking task (Task 3)
# is accepted under several names because its identifier is set by the organisers per phase.
# A container that solves a single task is called without argument; DEFAULT_TASK decides then.
#
# Environment variables (all optional):
#     INPUT_DIR      input folder                     (default /input)
#     OUTPUT_DIR     output folder                    (default /output)
#     CODE_DIR       folder with the Python code      (default /app/code)
#     DEFAULT_TASK   task used when no argument given (default GRS)
#     PYTHON         Python interpreter               (default python3)
#     EXTRA_ARGS     extra arguments passed to the inference script, e.g. "--set GPU_IDS=[]"
# --------------------------------------------------------------------------------------
set -euo pipefail

TASK="${1:-${DEFAULT_TASK:-GRS}}"
TASK="$(echo "${TASK}" | tr '[:lower:]' '[:upper:]')"
INPUT_DIR="${INPUT_DIR:-/input}"
OUTPUT_DIR="${OUTPUT_DIR:-/output}"
CODE_DIR="${CODE_DIR:-/app/code}"
PYTHON="${PYTHON:-python3}"
EXTRA_ARGS="${EXTRA_ARGS:-}"

case "${TASK}" in
    GRS|TASK1)
        SCRIPT="inference_task1.py"
        DESCRIPTION="Task 1 - GRS skill classification"
        ;;
    OSATS|TASK2)
        SCRIPT="inference_task2.py"
        DESCRIPTION="Task 2 - OSATS score prediction"
        ;;
    TRACK|TRACKING|KEYPOINT|KEYPOINTS|KPT|SEG|TASK3)
        SCRIPT="inference_task3.py"
        DESCRIPTION="Task 3 - keypoint tracking"
        ;;
    *)
        echo "Error: unknown task '${TASK}'. Use GRS, OSATS or TRACK." >&2
        exit 1
        ;;
esac

if [ ! -d "${INPUT_DIR}" ]; then
    echo "Error: input folder ${INPUT_DIR} does not exist" >&2
    exit 1
fi
mkdir -p "${OUTPUT_DIR}"

echo "Running ${DESCRIPTION}"
echo "  input : ${INPUT_DIR}"
echo "  output: ${OUTPUT_DIR}"
# shellcheck disable=SC2086
"${PYTHON}" "${CODE_DIR}/${SCRIPT}" "${INPUT_DIR}" "${OUTPUT_DIR}" ${EXTRA_ARGS}
echo "${DESCRIPTION} finished"
