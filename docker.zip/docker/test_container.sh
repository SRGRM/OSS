#!/usr/bin/env bash
# --------------------------------------------------------------------------------------
# Build the container and run every task on local test folders, the same way the
# evaluation system does.
#
#     docker/test_container.sh <videos folder> <frames-or-videos folder for Task 3> [cu118|cu121]
#
# Results are written to ./container_test/<task>.
# --------------------------------------------------------------------------------------
set -euo pipefail

VIDEO_DIR="$(realpath "${1:?usage: test_container.sh <videos> <task3 input> [cu118|cu121]}")"
TRACK_DIR="$(realpath "${2:?usage: test_container.sh <videos> <task3 input> [cu118|cu121]}")"
VARIANT="${3:-cu118}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="oss-skill:${VARIANT}"

if [ "${VARIANT}" = "cu118" ]; then
    DOCKERFILE="${REPO_ROOT}/docker/Dockerfile"
else
    DOCKERFILE="${REPO_ROOT}/docker/Dockerfile.${VARIANT}"
fi

docker build -f "${DOCKERFILE}" -t "${IMAGE}" "${REPO_ROOT}"

for TASK in GRS OSATS TRACK; do
    INPUT="${VIDEO_DIR}"
    [ "${TASK}" = "TRACK" ] && INPUT="${TRACK_DIR}"
    OUTPUT="${REPO_ROOT}/container_test/${TASK}"
    mkdir -p "${OUTPUT}"
    echo "=== ${TASK} ==="
    docker run --rm --gpus '"device=0"' --ipc=host \
        -v "${INPUT}:/input" -v "${OUTPUT}:/output" \
        "${IMAGE}" /usr/local/bin/Process_SkillEval.sh "${TASK}"
    ls -la "${OUTPUT}"
done
